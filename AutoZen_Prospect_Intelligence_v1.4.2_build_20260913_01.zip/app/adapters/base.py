from dataclasses import dataclass
from typing import Protocol

from app.schemas import CompanyCandidate, Contact, DiscoveryDiagnostics, Evidence, LeadRequest, Narrative


@dataclass
class CompanyDiscovery:
    companies: list[CompanyCandidate]
    diagnostics: DiscoveryDiagnostics | None = None


class CompanySource(Protocol):
    async def discover(
        self, request: LeadRequest, candidate_limit: int
    ) -> list[CompanyCandidate]: ...

    async def find_contact(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> Contact: ...


class SignalSource(Protocol):
    async def research(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> list[Evidence]: ...


class ContactVerifier(Protocol):
    async def verify_or_find(
        self, company: CompanyCandidate, contact: Contact
    ) -> Contact: ...


class NarrativeSource(Protocol):
    async def create(
        self,
        request: LeadRequest,
        company: CompanyCandidate,
        contact: Contact,
        evidence: list[Evidence],
    ) -> Narrative: ...
