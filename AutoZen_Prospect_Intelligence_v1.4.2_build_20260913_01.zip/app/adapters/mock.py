from datetime import date, timedelta

from app.schemas import (
    CompanyCandidate,
    Contact,
    EmailStatus,
    EmailType,
    Evidence,
    LeadRequest,
    PhoneType,
    SignalType,
)


class MockCompanySource:
    """Fictional UAE industrial distributors for safe dashboard demonstrations."""

    async def discover(
        self, request: LeadRequest, candidate_limit: int
    ) -> list[CompanyCandidate]:
        companies = [
            CompanyCandidate(
                provider_id="demo-001",
                name="Gulf Flow Systems",
                domain="gulf-flow-systems.example",
                website="https://gulf-flow-systems.example",
                industry="Industrial pumps, valves and flow-control equipment distribution",
                city="Dubai",
                country="United Arab Emirates",
                employee_count=46,
                public_phone="+971 4 555 0101",
                source_provider="mock",
            ),
            CompanyCandidate(
                provider_id="demo-002",
                name="Emirates Automation Supply",
                domain="emirates-automation.example",
                website="https://emirates-automation.example",
                industry="Industrial automation, instrumentation and control systems supplier",
                city="Abu Dhabi",
                country="United Arab Emirates",
                employee_count=73,
                public_phone="+971 2 555 0102",
                source_provider="mock",
            ),
            CompanyCandidate(
                provider_id="demo-003",
                name="Desert Air Compressors",
                domain="desert-air-compressors.example",
                website="https://desert-air-compressors.example",
                industry="Industrial compressors and compressed-air equipment distributor",
                city="Sharjah",
                country="United Arab Emirates",
                employee_count=29,
                public_phone="+971 6 555 0103",
                source_provider="mock",
            ),
            CompanyCandidate(
                provider_id="demo-004",
                name="Aqua Process Equipment",
                domain="aqua-process-equipment.example",
                website="https://aqua-process-equipment.example",
                industry="Water-treatment equipment and industrial filtration supplier",
                city="Ajman",
                country="United Arab Emirates",
                employee_count=35,
                public_phone="+971 6 555 0104",
                source_provider="mock",
            ),
            CompanyCandidate(
                provider_id="demo-005",
                name="Gulf Motion Controls",
                domain="gulf-motion-controls.example",
                website="https://gulf-motion-controls.example",
                industry="Industrial equipment, hydraulics and pneumatics distribution",
                city="Dubai",
                country="United Arab Emirates",
                employee_count=118,
                public_phone="+971 4 555 0105",
                source_provider="mock",
            ),
        ]
        return companies[:candidate_limit]

    async def find_contact(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> Contact:
        contacts = {
            "gulf-flow-systems.example": (
                "Omar Rahman",
                "Sales Director",
                "omar@gulf-flow-systems.example",
            ),
            "emirates-automation.example": (
                "Maya Nair",
                "Commercial Director",
                "maya@emirates-automation.example",
            ),
            "desert-air-compressors.example": (
                "Khalid Mansoor",
                "General Manager",
                "khalid@desert-air-compressors.example",
            ),
            "aqua-process-equipment.example": (
                "Sara Khan",
                "Head of Sales",
                "sara@aqua-process-equipment.example",
            ),
            "gulf-motion-controls.example": (
                "Rami Haddad",
                "Managing Director",
                "rami@gulf-motion-controls.example",
            ),
        }
        name, title, email = contacts[company.domain]
        return Contact(
            name=name,
            title=title,
            email=email,
            email_status=EmailStatus.VERIFIED,
            email_type=EmailType.PERSON_WORK,
            phone=company.public_phone,
            phone_type=PhoneType.GENERIC_COMPANY,
            source_provider="mock",
        )


class MockSignalSource:
    async def research(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> list[Evidence]:
        today = date.today()
        catalogue = {
            "gulf-flow-systems.example": [
                (
                    SignalType.QUOTATION_RFQ,
                    "Request-a-quotation form for configured pump packages",
                    "/request-quote",
                    0.95,
                ),
                (
                    SignalType.TECHNICAL_SALES,
                    "Application engineers support pump and valve selection",
                    "/technical-sales",
                    0.88,
                ),
            ],
            "emirates-automation.example": [
                (
                    SignalType.QUOTATION_RFQ,
                    "Dedicated RFQ channel for instrumentation enquiries",
                    "/rfq",
                    0.96,
                ),
                (
                    SignalType.PROJECT_TENDER,
                    "Project supply team supports tender submissions",
                    "/projects",
                    0.87,
                ),
            ],
            "desert-air-compressors.example": [
                (
                    SignalType.QUOTATION_RFQ,
                    "Quotation request for compressor packages",
                    "/quotation",
                    0.93,
                ),
                (
                    SignalType.TECHNICAL_SALES,
                    "Sales engineers size compressed-air systems",
                    "/engineering",
                    0.86,
                ),
            ],
            "aqua-process-equipment.example": [
                (
                    SignalType.PROJECT_TENDER,
                    "Tender support for water-treatment projects",
                    "/tenders",
                    0.91,
                ),
                (
                    SignalType.QUOTATION_RFQ,
                    "Project quotation enquiry form",
                    "/enquiry",
                    0.90,
                ),
            ],
            "gulf-motion-controls.example": [
                (
                    SignalType.TECHNICAL_SALES,
                    "Technical sales team configures hydraulic systems",
                    "/sales-team",
                    0.90,
                ),
                (
                    SignalType.QUOTATION_RFQ,
                    "RFQ mailbox for industrial components",
                    "/contact",
                    0.89,
                ),
            ],
        }
        return [
            Evidence(
                signal_type=signal_type,
                title=title,
                url=f"https://{company.domain}{path}",
                snippet=(
                    "Fictional demonstration evidence for the AutoZen "
                    "industrial-distributor workflow."
                ),
                source_provider="mock",
                published_at=today - timedelta(days=14),
                confidence=confidence,
            )
            for signal_type, title, path, confidence in catalogue.get(
                company.domain, []
            )
        ]


class MockContactVerifier:
    async def verify_or_find(
        self, company: CompanyCandidate, contact: Contact
    ) -> Contact:
        return contact
