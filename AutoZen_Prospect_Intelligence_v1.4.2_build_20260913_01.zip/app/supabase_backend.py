"""Supabase persistence for AutoZen.

The browser never receives the service-role key.  This module is used only by
the server and talks to the project's PostgREST endpoint.  Tables and the
atomic run-reservation function are created by ``supabase_schema.sql``.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
from datetime import datetime, timezone
from typing import Any

import httpx
from fastapi import HTTPException

from app.schemas import LeadDelivery, OutcomeEvent, SavedDiscoverySeed
from app.store import canonical_domain, utc_now


class SupabaseError(RuntimeError):
    """A sanitized server-side persistence failure."""


class SupabaseClient:
    def __init__(self, url: str, server_key: str, timeout: float = 20.0) -> None:
        self.base_url = url.strip().rstrip("/") + "/rest/v1"
        self.headers = {
            "apikey": server_key.strip(),
            "Content-Type": "application/json",
        }
        # New sb_secret_ keys are API keys, not JWTs. Legacy service_role keys
        # remain supported and are also sent as the bearer JWT they contain.
        if not server_key.strip().startswith("sb_secret_"):
            self.headers["Authorization"] = f"Bearer {server_key.strip()}"
        self.timeout = timeout

    def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, object] | None = None,
        payload: object | None = None,
        prefer: str | None = None,
    ) -> httpx.Response:
        headers = dict(self.headers)
        if prefer:
            headers["Prefer"] = prefer
        try:
            response = httpx.request(
                method,
                f"{self.base_url}/{path.lstrip('/')}",
                params=params,
                json=payload,
                headers=headers,
                timeout=self.timeout,
            )
        except httpx.HTTPError as error:
            raise SupabaseError("The persistent database could not be reached.") from error
        if response.status_code >= 400:
            request_id = response.headers.get("sb-request-id") or response.headers.get("x-request-id")
            suffix = f" Reference: {request_id}." if request_id else ""
            raise SupabaseError(
                f"The persistent database rejected an operation (HTTP {response.status_code}).{suffix}"
            )
        return response

    def rows(self, table: str, params: dict[str, object]) -> list[dict[str, Any]]:
        value = self.request("GET", table, params=params).json()
        if not isinstance(value, list):
            raise SupabaseError("The persistent database returned an invalid result.")
        return [row for row in value if isinstance(row, dict)]

    def upsert(self, table: str, payload: dict[str, object], conflict: str) -> None:
        self.request(
            "POST",
            table,
            params={"on_conflict": conflict},
            payload=payload,
            prefer="resolution=merge-duplicates,return=minimal",
        )

    def insert_ignore(self, table: str, payload: dict[str, object], conflict: str) -> None:
        self.request(
            "POST",
            table,
            params={"on_conflict": conflict},
            payload=payload,
            prefer="resolution=ignore-duplicates,return=minimal",
        )

    def patch(self, table: str, params: dict[str, object], payload: dict[str, object]) -> None:
        self.request("PATCH", table, params=params, payload=payload, prefer="return=minimal")

    def rpc(self, function: str, payload: dict[str, object]) -> Any:
        return self.request("POST", f"rpc/{function}", payload=payload).json()


def _payload(value: object) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        parsed = json.loads(value)
        if isinstance(parsed, dict):
            return parsed
    raise SupabaseError("The persistent database contains an invalid saved payload.")


class SupabaseStore:
    """Auditable prospect store backed by a private Supabase project."""

    def __init__(self, url: str, server_key: str) -> None:
        self.client = SupabaseClient(url, server_key)

    @staticmethod
    def _company_values(row: dict[str, object], niche: str) -> dict[str, object]:
        now = utc_now()
        domain = canonical_domain(
            str(row.get("domain") or row.get("website") or row.get("source_url") or "")
        )
        title = str(row.get("company_name") or row.get("name") or row.get("source_title") or domain)[:300]
        website = str(row.get("website") or f"https://{domain}")
        location = str(row.get("location_text") or "")
        if not location and isinstance(row.get("requested_locations"), list):
            location = " | ".join(str(value) for value in row["requested_locations"])
        employee = row.get("employee_count")
        if employee is None and row.get("employee_count_min") is not None:
            employee = f"{row.get('employee_count_min')}-{row.get('employee_count_max') or '?'}"
        return {
            "p_domain": domain,
            "p_company_name": title,
            "p_website": website,
            "p_seen_at": now,
            "p_niche": niche,
            "p_location_text": location,
            "p_employee_count_text": str(employee or ""),
            "p_payload": row,
        }

    def _upsert_discovery_company(self, row: dict[str, object], niche: str) -> tuple[str, bool]:
        values = self._company_values(row, niche)
        domain = str(values["p_domain"])
        if not domain:
            return "", False
        result = self.client.rpc("autozen_upsert_company", values)
        if not isinstance(result, dict) or "created" not in result:
            raise SupabaseError("The company upsert function returned an invalid result.")
        return domain, bool(result["created"])

    def save_discovery(self, result: dict[str, object]) -> dict[str, int]:
        meta = result.get("meta") if isinstance(result.get("meta"), dict) else {}
        discovery = meta.get("discovery") if isinstance(meta.get("discovery"), dict) else {}
        candidates = discovery.get("candidates") if isinstance(discovery.get("candidates"), list) else []
        request = result.get("request") if isinstance(result.get("request"), dict) else {}
        if meta.get("mode") == "demo":
            return {"new_companies": 0, "existing_companies": 0, "database_total": self.prospect_count()}
        job_id = str(meta.get("job_id") or "")
        niche = str(request.get("niche") or "")
        new_count = existing_count = 0
        for candidate in candidates:
            if not isinstance(candidate, dict):
                continue
            domain = canonical_domain(str(candidate.get("domain") or candidate.get("source_url") or ""))
            if not domain or domain.endswith(".example"):
                continue
            domain, created = self._upsert_discovery_company(candidate, niche)
            if not domain:
                continue
            new_count += int(created)
            existing_count += int(not created)
            source_url = str(candidate.get("source_url") or f"https://{domain}")
            self.client.upsert(
                "autozen_prospect_sources",
                {
                    "domain": domain,
                    "source_url": source_url,
                    "title": str(candidate.get("source_title") or "")[:300],
                    "snippet": str(candidate.get("snippet") or "")[:2000],
                    "source_job_id": job_id,
                    "evidence_kind": "discovery",
                    "observed_at": utc_now(),
                },
                "domain,source_url",
            )
            self.client.insert_ignore(
                "autozen_prospect_occurrences",
                {"job_id": job_id, "domain": domain, "stage": "discovery", "seen_at": utc_now()},
                "job_id,domain,stage",
            )
        return {
            "new_companies": new_count,
            "existing_companies": existing_count,
            "database_total": self.prospect_count(),
        }

    def save_delivery(self, delivery: LeadDelivery) -> None:
        self.client.upsert(
            "autozen_deliveries",
            {
                "job_id": delivery.meta.job_id,
                "generated_at": delivery.meta.generated_at.isoformat(),
                "payload_json": delivery.model_dump(mode="json"),
            },
            "job_id",
        )
        leads = {canonical_domain(lead.company.domain): lead for lead in delivery.leads}
        for assessment in delivery.meta.assessments:
            domain = canonical_domain(assessment.domain)
            if not domain or domain.endswith(".example"):
                continue
            lead = leads.get(domain)
            base = lead.company.model_dump(mode="json") if lead else {
                "domain": domain,
                "name": assessment.company_name,
                "website": f"https://{domain}",
            }
            domain, _ = self._upsert_discovery_company(base, delivery.request.industry)
            if not domain:
                continue
            self.client.patch(
                "autozen_prospect_companies",
                {"domain": f"eq.{domain}"},
                {
                    "status": assessment.status,
                    "grade": assessment.grade,
                    "score": assessment.score,
                    "qualification_reason": assessment.qualification_reason,
                    "last_seen_at": utc_now(),
                },
            )
            self.client.insert_ignore(
                "autozen_prospect_occurrences",
                {"job_id": delivery.meta.job_id, "domain": domain, "stage": "qualification", "seen_at": utc_now()},
                "job_id,domain,stage",
            )
            if lead:
                self._save_lead_details(domain, lead.model_dump(mode="json"))

    def _save_lead_details(self, domain: str, lead: dict[str, object]) -> None:
        company = lead.get("company") if isinstance(lead.get("company"), dict) else {}
        contact = lead.get("contact") if isinstance(lead.get("contact"), dict) else {}
        self.client.patch(
            "autozen_prospect_companies",
            {"domain": f"eq.{domain}"},
            {"public_phone": str(company.get("public_phone") or ""), "payload_json": company},
        )
        if any(contact.get(key) for key in ("name", "email", "linkedin_url", "phone")):
            identity = str(
                contact.get("email")
                or contact.get("linkedin_url")
                or f"{domain}:{contact.get('name')}:{contact.get('title')}"
            ).strip().lower()
            person_key = hashlib.sha256(identity.encode("utf-8")).hexdigest()
            now = utc_now()
            self.client.rpc(
                "autozen_upsert_person",
                {
                    "p_person_key": person_key,
                    "p_domain": domain,
                    "p_name": contact.get("name"),
                    "p_title": contact.get("title"),
                    "p_email": contact.get("email"),
                    "p_email_status": contact.get("email_status"),
                    "p_linkedin_url": contact.get("linkedin_url"),
                    "p_phone": contact.get("phone"),
                    "p_source_url": contact.get("source_url"),
                    "p_seen_at": now,
                    "p_payload": contact,
                },
            )
        evidence = lead.get("evidence") if isinstance(lead.get("evidence"), list) else []
        for item in evidence:
            if not isinstance(item, dict) or not item.get("url"):
                continue
            evidence_type = str(item.get("signal_type") or "research")
            url = str(item["url"])
            key = hashlib.sha256(f"{domain}|{evidence_type}|{url}".encode("utf-8")).hexdigest()
            self.client.upsert(
                "autozen_prospect_evidence",
                {
                    "evidence_key": key,
                    "domain": domain,
                    "evidence_type": evidence_type,
                    "title": str(item.get("title") or "")[:300],
                    "source_url": url,
                    "snippet": str(item.get("snippet") or "")[:2000],
                    "confidence": item.get("confidence"),
                    "observed_at": utc_now(),
                },
                "evidence_key",
            )

    def prospect_count(self) -> int:
        return int(self.client.rpc("autozen_prospect_count", {}))

    def list_prospects(
        self, limit: int = 100, status: str | None = None, grade: str | None = None
    ) -> list[dict[str, object]]:
        params: dict[str, object] = {
            "select": "domain,company_name,website,first_seen_at,last_seen_at,last_niche,status,website_status,grade,score,qualification_reason,location_text,employee_count_text,public_phone,seen_count",
            "order": "last_seen_at.desc",
            "limit": max(1, min(limit, 500)),
        }
        if status:
            params["status"] = f"eq.{status}"
        if grade:
            params["grade"] = f"eq.{grade}"
        return self.client.rows("autozen_prospect_companies", params)

    def get_prospect(self, domain: str) -> dict[str, object] | None:
        domain = canonical_domain(domain)
        companies = self.client.rows(
            "autozen_prospect_companies", {"select": "*", "domain": f"eq.{domain}", "limit": 1}
        )
        if not companies:
            return None
        result: dict[str, object] = dict(companies[0])
        result["people"] = self.client.rows(
            "autozen_prospect_people",
            {"select": "*", "domain": f"eq.{domain}", "order": "last_seen_at.desc"},
        )
        result["evidence"] = self.client.rows(
            "autozen_prospect_evidence",
            {"select": "*", "domain": f"eq.{domain}", "order": "observed_at.desc"},
        )
        result["sources"] = self.client.rows(
            "autozen_prospect_sources",
            {"select": "*", "domain": f"eq.{domain}", "order": "observed_at.desc"},
        )
        return result

    def saved_discovery(self, domains: list[str]) -> tuple[list[SavedDiscoverySeed], list[str]]:
        seeds: list[SavedDiscoverySeed] = []
        missing: list[str] = []
        for value in domains:
            domain = canonical_domain(value)
            companies = self.client.rows(
                "autozen_prospect_companies",
                {"select": "domain,company_name,website", "domain": f"eq.{domain}", "limit": 1},
            )
            if not companies:
                missing.append(value)
                continue
            sources = self.client.rows(
                "autozen_prospect_sources",
                {"select": "source_url,title,snippet", "domain": f"eq.{domain}", "order": "observed_at.desc", "limit": 1},
            )
            company = companies[0]
            source = sources[0] if sources else {}
            seeds.append(
                SavedDiscoverySeed(
                    source_url=str(source.get("source_url") or company.get("website") or f"https://{domain}"),
                    source_title=str(source.get("title") or company.get("company_name") or domain),
                    snippet=str(source.get("snippet") or "Saved prospect database company; re-verify before qualification."),
                )
            )
        return seeds, missing

    def prospects_csv(self, limit: int = 500) -> str:
        rows = self.list_prospects(limit=limit)
        output = io.StringIO()
        fields = [
            "domain", "company_name", "website", "last_niche", "status", "grade", "score",
            "qualification_reason", "location_text", "employee_count_text", "public_phone", "last_seen_at",
        ]
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fields})
        return output.getvalue()

    def get_delivery(self, job_id: str) -> LeadDelivery | None:
        rows = self.client.rows(
            "autozen_deliveries", {"select": "payload_json", "job_id": f"eq.{job_id}", "limit": 1}
        )
        return None if not rows else LeadDelivery.model_validate(_payload(rows[0]["payload_json"]))

    def list_deliveries(self, limit: int = 20) -> list[dict[str, object]]:
        rows = self.client.rows(
            "autozen_deliveries",
            {"select": "payload_json", "order": "generated_at.desc", "limit": limit},
        )
        items: list[dict[str, object]] = []
        for row in rows:
            delivery = LeadDelivery.model_validate(_payload(row["payload_json"]))
            items.append(
                {
                    "job_id": delivery.meta.job_id,
                    "generated_at": delivery.meta.generated_at.isoformat(),
                    "mode": delivery.meta.mode,
                    "industry": delivery.request.industry,
                    "geographies": delivery.request.geographies,
                    "qualified_count": delivery.meta.qualified_count,
                    "requested_count": delivery.meta.requested_count,
                }
            )
        return items

    def save_outcome(self, event: OutcomeEvent) -> None:
        self.client.request(
            "POST",
            "autozen_outcomes",
            payload={
                "job_id": event.job_id,
                "company_domain": event.company_domain,
                "outcome": event.outcome,
                "note": event.note,
                "recorded_at": event.recorded_at.isoformat(),
            },
            prefer="return=minimal",
        )

    def list_outcomes(self, job_id: str) -> list[dict[str, str | None]]:
        rows = self.client.rows(
            "autozen_outcomes",
            {
                "select": "company_domain,outcome,note,recorded_at",
                "job_id": f"eq.{job_id}",
                "order": "id.asc",
            },
        )
        return [{key: row.get(key) for key in ("company_domain", "outcome", "note", "recorded_at")} for row in rows]


class SupabaseRunLedger:
    """Atomic idempotency and shared daily caps stored in Supabase."""

    def __init__(self, url: str, server_key: str) -> None:
        self.client = SupabaseClient(url, server_key)

    def reserve(self, key: str, route: str, payload: object, live: bool, limit: int):
        if not re.fullmatch(r"[A-Za-z0-9_-]{16,100}", key or ""):
            raise HTTPException(400, "A fresh Idempotency-Key of 16–100 letters, digits, hyphens or underscores is required.")
        fingerprint = hashlib.sha256(
            (route + "\n" + json.dumps(payload, sort_keys=True, separators=(",", ":"))).encode()
        ).hexdigest()
        result = self.client.rpc(
            "autozen_reserve_run",
            {
                "p_key": key,
                "p_fingerprint": fingerprint,
                "p_day": datetime.now(timezone.utc).date().isoformat(),
                "p_live": bool(live),
                "p_limit": int(limit),
            },
        )
        if not isinstance(result, dict):
            raise SupabaseError("The run ledger returned an invalid result.")
        action = result.get("action")
        if action == "reserved":
            return None
        if action == "cached":
            return result.get("result")
        if action == "different_inputs":
            raise HTTPException(409, "That request key belongs to different inputs.")
        if action == "active_or_interrupted":
            raise HTTPException(409, "This run is active, failed, or interrupted. No automatic retry was made; check saved results before starting another run.")
        if action == "live_run_active":
            raise HTTPException(409, "A live run is active or interrupted. Resolve it before spending more credits.")
        if action == "daily_limit":
            raise HTTPException(429, "Daily live-run limit reached. It covers both AutoZen workflows and counts failed attempts.")
        raise SupabaseError("The run ledger returned an unknown result.")

    def finish(self, key: str, result: object) -> None:
        self.client.patch(
            "autozen_run_operations",
            {"operation_key": f"eq.{key}"},
            {"state": "completed", "result": result, "updated_at": utc_now()},
        )

    def fail(self, key: str) -> None:
        self.client.patch(
            "autozen_run_operations",
            {"operation_key": f"eq.{key}"},
            {"state": "failed", "updated_at": utc_now()},
        )

    def get_result(self, job_id: str):
        rows = self.client.rows(
            "autozen_run_operations",
            {"select": "result", "state": "eq.completed", "order": "created_at.desc", "limit": 1000},
        )
        for row in rows:
            result = row.get("result")
            if isinstance(result, str):
                result = json.loads(result)
            if isinstance(result, dict) and result.get("meta", {}).get("job_id") == job_id:
                return result
        return None

    def used_today(self) -> int:
        return int(
            self.client.rpc(
                "autozen_live_runs_used",
                {"p_day": datetime.now(timezone.utc).date().isoformat()},
            )
        )
