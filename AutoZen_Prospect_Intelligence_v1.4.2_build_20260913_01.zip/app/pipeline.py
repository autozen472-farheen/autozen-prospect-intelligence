from __future__ import annotations

import asyncio
import time
import uuid
from dataclasses import dataclass
from datetime import date

from app.adapters.base import (
    CompanySource,
    CompanyDiscovery,
    ContactVerifier,
    NarrativeSource,
    SignalSource,
)
from app.schemas import (
    CompanyCandidate,
    Contact,
    DeliveryMeta,
    Evidence,
    LeadDelivery,
    LeadRecord,
    LeadRequest,
    EmailStatus,
    ProspectAssessment,
)
from app.scoring import grade_for_score, hard_filter_failures, score_candidate
from app.roles import title_matches_requested_roles
from app.adapters.live import ProviderError


@dataclass(frozen=True)
class QualificationRejection:
    reason: str
    score: int | None = None
    evidence_urls: tuple[str, ...] = ()
    unknowns: tuple[str, ...] = ()


class LeadPipeline:
    def __init__(
        self,
        company_source: CompanySource,
        signal_source: SignalSource,
        contact_verifier: ContactVerifier,
        narrative_source: NarrativeSource,
        mode: str,
        max_concurrency: int = 4,
    ) -> None:
        self.company_source = company_source
        self.signal_source = signal_source
        self.contact_verifier = contact_verifier
        self.narrative_source = narrative_source
        self.mode = mode
        self.semaphore = asyncio.Semaphore(max_concurrency)

    async def run(self, request: LeadRequest) -> LeadDelivery:
        if request.saved_discovery and self.mode != 'live':
            raise ProviderError('Previous research JSON requires live verification mode; it cannot produce demo leads.')
        started = time.perf_counter()
        job_id = f"leadjob_{uuid.uuid4().hex[:16]}"
        warnings: list[str] = []
        candidate_limit = min(100, max(request.desired_count * 4, 20))
        discover_batch = getattr(self.company_source, "discover_batch", None)
        batch = (await discover_batch(request, candidate_limit)) if discover_batch else CompanyDiscovery(await self.company_source.discover(request, candidate_limit))
        candidates, discovery = batch.companies, batch.diagnostics
        findings = {item.domain: item for item in discovery.candidates} if discovery else {}
        if discovery is not None:
            warnings.append(
                "Discovery diagnostics: "
                f"{len(discovery.queries)} search(es), {discovery.raw_results} result(s), "
                f"{discovery.eligible_domains} shortlisted domain(s), "
                f"{discovery.hunter_enrichment_attempts} Hunter attempt(s), "
                f"{discovery.enriched_companies} complete company profile(s)."
            )
            if discovery.stopped_reason:
                warnings.append(f"Provider work stopped: {discovery.stopped_reason}. See discovery details.")
        candidates = self._deduplicate(candidates)
        filtered: list[CompanyCandidate] = []
        assessments: list[ProspectAssessment] = []
        hard_rejections = {
            "industry": 0,
            "employee range": 0,
            "geography": 0,
        }
        for candidate in candidates:
            failures = hard_filter_failures(request, candidate)
            if not failures:
                filtered.append(candidate)
                continue
            for failure in failures:
                hard_rejections[failure] += 1
            if candidate.domain in findings:
                findings[candidate.domain].status = "not_qualified"
                findings[candidate.domain].reasons = [f.replace(" ", "_") + "_mismatch" for f in failures]
            assessments.append(ProspectAssessment(
                domain=candidate.domain,
                company_name=candidate.name,
                status="rejected",
                grade="Reject",
                score=0,
                qualification_reason="Rejected by required ICP filter: " + ", ".join(failures) + ".",
                evidence_urls=self._company_sources(candidate),
                unknowns=self._unknowns(candidate, None, []),
            ))
        tasks = [self._qualify(request, company) for company in filtered]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        qualified: list[LeadRecord] = []
        evidence_gate_rejections = 0
        contact_rejections = 0
        score_rejections = 0
        qualification_errors = 0
        provider_unavailable_rejections = 0
        for company, result in zip(filtered, results, strict=False):
            finding = findings.get(company.domain)
            if isinstance(result, Exception):
                qualification_errors += 1
                warnings.append(
                    f"{company.domain}: qualification failed ({type(result).__name__})."
                )
                if finding:
                    finding.status = "needs_verification"
                    finding.reasons = ["qualification_provider_error" if isinstance(result, ProviderError) else "qualification_error"]
                assessments.append(ProspectAssessment(
                    domain=company.domain,
                    company_name=company.name,
                    status="incomplete",
                    qualification_reason="Qualification could not complete because a research step failed.",
                    evidence_urls=self._company_sources(company),
                    unknowns=self._unknowns(company, None, []),
                ))
                continue
            if isinstance(result, QualificationRejection):
                if finding:
                    finding.status = "needs_verification" if result.reason in {"provider_unavailable", "unusable_contact"} else "not_qualified"
                    finding.reasons = [result.reason]
                if result.reason == "missing_required_sales_signal":
                    evidence_gate_rejections += 1
                elif result.reason == "unusable_contact":
                    contact_rejections += 1
                elif result.reason == "below_minimum_score":
                    score_rejections += 1
                elif result.reason == "provider_unavailable":
                    provider_unavailable_rejections += 1
                incomplete = result.reason == "provider_unavailable"
                assessments.append(ProspectAssessment(
                    domain=company.domain,
                    company_name=company.name,
                    status="incomplete" if incomplete else "rejected",
                    grade=None if incomplete else "Reject",
                    score=result.score,
                    qualification_reason=self._reason_text(result.reason, request.minimum_score),
                    evidence_urls=list(result.evidence_urls) or self._company_sources(company),
                    unknowns=list(result.unknowns) or self._unknowns(company, None, []),
                ))
            elif result.score.total >= request.minimum_score:
                result.grade = grade_for_score(result.score.total, request.minimum_score)
                result.qualification_reason = "Meets the requested ICP, buyer-contact gate, and minimum score."
                qualified.append(result)
            else:
                score_rejections += 1
                if finding:
                    finding.status = "not_qualified"
                    finding.reasons = ["below_minimum_score"]
                assessments.append(ProspectAssessment(
                    domain=company.domain,
                    company_name=company.name,
                    status="rejected",
                    grade="Reject",
                    score=result.score.total,
                    qualification_reason=self._reason_text("below_minimum_score", request.minimum_score),
                    evidence_urls=list(dict.fromkeys(item.url for item in result.evidence)),
                    unknowns=self._unknowns(company, result.contact, result.evidence),
                ))

        rejection_parts = [
            f"{count} {label} mismatch{'es' if count != 1 else ''}"
            for label, count in hard_rejections.items()
            if count
        ]
        if rejection_parts:
            warnings.append(
                "ICP filters rejected discovered companies: "
                + ", ".join(rejection_parts)
                + "."
            )
        if evidence_gate_rejections:
            warnings.append(
                f"{evidence_gate_rejections} compan{'ies' if evidence_gate_rejections != 1 else 'y'} "
                "had no current revenue-workflow evidence selected in this brief."
            )
        if contact_rejections:
            warnings.append(
                f"{contact_rejections} compan{'ies' if contact_rejections != 1 else 'y'} "
                "had no requested decision-maker role with a valid or accept-all personal work email."
            )
        if score_rejections:
            warnings.append(
                f"{score_rejections} compan{'ies' if score_rejections != 1 else 'y'} "
                f"scored below the minimum score of {request.minimum_score}."
            )
        if provider_unavailable_rejections:
            warnings.append(
                f"{provider_unavailable_rejections} compan{'ies' if provider_unavailable_rejections != 1 else 'y'} "
                "were preserved as provider-unavailable rather than misclassified as weak prospects after repeated research failures."
            )
        if qualification_errors:
            warnings.append(
                f"{qualification_errors} compan{'ies' if qualification_errors != 1 else 'y'} "
                "hit an unexpected qualification error."
            )

        rejection_summary = {
            "industry": hard_rejections["industry"],
            "employee_range": hard_rejections["employee range"],
            "geography": hard_rejections["geography"],
            "missing_required_sales_signal": evidence_gate_rejections,
            "unusable_contact": contact_rejections,
            "below_minimum_score": score_rejections,
            "provider_failure": qualification_errors,
            "provider_unavailable": provider_unavailable_rejections,
        }

        qualified.sort(
            key=lambda lead: (
                lead.score.total,
                lead.score.quotation_rfq,
                lead.score.evidence_quality,
            ),
            reverse=True,
        )
        selected = qualified[: request.desired_count]
        selected_domains = {lead.company.domain for lead in selected}
        for lead in qualified:
            if lead.company.domain in findings:
                finding = findings[lead.company.domain]
                finding.status = "qualified" if lead.company.domain in selected_domains else "not_selected"
                finding.reasons = [] if finding.status == "qualified" else ["requested_count_reached"]
        for index, lead in enumerate(selected, start=1):
            lead.rank = index
        for lead in qualified:
            selected_for_delivery = lead.company.domain in selected_domains
            assessments.append(ProspectAssessment(
                domain=lead.company.domain,
                company_name=lead.company.name,
                status="qualified" if selected_for_delivery else "not_selected",
                grade=lead.grade,
                score=lead.score.total,
                qualification_reason=(lead.qualification_reason if selected_for_delivery
                                      else "Qualified, but the requested delivery count was already reached."),
                evidence_urls=list(dict.fromkeys(item.url for item in lead.evidence)),
                unknowns=self._unknowns(lead.company, lead.contact, lead.evidence),
            ))

        if len(selected) < request.desired_count:
            warnings.append(
                f"Returned {len(selected)} of {request.desired_count} requested leads; "
                "Unverified discoveries are not qualified leads. Review the diagnostic reasons below."
            )

        delivery_mode = "import" if request.seed_companies else self.mode
        if delivery_mode == "mock":
            warnings.insert(
                0,
                "Demonstration mode uses fictional companies and contacts; do not send outreach.",
            )
        elif delivery_mode == "import":
            warnings.insert(
                0,
                "Imported fields are scored as supplied; verify provider rights, source URLs, and contact status before outreach.",
            )
        duration_ms = round((time.perf_counter() - started) * 1000)
        meta = DeliveryMeta(
            job_id=job_id,
            mode=delivery_mode,
            requested_count=request.desired_count,
            candidates_considered=len(candidates),
            qualified_count=len(selected),
            duration_ms=duration_ms,
            warnings=warnings,
            rejection_summary=rejection_summary,
            discovery=discovery,
            assessments=sorted(assessments, key=lambda item: (item.status != "qualified", -(item.score or -1), item.domain)),
        )
        return LeadDelivery(request=request, meta=meta, leads=selected)

    async def _qualify(
        self, request: LeadRequest, company: CompanyCandidate
    ) -> LeadRecord | QualificationRejection:
        async with self.semaphore:
            # V1.1 researches commercial evidence before spending a Hunter
            # decision-maker lookup. Weak companies are rejected first.
            try:
                evidence = await self.signal_source.research(company, request)
            except ProviderError:
                return QualificationRejection(
                    "provider_unavailable",
                    unknowns=tuple(self._unknowns(company, None, [])),
                )
            if request.require_timing_signal and not self._has_current_desired_signal(
                request, evidence
            ):
                return QualificationRejection(
                    "missing_required_sales_signal",
                    evidence_urls=tuple(dict.fromkeys(item.url for item in evidence)),
                    unknowns=tuple(self._unknowns(company, None, evidence)),
                )

            # A contact can contribute at most 15 reachability points. If the
            # company cannot possibly reach the requested minimum even with a
            # perfect buyer, skip the paid contact lookup entirely.
            precontact = score_candidate(request, company, evidence, Contact(source_provider="precontact"))
            if self.mode == "live" and not request.seed_companies:
                if precontact.total + 15 < request.minimum_score:
                    return QualificationRejection(
                        "below_minimum_score",
                        score=precontact.total,
                        evidence_urls=tuple(dict.fromkeys(item.url for item in evidence)),
                        unknowns=tuple(self._unknowns(company, None, evidence)),
                    )

            contact = await self.company_source.find_contact(company, request)
            contact = await self.contact_verifier.verify_or_find(company, contact)
            score = score_candidate(request, company, evidence, contact)
            if (
                self.mode == "live"
                and not request.seed_companies
                and not self._has_usable_buyer_contact(request, contact)
            ):
                return QualificationRejection(
                    "unusable_contact",
                    score=score.total,
                    evidence_urls=tuple(dict.fromkeys(item.url for item in evidence)),
                    unknowns=tuple(self._unknowns(company, contact, evidence)),
                )
            narrative = await self.narrative_source.create(
                request, company, contact, evidence
            )
            return LeadRecord(
                rank=1,
                company=company,
                contact=contact,
                evidence=evidence,
                score=score,
                narrative=narrative,
                grade=grade_for_score(score.total, request.minimum_score),
            )

    @staticmethod
    def _company_sources(company: CompanyCandidate) -> list[str]:
        return list(dict.fromkeys(
            value for value in [company.source_url, company.website,
                                *(fact.source_url for fact in company.verification_facts)]
            if value
        ))

    @staticmethod
    def _unknowns(company: CompanyCandidate, contact: Contact | None,
                  evidence: list[Evidence]) -> list[str]:
        unknowns: list[str] = []
        if company.employee_count is None and company.employee_count_min is None:
            unknowns.append("employee_count")
        if not company.country and not company.city:
            unknowns.append("operating_location")
        if not evidence:
            unknowns.append("business_pain_or_workflow_evidence")
        if contact is None or not contact.name:
            unknowns.append("decision_maker")
        if contact is None or not contact.email or contact.email_status not in {EmailStatus.VERIFIED, EmailStatus.ACCEPT_ALL}:
            unknowns.append("verified_work_email")
        return unknowns

    @staticmethod
    def _reason_text(reason: str, minimum_score: int) -> str:
        return {
            "missing_required_sales_signal": "Required revenue-workflow evidence was not found.",
            "unusable_contact": "No requested decision-maker with a usable verified or accept-all work email was found.",
            "below_minimum_score": f"Score is below the requested minimum of {minimum_score}.",
            "provider_unavailable": "Research provider was unavailable; the company was held for review rather than graded.",
        }.get(reason, reason.replace("_", " ").capitalize() + ".")

    @staticmethod
    def _has_usable_buyer_contact(
        request: LeadRequest, contact: Contact
    ) -> bool:
        return bool(
            contact.name
            and contact.email
            and contact.email_status in {EmailStatus.VERIFIED, EmailStatus.ACCEPT_ALL}
            and title_matches_requested_roles(contact.title, request.target_roles)
        )

    @staticmethod
    def _has_current_desired_signal(
        request: LeadRequest, evidence: list[Evidence]
    ) -> bool:
        for item in evidence:
            if item.signal_type not in request.desired_signals:
                continue
            if item.published_at is None:
                return True
            if (date.today() - item.published_at).days <= request.freshness_days:
                return True
        return False

    @staticmethod
    def _deduplicate(companies: list[CompanyCandidate]) -> list[CompanyCandidate]:
        output: list[CompanyCandidate] = []
        seen: set[str] = set()
        for company in companies:
            key = company.domain.lower().removeprefix("www.")
            if key in seen:
                continue
            seen.add(key)
            output.append(company)
        return output
