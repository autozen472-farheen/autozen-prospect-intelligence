"""Bounded first-party GETs. No API keys, cookies, proxies, JS, or access bypass.

DNS answers are validated then pinned to the socket; TLS still checks the
original hostname. Every redirect is rechecked and consumes the shared budget.
"""
from __future__ import annotations

import asyncio
import http.client
import ipaddress
import socket
import ssl
import time
from dataclasses import dataclass
from urllib.parse import urljoin, urlsplit
from urllib.robotparser import RobotFileParser

from app.discovery import WEBSITE_HTTP_CAP, domain_from_url

AGENT = "AutoZenResearch"
MAX_BYTES = 800_000


class WebReadError(Exception):
    pass


def validate_url(url: str, domain: str):
    try:
        parsed = urlsplit(url)
        if parsed.scheme != 'https' or parsed.username or parsed.password or parsed.port not in (None, 443):
            raise ValueError('scheme/port')
        if domain_from_url(url) != domain or any(ord(c) < 32 for c in url) or '\\' in url:
            raise ValueError('host')
        host = (parsed.hostname or '').encode('idna').decode('ascii')
        if '.' not in host or host.endswith(('.localhost', '.local', '.internal')):
            raise ValueError('host')
        if re_sensitive_path(parsed.path):
            raise ValueError('sensitive path')
        return parsed, host
    except (ValueError, UnicodeError):
        raise WebReadError('website_url_blocked') from None


def re_sensitive_path(path: str) -> bool:
    from urllib.parse import unquote
    import re
    return bool(re.search(r'/(?:admin|login|signin|logout|checkout|account|wp-admin|api)(?:/|$)', unquote(path), re.I))


def public_addresses(host: str) -> list[str]:
    try:
        answers = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
        values = list(dict.fromkeys(answer[4][0] for answer in answers))
        if not values:
            raise ValueError('empty')
        for value in values:
            ip = ipaddress.ip_address(value)
            if not ip.is_global or ip.is_multicast or getattr(ip, 'ipv4_mapped', None) or getattr(ip, 'sixtofour', None) or getattr(ip, 'teredo', None):
                raise ValueError('private or transition address')
        return values
    except (OSError, ValueError):
        raise WebReadError('website_dns_blocked_or_unavailable') from None


@dataclass
class Page:
    url: str
    status: int
    text: str
    content_type: str = 'text/html'
    location: str | None = None


def pinned_get(url: str, domain: str) -> Page:
    parsed, host = validate_url(url, domain)
    address = public_addresses(host)[0]
    connection = http.client.HTTPSConnection(host, timeout=5)
    sock = None
    try:
        # Connect to this numeric address only, never resolve the hostname again.
        family = socket.AF_INET6 if ':' in address else socket.AF_INET
        sock = socket.socket(family, socket.SOCK_STREAM)
        sock.settimeout(5)
        sock.connect((address, 443))
        context = ssl.create_default_context()
        context.set_alpn_protocols(['http/1.1'])
        connection.sock = context.wrap_socket(sock, server_hostname=host)
        connection.request('GET', (parsed.path or '/') + ('?' + parsed.query if parsed.query else ''), headers={
            'User-Agent': AGENT + '/1.2.6 (public company research)',
            'Accept': 'text/html,text/plain,application/xhtml+xml', 'Accept-Encoding': 'identity',
        })
        response = connection.getresponse()
        content_type = response.getheader('Content-Type', '').split(';')[0].strip().lower()
        if response.status >= 300:
            return Page(url, response.status, '', content_type, response.getheader('Location'))
        if content_type not in {'text/html', 'text/plain', 'application/xhtml+xml'} or response.getheader('Content-Encoding', 'identity') != 'identity':
            raise WebReadError('website_unsupported_content')
        length = response.getheader('Content-Length')
        if length and int(length) > MAX_BYTES:
            raise WebReadError('website_page_too_large')
        chunks, size, started = [], 0, time.monotonic()
        while True:
            if time.monotonic() - started > 12:
                raise WebReadError('website_timeout')
            chunk = response.read1(16384)
            if not chunk:
                break
            size += len(chunk)
            if size > MAX_BYTES:
                raise WebReadError('website_page_too_large')
            chunks.append(chunk)
        encoding = response.headers.get_content_charset() or 'utf-8'
        return Page(url, response.status, b''.join(chunks).decode(encoding, errors='replace'), content_type)
    except WebReadError:
        raise
    except (OSError, ValueError, LookupError, http.client.HTTPException):
        raise WebReadError('website_unavailable') from None
    finally:
        connection.close()
        if sock is not None:
            sock.close()


class PublicWebReader:
    def __init__(self, limit: int = WEBSITE_HTTP_CAP):
        self.limit = min(WEBSITE_HTTP_CAP, max(0, limit))
        self.requests = 0
        self.robots: dict[str, RobotFileParser] = {}

    async def _get(self, url: str, domain: str) -> Page:
        validate_url(url, domain)
        if self.requests >= self.limit:
            raise WebReadError('website_budget_reached')
        self.requests += 1
        return await asyncio.to_thread(pinned_get, url, domain)

    async def _follow(self, url: str, domain: str, rules=None) -> Page:
        for _ in range(3):
            validate_url(url, domain)
            if rules and not rules.can_fetch(AGENT, url):
                raise WebReadError('website_robots_disallowed')
            page = await self._get(url, domain)
            if page.status in {301, 302, 303, 307, 308} and page.location:
                target = urljoin(url, page.location)
                validate_url(target, domain)
                if urlsplit(target).netloc.lower() != urlsplit(url).netloc.lower():
                    raise WebReadError('website_cross_origin_redirect_blocked')
                url = target
                continue
            return page
        raise WebReadError('website_redirect_limit')

    async def read(self, url: str, domain: str) -> Page:
        parsed, _ = validate_url(url, domain)
        origin = f'https://{parsed.netloc}'
        if origin not in self.robots:
            robot_page = await self._follow(origin + '/robots.txt', domain)
            rules = RobotFileParser()
            if robot_page.status == 404:
                rules.parse([])
            elif robot_page.status == 200:
                if robot_page.content_type != 'text/plain':
                    raise WebReadError('website_robots_unavailable')
                rules.parse(robot_page.text.splitlines())
            else:
                raise WebReadError('website_robots_unavailable')
            # Honor restrictive crawl timing by skipping, rather than extra requests.
            rate = rules.request_rate(AGENT)
            if rules.crawl_delay(AGENT) or (rate and rate.seconds > rate.requests):
                raise WebReadError('website_robots_crawl_delay')
            self.robots[origin] = rules
        page = await self._follow(url, domain, self.robots[origin])
        if page.status != 200:
            raise WebReadError(f'website_http_{page.status}')
        if page.content_type not in {'text/html', 'application/xhtml+xml'}:
            raise WebReadError('website_unsupported_content')
        return page
