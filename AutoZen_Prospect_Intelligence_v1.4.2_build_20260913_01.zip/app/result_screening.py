"""Conservative, offline source screening. No ownership or niche verification.

Reference pages are retained for review, never turned into the mentioned
company's domain. A name in a title is only a quoted, unverified hint.
"""
from dataclasses import dataclass
import re
from urllib.parse import unquote, urlsplit


@dataclass(frozen=True)
class SourceScreen:
    disposition: str = 'candidate'
    reason: str = ''
    mentioned_business: str | None = None


def screen_source(domain: str, url: str, title: str, snippet: str = '') -> SourceScreen:
    domain = domain.lower().rstrip('.')
    # Label boundaries matter: neither gov.au.example.com nor gov-supplies.com
    # is a government domain. This list is deliberately not a worldwide registry.
    if re.search(r'(?:^|\.)gov(?:\.[a-z]{2})?$', domain) or domain.endswith('.govt.nz'):
        return SourceScreen('excluded', 'government_source')

    path = unquote(urlsplit(url).path).lower()
    named = re.match(r'^(.{2,120}?)\s+[—–-]\s+(?:authorized|authorised|certified)\s+'
                     r'(?:.{0,35}?\s+)?(?:distributor|dealer|partner)\b', title, re.I)
    subject = named.group(1).strip() if named else None
    # A manufacturer's distributor profile or locator is a source, not the
    # distributor's own website. Do not visit an email-derived domain.
    profile_path = bool(re.search(r'/(?:[^/]*[-_])?(?:distributors|dealers|partners)/[^/]+', path)
                        or re.search(r'/(?:authorized|authorised|certified)[-_][^/]*'
                                     r'(?:distributors|dealers|partners)(?:[-_/]|$)', path))
    locator = bool(re.search(r'\b(?:dealer|distributor|partner)\s+(?:locator|directory|network)\b', title, re.I)
                   or re.search(r'\b(?:find|locate)\s+(?:(?:your|our|a|an)\s+)?'
                                r'(?:(?:authorized|authorised)\s+)?(?:dealer|distributor|partner)s?\b', title, re.I)
                   or re.search(r'/(?:dealer|distributor|partner)[-_](?:locator|directory|network)(?:/|$)', path))
    email_hosts = re.findall(r'\b(?:sales|info|contact|office|service)@([a-z0-9.-]+\.[a-z]{2,})\b', snippet, re.I)
    different_host = any(host.lower() != domain and not host.lower().endswith('.' + domain) for host in email_hosts)
    if profile_path or locator or (named and different_host):
        return SourceScreen('reference', 'distributor_reference', subject)
    return SourceScreen()
