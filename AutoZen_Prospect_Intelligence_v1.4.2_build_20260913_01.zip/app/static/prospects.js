const list = document.querySelector('#prospect-list');
const summary = document.querySelector('#database-summary');

function add(parent, tag, value, className) {
  const node = document.createElement(tag);
  node.textContent = value;
  if (className) node.className = className;
  parent.appendChild(node);
  return node;
}

function safeLink(parent, label, value) {
  try {
    const url = new URL(value);
    if (!['http:', 'https:'].includes(url.protocol)) return;
    const link = add(parent, 'a', label);
    link.href = url.href; link.target = '_blank'; link.rel = 'noopener noreferrer';
  } catch {}
}

function summaryCard(label, value) {
  const card = document.createElement('div');
  card.className = 'summary-card';
  add(card, 'span', label); add(card, 'strong', String(value));
  summary.appendChild(card);
}

fetch('/v1/prospects?limit=500').then(async response => {
  if (!response.ok) throw new Error('Could not load the Prospect Database.');
  return response.json();
}).then(payload => {
  const items = payload.items;
  document.querySelector('#status').textContent = `${payload.database_total} unique companies`;
  document.querySelector('#database-title').textContent = `${items.length} saved prospect${items.length === 1 ? '' : 's'}`;
  document.querySelector('#database-note').textContent = 'Discovery adds or updates a domain; qualification adds the grade, reason, evidence and buyer record.';
  summaryCard('Unique companies', payload.database_total);
  summaryCard('Qualified', items.filter(item => item.status === 'qualified').length);
  summaryCard('Needs qualification', items.filter(item => item.status === 'discovered').length);
  for (const item of items) {
    const card = document.createElement('article');
    card.className = 'lead-card';
    const title = add(card, 'h3', `${item.grade || 'Ungraded'} · ${item.company_name || item.domain}`);
    title.title = item.domain;
    add(card, 'p', `${item.domain} · ${item.status.replaceAll('_', ' ')}${item.score == null ? '' : ` · ${item.score}/100`}`, 'company-meta');
    add(card, 'p', item.qualification_reason || 'Discovered only; deeper research and qualification have not run.', 'review-reason');
    add(card, 'p', [item.last_niche, item.location_text, item.employee_count_text && `${item.employee_count_text} employees`].filter(Boolean).join(' · ') || 'Firmographic details remain unverified.', 'company-meta');
    safeLink(card, 'Company website', item.website);
    list.appendChild(card);
  }
  if (!items.length) add(list, 'p', 'No real companies are saved yet. Run the Prospecting Agent in an approved live or import mode.', 'alert warning');
}).catch(error => {
  document.querySelector('#status').textContent = 'Database unavailable';
  add(list, 'p', error.message, 'alert error');
});
