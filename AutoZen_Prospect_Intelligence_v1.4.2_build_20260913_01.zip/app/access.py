"""Owner-only dashboard and API, with a fail-closed live-run switch."""
import base64
import binascii
import secrets
from urllib.parse import urlsplit

from starlette.responses import JSONResponse

from app.config import get_settings


class OwnerAccess:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            await self.app(scope, receive, send)
            return
        settings = get_settings()
        path = scope['path']
        headers = {k.lower(): v for k, v in scope.get('headers', [])}

        async def deny(status, text, challenge=False):
            extra = {'Cache-Control': 'no-store'}
            if challenge:
                extra['WWW-Authenticate'] = 'Basic realm="AutoZen owner", charset="UTF-8"'
            await JSONResponse({'detail': text}, status_code=status, headers=extra)(scope, receive, send)

        async def secured_send(message):
            if message['type'] == 'http.response.start':
                message['headers'] = list(message.get('headers', [])) + [
                    (b'cache-control', b'no-store'), (b'x-content-type-options', b'nosniff'),
                    (b'x-frame-options', b'DENY'), (b'referrer-policy', b'no-referrer'),
                ]
            await send(message)

        # Minimal liveness is public. All configuration, jobs, docs and static UI
        # are protected whenever hosted or configured for real providers.
        protect = settings.app_environment != 'development' or settings.data_mode == 'live' or bool(settings.dashboard_password)
        if path != '/health' and protect:
            if not settings.dashboard_username or len(settings.dashboard_password or '') < 16:
                await deny(503, 'Set a dashboard username and a private password of at least 16 characters in Render.')
                return
            try:
                scheme, token = headers.get(b'authorization', b'').decode('ascii').split(' ', 1)
                user, password = base64.b64decode(token, validate=True).decode('utf-8').split(':', 1)
                valid = scheme.lower() == 'basic' and secrets.compare_digest(user.encode(), settings.dashboard_username.encode()) and secrets.compare_digest(password.encode(), settings.dashboard_password.encode())
            except (ValueError, UnicodeError, binascii.Error):
                valid = False
            if not valid:
                await deny(401, 'Owner login required.', True)
                return
        if scope['method'] not in {'GET', 'HEAD', 'OPTIONS'}:
            # Scripts intentionally send JSON plus a non-simple request header.
            # No cross-origin CORS policy is enabled; browser cross-site writes
            # and form posts fail before any provider operation.
            if headers.get(b'sec-fetch-site') == b'cross-site':
                await deny(403, 'Cross-site writes are not allowed.')
                return
            if b'origin' in headers:
                try:
                    origin = urlsplit(headers[b'origin'].decode('ascii'))
                    same = origin.scheme in {'http', 'https'} and origin.netloc.lower() == headers.get(b'host', b'').decode('ascii').lower()
                except (ValueError, UnicodeError):
                    same = False
                if not same:
                    await deny(403, 'Cross-origin writes are not allowed.')
                    return
            if path.startswith('/v1/') and not headers.get(b'content-type', b'').lower().startswith(b'application/json'):
                await deny(415, 'Use application/json.')
                return
            chunks, size = [], 0
            while True:
                message = await receive()
                if message['type'] == 'http.disconnect':
                    return
                part = message.get('body', b'')
                chunks.append(part)
                size += len(part)
                if size > 2_000_000:
                    await deny(413, 'Request exceeds 2 MB.')
                    return
                if not message.get('more_body', False):
                    break
            delivered = False

            async def bounded_receive():
                nonlocal delivered
                if not delivered:
                    delivered = True
                    return {'type': 'http.request', 'body': b''.join(chunks), 'more_body': False}
                return await receive()

            await self.app(scope, bounded_receive, secured_send)
            return
        await self.app(scope, receive, secured_send)
