from __future__ import annotations

import csv
import io

from app.schemas import LeadDelivery


def safe_cell(value):
    if isinstance(value, str) and value.lstrip().startswith(('=', '+', '-', '@')):
        return "'" + value
    return value


class SafeDictWriter(csv.DictWriter):
    def writerow(self, rowdict):
        return super().writerow({key: safe_cell(value) for key, value in rowdict.items()})


CSV_COLUMNS = [
    "rank",
    "grade",
    "qualification_reason",
    "score_total",
    "score_icp_fit",
    "score_commercial_value",
    "score_quotation_rfq",
    "score_workflow_evidence",
    "score_reachability",
    "score_evidence_quality",
    "company_name",
    "domain",
    "website",
    "industry",
    "location",
    "employee_count",
    "employee_count_range",
    "technologies",
    "active_job_count",
    "contact_name",
    "contact_title",
    "contact_email",
    "email_status",
    "email_type",
    "contact_phone",
    "phone_type",
    "linkedin_url",
    "company_source_url",
    "contact_source_url",
    "why_now",
    "outreach_hook",
    "narrative_confidence",
    "signals",
    "evidence_titles",
    "evidence_urls",
    "evidence_dates",
    "warnings",
    "verification_facts",
    "verification_sources",
]


def delivery_to_csv(delivery: LeadDelivery) -> str:
    output = io.StringIO(newline="")
    writer = SafeDictWriter(output, fieldnames=CSV_COLUMNS)
    writer.writeheader()
    for lead in delivery.leads:
        writer.writerow(
            {
                "rank": lead.rank,
                "grade": lead.grade,
                "qualification_reason": lead.qualification_reason,
                "score_total": lead.score.total,
                "score_icp_fit": lead.score.icp_fit,
                "score_commercial_value": lead.score.commercial_value,
                "score_quotation_rfq": lead.score.quotation_rfq,
                "score_workflow_evidence": lead.score.quotation_rfq,
                "score_reachability": lead.score.reachability,
                "score_evidence_quality": lead.score.evidence_quality,
                "company_name": lead.company.name,
                "domain": lead.company.domain,
                "website": lead.company.website,
                "industry": lead.company.industry,
                "location": lead.company.location_text,
                "employee_count": lead.company.employee_count,
                "employee_count_range": lead.company.employee_count_text,
                "technologies": " | ".join(lead.company.technologies),
                "active_job_count": lead.company.active_job_count,
                "contact_name": lead.contact.name,
                "contact_title": lead.contact.title,
                "contact_email": lead.contact.email,
                "email_status": lead.contact.email_status.value,
                "email_type": lead.contact.email_type.value,
                "contact_phone": lead.contact.phone,
                "phone_type": lead.contact.phone_type.value,
                "linkedin_url": lead.contact.linkedin_url,
                "company_source_url": lead.company.source_url,
                "contact_source_url": lead.contact.source_url,
                "why_now": lead.narrative.why_now,
                "outreach_hook": lead.narrative.outreach_hook,
                "narrative_confidence": lead.narrative.confidence,
                "signals": " | ".join(
                    dict.fromkeys(item.signal_type.value for item in lead.evidence)
                ),
                "evidence_titles": " | ".join(
                    item.title for item in lead.evidence
                ),
                "evidence_urls": " | ".join(item.url for item in lead.evidence),
                "evidence_dates": " | ".join(
                    item.published_at.isoformat() if item.published_at else "undated"
                    for item in lead.evidence
                ),
                "warnings": " | ".join(lead.narrative.warnings),
                "verification_facts": " | ".join(f'{fact.field}: {fact.value} ({fact.method})' for fact in lead.company.verification_facts),
                "verification_sources": " | ".join(dict.fromkeys(fact.source_url for fact in lead.company.verification_facts)),
            }
        )
    return output.getvalue()


def delivery_to_review_csv(delivery: LeadDelivery) -> str:
    """Research-only export: never relabel missing facts as qualified leads."""
    output = io.StringIO(newline='')
    columns = ['domain', 'search_title', 'delivery_status', 'grade', 'score',
        'qualification_reason', 'unknowns', 'reasons', 'website_status',
        'published_name', 'published_location', 'published_employee_count', 'published_employee_range',
        'public_company_phone', 'hunter_attempted', 'hunter_http_status', 'search_url', 'fact_sources',
        'notice']
    writer = SafeDictWriter(output, fieldnames=columns)
    writer.writeheader()
    decisions = {item.domain: item for item in delivery.meta.assessments}
    for item in (delivery.meta.discovery.candidates if delivery.meta.discovery else []):
        if item.status == 'qualified':
            continue
        site = item.website
        decision = decisions.get(item.domain)
        writer.writerow({'domain': item.domain, 'search_title': item.source_title,
            'delivery_status': item.status, 'grade': decision.grade if decision else '',
            'score': decision.score if decision else '',
            'qualification_reason': decision.qualification_reason if decision else '',
            'unknowns': ' | '.join(decision.unknowns) if decision else '',
            'reasons': ' | '.join(item.reasons),
            'website_status': site.status, 'published_name': site.name,
            'published_location': ', '.join(x for x in [site.city, site.country] if x),
            'published_employee_count': site.employee_count,
            'published_employee_range': f'{site.employee_count_min}-{site.employee_count_max}' if site.employee_count_min else '',
            'public_company_phone': site.public_phone, 'hunter_attempted': item.hunter_attempted,
            'hunter_http_status': item.hunter_http_status, 'search_url': item.source_url,
            'fact_sources': ' | '.join(f'{fact.field}: {fact.value} [{fact.source_url}]' for fact in site.facts),
            'notice': 'Research only; not in the qualified delivery. Verify missing facts before use.'})
    return output.getvalue()
