from __future__ import annotations

import csv
import hashlib
import io
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

from app.schemas import LeadDelivery, OutcomeEvent, SavedDiscoverySeed


def canonical_domain(value: str) -> str:
    candidate = value.strip().lower()
    if "://" not in candidate:
        candidate = "https://" + candidate
    try:
        host = (urlsplit(candidate).hostname or "").lower().rstrip(".")
    except ValueError:
        return ""
    return host.removeprefix("www.")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class SQLiteStore:
    """Auditable store shared by discovery and qualification."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS deliveries (
                    job_id TEXT PRIMARY KEY,
                    generated_at TEXT NOT NULL,
                    payload_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS outcomes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_id TEXT NOT NULL,
                    company_domain TEXT NOT NULL,
                    outcome TEXT NOT NULL,
                    note TEXT,
                    recorded_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS prospect_companies (
                    domain TEXT PRIMARY KEY,
                    company_name TEXT NOT NULL,
                    website TEXT NOT NULL,
                    first_seen_at TEXT NOT NULL,
                    last_seen_at TEXT NOT NULL,
                    first_niche TEXT,
                    last_niche TEXT,
                    status TEXT NOT NULL DEFAULT 'discovered',
                    website_status TEXT NOT NULL DEFAULT 'not_checked',
                    grade TEXT,
                    score INTEGER,
                    qualification_reason TEXT,
                    location_text TEXT,
                    employee_count_text TEXT,
                    public_phone TEXT,
                    payload_json TEXT NOT NULL DEFAULT '{}',
                    seen_count INTEGER NOT NULL DEFAULT 1
                );
                CREATE TABLE IF NOT EXISTS prospect_sources (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    domain TEXT NOT NULL,
                    source_url TEXT NOT NULL,
                    title TEXT,
                    snippet TEXT,
                    source_job_id TEXT NOT NULL,
                    evidence_kind TEXT NOT NULL,
                    observed_at TEXT NOT NULL,
                    UNIQUE(domain, source_url),
                    FOREIGN KEY(domain) REFERENCES prospect_companies(domain)
                );
                CREATE TABLE IF NOT EXISTS prospect_people (
                    person_key TEXT PRIMARY KEY,
                    domain TEXT NOT NULL,
                    name TEXT,
                    title TEXT,
                    email TEXT,
                    email_status TEXT,
                    linkedin_url TEXT,
                    phone TEXT,
                    source_url TEXT,
                    first_seen_at TEXT NOT NULL,
                    last_seen_at TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    FOREIGN KEY(domain) REFERENCES prospect_companies(domain)
                );
                CREATE TABLE IF NOT EXISTS prospect_evidence (
                    evidence_key TEXT PRIMARY KEY,
                    domain TEXT NOT NULL,
                    evidence_type TEXT NOT NULL,
                    title TEXT,
                    source_url TEXT NOT NULL,
                    snippet TEXT,
                    confidence REAL,
                    observed_at TEXT NOT NULL,
                    FOREIGN KEY(domain) REFERENCES prospect_companies(domain)
                );
                CREATE TABLE IF NOT EXISTS prospect_occurrences (
                    job_id TEXT NOT NULL,
                    domain TEXT NOT NULL,
                    stage TEXT NOT NULL,
                    seen_at TEXT NOT NULL,
                    PRIMARY KEY(job_id, domain, stage),
                    FOREIGN KEY(domain) REFERENCES prospect_companies(domain)
                );
                CREATE INDEX IF NOT EXISTS ix_prospect_status ON prospect_companies(status);
                CREATE INDEX IF NOT EXISTS ix_prospect_grade ON prospect_companies(grade);
                CREATE INDEX IF NOT EXISTS ix_people_domain ON prospect_people(domain);
                CREATE INDEX IF NOT EXISTS ix_evidence_domain ON prospect_evidence(domain);
                """
            )

    @staticmethod
    def _company_values(row: dict[str, object], niche: str) -> tuple[object, ...]:
        now = utc_now()
        domain = canonical_domain(str(row.get("domain") or row.get("website") or row.get("source_url") or ""))
        title = str(row.get("company_name") or row.get("name") or row.get("source_title") or domain)[:300]
        website = str(row.get("website") or f"https://{domain}")
        location = str(row.get("location_text") or "")
        if not location and isinstance(row.get("requested_locations"), list):
            location = " | ".join(str(value) for value in row["requested_locations"])
        employee = row.get("employee_count")
        if employee is None and row.get("employee_count_min") is not None:
            employee = f"{row.get('employee_count_min')}-{row.get('employee_count_max') or '?'}"
        return (domain, title, website, now, now, niche, niche, location,
                str(employee or ""), json.dumps(row, ensure_ascii=False, default=str))

    def _upsert_discovery_company(self, connection: sqlite3.Connection,
                                  row: dict[str, object], niche: str) -> str:
        values = self._company_values(row, niche)
        domain = str(values[0])
        if not domain:
            return ""
        connection.execute(
            """
            INSERT INTO prospect_companies(
                domain, company_name, website, first_seen_at, last_seen_at,
                first_niche, last_niche, location_text, employee_count_text, payload_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(domain) DO UPDATE SET
                company_name=CASE WHEN excluded.company_name != '' THEN excluded.company_name ELSE company_name END,
                website=CASE WHEN excluded.website != '' THEN excluded.website ELSE website END,
                last_seen_at=excluded.last_seen_at,
                last_niche=excluded.last_niche,
                location_text=CASE WHEN excluded.location_text != '' THEN excluded.location_text ELSE location_text END,
                employee_count_text=CASE WHEN excluded.employee_count_text != '' THEN excluded.employee_count_text ELSE employee_count_text END,
                payload_json=excluded.payload_json,
                seen_count=seen_count + 1
            """,
            values,
        )
        return domain

    def save_discovery(self, result: dict[str, object]) -> dict[str, int]:
        meta = result.get("meta") if isinstance(result.get("meta"), dict) else {}
        discovery = meta.get("discovery") if isinstance(meta.get("discovery"), dict) else {}
        candidates = discovery.get("candidates") if isinstance(discovery.get("candidates"), list) else []
        request = result.get("request") if isinstance(result.get("request"), dict) else {}
        if meta.get("mode") == "demo":
            return {"new_companies": 0, "existing_companies": 0, "database_total": self.prospect_count()}
        job_id = str(meta.get("job_id") or "")
        niche = str(request.get("niche") or "")
        new_count = existing_count = 0
        with self._connect() as connection:
            for candidate in candidates:
                if not isinstance(candidate, dict):
                    continue
                domain = canonical_domain(str(candidate.get("domain") or candidate.get("source_url") or ""))
                if not domain or domain.endswith(".example"):
                    continue
                existed = connection.execute(
                    "SELECT 1 FROM prospect_companies WHERE domain = ?", (domain,)
                ).fetchone() is not None
                domain = self._upsert_discovery_company(connection, candidate, niche)
                if not domain:
                    continue
                existing_count += int(existed)
                new_count += int(not existed)
                source_url = str(candidate.get("source_url") or f"https://{domain}")
                connection.execute(
                    """
                    INSERT INTO prospect_sources(domain, source_url, title, snippet, source_job_id, evidence_kind, observed_at)
                    VALUES (?, ?, ?, ?, ?, 'discovery', ?)
                    ON CONFLICT(domain, source_url) DO UPDATE SET
                        title=excluded.title, snippet=excluded.snippet,
                        source_job_id=excluded.source_job_id, observed_at=excluded.observed_at
                    """,
                    (domain, source_url, str(candidate.get("source_title") or "")[:300],
                     str(candidate.get("snippet") or "")[:2000], job_id, utc_now()),
                )
                connection.execute(
                    "INSERT OR IGNORE INTO prospect_occurrences(job_id, domain, stage, seen_at) VALUES (?, ?, 'discovery', ?)",
                    (job_id, domain, utc_now()),
                )
            total = connection.execute("SELECT COUNT(*) FROM prospect_companies").fetchone()[0]
        return {"new_companies": new_count, "existing_companies": existing_count, "database_total": int(total)}

    def save_delivery(self, delivery: LeadDelivery) -> None:
        leads = {canonical_domain(lead.company.domain): lead for lead in delivery.leads}
        with self._connect() as connection:
            connection.execute(
                "INSERT OR REPLACE INTO deliveries(job_id, generated_at, payload_json) VALUES (?, ?, ?)",
                (delivery.meta.job_id, delivery.meta.generated_at.isoformat(), delivery.model_dump_json()),
            )
            for assessment in delivery.meta.assessments:
                domain = canonical_domain(assessment.domain)
                if not domain or domain.endswith(".example"):
                    continue
                lead = leads.get(domain)
                base = lead.company.model_dump(mode="json") if lead else {
                    "domain": domain, "name": assessment.company_name, "website": f"https://{domain}"
                }
                domain = self._upsert_discovery_company(connection, base, delivery.request.industry)
                if not domain:
                    continue
                connection.execute(
                    """UPDATE prospect_companies SET status=?, grade=?, score=?,
                       qualification_reason=?, last_seen_at=? WHERE domain=?""",
                    (assessment.status, assessment.grade, assessment.score,
                     assessment.qualification_reason, utc_now(), domain),
                )
                connection.execute(
                    "INSERT OR IGNORE INTO prospect_occurrences(job_id, domain, stage, seen_at) VALUES (?, ?, 'qualification', ?)",
                    (delivery.meta.job_id, domain, utc_now()),
                )
                if lead:
                    self._save_lead_details(connection, domain, lead.model_dump(mode="json"))

    def _save_lead_details(self, connection: sqlite3.Connection,
                           domain: str, lead: dict[str, object]) -> None:
        company = lead.get("company") if isinstance(lead.get("company"), dict) else {}
        contact = lead.get("contact") if isinstance(lead.get("contact"), dict) else {}
        connection.execute(
            "UPDATE prospect_companies SET public_phone=?, payload_json=? WHERE domain=?",
            (str(company.get("public_phone") or ""),
             json.dumps(company, ensure_ascii=False, default=str), domain),
        )
        if any(contact.get(key) for key in ("name", "email", "linkedin_url", "phone")):
            identity = str(contact.get("email") or contact.get("linkedin_url") or
                           f"{domain}:{contact.get('name')}:{contact.get('title')}").strip().lower()
            person_key = hashlib.sha256(identity.encode("utf-8")).hexdigest()
            now = utc_now()
            connection.execute(
                """
                INSERT INTO prospect_people(person_key, domain, name, title, email, email_status,
                    linkedin_url, phone, source_url, first_seen_at, last_seen_at, payload_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(person_key) DO UPDATE SET
                    name=excluded.name, title=excluded.title, email=excluded.email,
                    email_status=excluded.email_status, linkedin_url=excluded.linkedin_url,
                    phone=excluded.phone, source_url=excluded.source_url,
                    last_seen_at=excluded.last_seen_at, payload_json=excluded.payload_json
                """,
                (person_key, domain, contact.get("name"), contact.get("title"), contact.get("email"),
                 contact.get("email_status"), contact.get("linkedin_url"), contact.get("phone"),
                 contact.get("source_url"), now, now,
                 json.dumps(contact, ensure_ascii=False, default=str)),
            )
        evidence = lead.get("evidence") if isinstance(lead.get("evidence"), list) else []
        for item in evidence:
            if not isinstance(item, dict) or not item.get("url"):
                continue
            evidence_type = str(item.get("signal_type") or "research")
            url = str(item["url"])
            key = hashlib.sha256(f"{domain}|{evidence_type}|{url}".encode("utf-8")).hexdigest()
            connection.execute(
                """
                INSERT INTO prospect_evidence(evidence_key, domain, evidence_type, title, source_url,
                    snippet, confidence, observed_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(evidence_key) DO UPDATE SET title=excluded.title, snippet=excluded.snippet,
                    confidence=excluded.confidence, observed_at=excluded.observed_at
                """,
                (key, domain, evidence_type, str(item.get("title") or "")[:300], url,
                 str(item.get("snippet") or "")[:2000], item.get("confidence"), utc_now()),
            )

    def prospect_count(self) -> int:
        with self._connect() as connection:
            return int(connection.execute("SELECT COUNT(*) FROM prospect_companies").fetchone()[0])

    def list_prospects(self, limit: int = 100, status: str | None = None,
                       grade: str | None = None) -> list[dict[str, object]]:
        clauses: list[str] = []
        values: list[object] = []
        if status:
            clauses.append("status = ?")
            values.append(status)
        if grade:
            clauses.append("grade = ?")
            values.append(grade)
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        values.append(max(1, min(limit, 500)))
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT domain, company_name, website, first_seen_at, last_seen_at, last_niche, status, website_status, grade, score, qualification_reason, location_text, employee_count_text, public_phone, seen_count FROM prospect_companies"
                + where + " ORDER BY last_seen_at DESC LIMIT ?", values,
            ).fetchall()
        return [dict(row) for row in rows]

    def get_prospect(self, domain: str) -> dict[str, object] | None:
        domain = canonical_domain(domain)
        with self._connect() as connection:
            company = connection.execute("SELECT * FROM prospect_companies WHERE domain=?", (domain,)).fetchone()
            if company is None:
                return None
            people = connection.execute("SELECT * FROM prospect_people WHERE domain=? ORDER BY last_seen_at DESC", (domain,)).fetchall()
            evidence = connection.execute("SELECT * FROM prospect_evidence WHERE domain=? ORDER BY observed_at DESC", (domain,)).fetchall()
            sources = connection.execute("SELECT * FROM prospect_sources WHERE domain=? ORDER BY observed_at DESC", (domain,)).fetchall()
        result = dict(company)
        result["people"] = [dict(row) for row in people]
        result["evidence"] = [dict(row) for row in evidence]
        result["sources"] = [dict(row) for row in sources]
        return result

    def saved_discovery(self, domains: list[str]) -> tuple[list[SavedDiscoverySeed], list[str]]:
        seeds, missing = [], []
        with self._connect() as connection:
            for value in domains:
                domain = canonical_domain(value)
                row = connection.execute(
                    """SELECT c.domain, c.company_name, c.website, s.source_url, s.title, s.snippet
                       FROM prospect_companies c LEFT JOIN prospect_sources s ON s.id=(
                           SELECT id FROM prospect_sources WHERE domain=c.domain ORDER BY observed_at DESC LIMIT 1)
                       WHERE c.domain=?""", (domain,),
                ).fetchone()
                if row is None:
                    missing.append(value)
                    continue
                seeds.append(SavedDiscoverySeed(
                    source_url=row["source_url"] or row["website"] or f"https://{domain}",
                    source_title=row["title"] or row["company_name"],
                    snippet=row["snippet"] or "Saved prospect database company; re-verify before qualification.",
                ))
        return seeds, missing

    def prospects_csv(self, limit: int = 500) -> str:
        rows = self.list_prospects(limit=limit)
        output = io.StringIO()
        fields = ["domain", "company_name", "website", "last_niche", "status", "grade", "score",
                  "qualification_reason", "location_text", "employee_count_text", "public_phone", "last_seen_at"]
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fields})
        return output.getvalue()

    def get_delivery(self, job_id: str) -> LeadDelivery | None:
        with self._connect() as connection:
            row = connection.execute("SELECT payload_json FROM deliveries WHERE job_id = ?", (job_id,)).fetchone()
        return None if row is None else LeadDelivery.model_validate_json(row["payload_json"])

    def list_deliveries(self, limit: int = 20) -> list[dict[str, object]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT payload_json FROM deliveries ORDER BY generated_at DESC LIMIT ?", (limit,)
            ).fetchall()
        items: list[dict[str, object]] = []
        for row in rows:
            delivery = LeadDelivery.model_validate_json(row["payload_json"])
            items.append({"job_id": delivery.meta.job_id,
                          "generated_at": delivery.meta.generated_at.isoformat(),
                          "mode": delivery.meta.mode, "industry": delivery.request.industry,
                          "geographies": delivery.request.geographies,
                          "qualified_count": delivery.meta.qualified_count,
                          "requested_count": delivery.meta.requested_count})
        return items

    def save_outcome(self, event: OutcomeEvent) -> None:
        with self._connect() as connection:
            connection.execute(
                "INSERT INTO outcomes(job_id, company_domain, outcome, note, recorded_at) VALUES (?, ?, ?, ?, ?)",
                (event.job_id, event.company_domain, event.outcome, event.note,
                 event.recorded_at.isoformat()),
            )

    def list_outcomes(self, job_id: str) -> list[dict[str, str | None]]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT company_domain, outcome, note, recorded_at FROM outcomes WHERE job_id = ? ORDER BY id ASC",
                (job_id,),
            ).fetchall()
        return [dict(row) for row in rows]
