from __future__ import annotations

from math import ceil

from app.config import Settings
from app.discovery import DISCOVERY_QUERY_COUNT, DISCOVERY_RESULT_LIMIT, FIRECRAWL_MAX_ATTEMPTS, WEBSITE_COMPANY_CAP, WEBSITE_HTTP_CAP
from app.schemas import LeadRequest


def search_credit_estimate(results_per_source: int, sources: int = 1) -> int:
    # Plain search, without scrape/ZDR options: 2 credits per 10 results,
    # rounded up. Conservatively round each requested source separately.
    return 2 * ceil(results_per_source / 10) * sources


def estimate_zero_cost_usage(settings: Settings, request: LeadRequest) -> dict[str, object]:
    """Credit planning, NOT a cash quote or provider-account balance check."""
    live = settings.data_mode == "live"
    imported_count = len(request.seed_companies)
    automatic_hunter = live and not imported_count and (
        settings.company_provider == "hunter" or
        (settings.company_provider == "auto" and bool(settings.hunter_api_key))
    )
    candidate_cap = min(imported_count, 100) if imported_count else (
        settings.hunter_candidate_attempts_per_run if automatic_hunter
        else min(100, max(request.desired_count * 4, 20))
    )
    hybrid = automatic_hunter and bool(settings.firecrawl_api_key)
    focused = DISCOVERY_QUERY_COUNT if hybrid and not request.saved_discovery else 0
    fallback = 1 if hybrid and not request.saved_discovery else 0
    research = candidate_cap if live and settings.firecrawl_api_key else 0
    focused_credits = focused * search_credit_estimate(DISCOVERY_RESULT_LIMIT)
    fallback_credits = fallback * search_credit_estimate(DISCOVERY_RESULT_LIMIT)
    research_credits = research * search_credit_estimate(settings.firecrawl_results_per_company, 2)
    single_attempt = focused_credits + fallback_credits + research_credits
    company_calls = candidate_cap if automatic_hunter else 0
    contact_calls = candidate_cap if live and settings.hunter_api_key else 0
    hunter_estimate = company_calls + contact_calls * (1 if automatic_hunter else 2)
    warnings = [
        "Estimates are per run, not a monthly or account-wide spending limit.",
        "Actual charges and remaining credits depend on your provider plan; no balance was checked.",
    ]
    if automatic_hunter and request.desired_count > candidate_cap:
        warnings.append("Requested leads exceed the capped company attempts; fewer leads can be returned.")
    if live and settings.narrative_mode == "openai":
        warnings.append("Optional OpenAI token charges are additional and are not included here.")
    return {
        "currency": "AED", "estimated_cash_charge": None if live else 0,
        "assumption": "Credit estimates only; free allowances and paid billing settings are not verified.",
        "candidate_cap": candidate_cap, "qualified_pool_cap": candidate_cap,
        "saved_research_used": bool(request.saved_discovery),
        "website_verification": {"company_checks_max": WEBSITE_COMPANY_CAP if hybrid else 0,
            "http_requests_max": WEBSITE_HTTP_CAP if hybrid else 0,
            "provider_api_credits": 0,
            "note": "Direct public-page reads use hosting resources; blocked sites are not bypassed."},
        "hunter": {
            "company_enrichment_calls": company_calls,
            "contact_lookup_calls": contact_calls,
            "estimated_max_credits": hunter_estimate,
            "discover_calls": 2 if automatic_hunter and not hybrid else 0,
        },
        "firecrawl": {
            "company_discovery_searches": focused,
            "fallback_searches": fallback,
            "signal_research_searches": research,
            "search_calls": focused + fallback + research,
            "request_attempts_max": (focused + fallback + research) * FIRECRAWL_MAX_ATTEMPTS,
            "discovery_result_limit": DISCOVERY_RESULT_LIMIT if hybrid else 0,
            "focused_discovery_credits": focused_credits,
            "credits_before_retries": single_attempt,
            "estimated_max_credits": single_attempt * FIRECRAWL_MAX_ATTEMPTS,
            "includes_fallback_and_retries": True,
            "pricing_reference": "https://docs.firecrawl.dev/features/search#cost-implications",
        },
        "warnings": warnings,
    }
