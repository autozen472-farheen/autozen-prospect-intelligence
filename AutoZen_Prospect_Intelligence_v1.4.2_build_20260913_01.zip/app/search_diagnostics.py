"""Allowlisted Global search diagnostics. Never serialize exceptions or headers."""
import socket
import ssl

import httpx

from app.public_web import WebReadError


CLIENT_TIMEOUT_SECONDS = 25
PROVIDER_TIMEOUT_MS = 20000

# Specific subclasses must precede their bases. Names and explanations are
# constants, not type(error).__name__ or provider-controlled exception messages.
ERROR_TYPES = (
    (httpx.ConnectTimeout, 'search_connect_timeout', 'The connection timed out.'),
    (httpx.ReadTimeout, 'search_read_timeout', 'Waiting for response data timed out. This does not prove the provider stopped processing.'),
    (httpx.WriteTimeout, 'search_write_timeout', 'Sending request data timed out.'),
    (httpx.PoolTimeout, 'search_pool_timeout', 'Waiting for a local connection slot timed out.'),
    (httpx.ConnectError, 'search_connect_error', 'A connection could not be established.'),
    (httpx.ReadError, 'search_read_error', 'The connection failed while receiving data.'),
    (httpx.WriteError, 'search_write_error', 'The connection failed while sending data.'),
    (httpx.CloseError, 'search_close_error', 'The connection could not be closed normally.'),
    (httpx.LocalProtocolError, 'search_local_protocol_error', 'The client could not send a valid HTTP exchange. Check local request configuration.'),
    (httpx.RemoteProtocolError, 'search_remote_protocol_error', 'The remote HTTP exchange was incomplete or invalid.'),
    (httpx.ProxyError, 'search_proxy_error', 'A proxy connection failed.'),
    (httpx.UnsupportedProtocol, 'search_unsupported_protocol', 'The request used an unsupported protocol.'),
    (httpx.DecodingError, 'search_decoding_error', 'Response data could not be decoded.'),
    (httpx.TooManyRedirects, 'search_redirect_error', 'The HTTP client reported too many redirects.'),
    (httpx.HTTPStatusError, 'search_http_status_error', 'The HTTP client reported an unsuccessful status.'),
    (httpx.TimeoutException, 'search_timeout', 'An HTTP operation timed out; the specific operation is unknown.'),
    (httpx.NetworkError, 'search_network_error', 'The HTTP client reported a network failure.'),
    (httpx.ProtocolError, 'search_protocol_error', 'The HTTP client reported a protocol failure.'),
    (httpx.HTTPError, 'search_http_error', 'The HTTP client reported an unclassified failure.'),
    (UnicodeEncodeError, 'search_encoding_error', 'Request text could not be encoded. Check for non-ASCII characters in the API key without sharing it.'),
)

SAFE_PROVIDER_ERRORS = {
    'firecrawl_response_too_large': 'The response exceeded the existing size limit.',
    'firecrawl_invalid_response': 'The response was not valid search-result JSON.',
    'firecrawl_unsuccessful_response': 'The provider returned an unsuccessful response.',
}


def underlying_cause(error):
    """Report a known exception category only when present, never infer from text."""
    seen = set()
    current = error
    for _ in range(8):
        if current is None or id(current) in seen:
            break
        seen.add(id(current))
        for kind, code in (
            (ssl.SSLCertVerificationError, 'tls_certificate_verification_error'),
            (ssl.SSLError, 'tls_error'),
            (socket.gaierror, 'dns_resolution_error'),
            (ConnectionRefusedError, 'connection_refused'),
            (ConnectionResetError, 'connection_reset'),
        ):
            if isinstance(current, kind):
                return code
        current = current.__cause__ or (None if current.__suppress_context__ else current.__context__)
    return 'unknown'


def describe_search_error(error):
    if isinstance(error, SearchFailure):
        return dict(error.diagnostic)
    code, name, explanation = 'search_failed', 'Unknown', 'Search failed; no safe error category was available.'
    if isinstance(error, WebReadError):
        # Only accept exact internal codes. Unknown exception messages are private.
        value = error.args[0] if len(error.args) == 1 and isinstance(error.args[0], str) else ''
        if value in SAFE_PROVIDER_ERRORS:
            code, explanation = value, SAFE_PROVIDER_ERRORS[value]
        elif value.startswith('firecrawl_http_') and value[15:].isascii() and value[15:].isdigit() and len(value[15:]) == 3 and 100 <= int(value[15:]) <= 599:
            code, explanation = value, 'The provider returned an unsuccessful HTTP status.'
        name = 'WebReadError'
    else:
        for kind, label, message in ERROR_TYPES:
            if isinstance(error, kind):
                code, name, explanation = label, kind.__name__, message
                break
    return {
        'code': code, 'error_type': name, 'explanation': explanation,
        'underlying_cause': underlying_cause(error),
        'stage': 'unknown', 'response_received': None, 'http_status': None,
        'client_timeout_seconds': CLIENT_TIMEOUT_SECONDS,
        'provider_timeout_ms': PROVIDER_TIMEOUT_MS, 'retry_attempted': False,
    }


class SearchFailure(WebReadError):
    def __init__(self, error, stage, http_status):
        self.diagnostic = describe_search_error(error)
        self.diagnostic.update(stage=stage, response_received=http_status is not None, http_status=http_status)
        super().__init__(self.diagnostic['code'])
