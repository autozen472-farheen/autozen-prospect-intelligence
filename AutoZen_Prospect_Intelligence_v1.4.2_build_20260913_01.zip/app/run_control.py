"""Durable idempotency and a shared daily cap for both AutoZen workflows.

Requires persistent SQLite for restart durability. Failed and interrupted live
runs count; uncertain operations are never retried automatically.
"""
import hashlib
import json
import re
import sqlite3
from datetime import datetime, timezone

from fastapi import HTTPException


class RunLedger:
    def __init__(self, path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS run_operations (key TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, day TEXT NOT NULL, live INTEGER NOT NULL, state TEXT NOT NULL, result TEXT)')

    def connect(self):
        return sqlite3.connect(self.path, timeout=10)

    def reserve(self, key, route, payload, live, limit):
        if not re.fullmatch(r'[A-Za-z0-9_-]{16,100}', key or ''):
            raise HTTPException(400, 'A fresh Idempotency-Key of 16–100 letters, digits, hyphens or underscores is required.')
        fingerprint = hashlib.sha256((route + '\n' + json.dumps(payload, sort_keys=True, separators=(',', ':'))).encode()).hexdigest()
        day = datetime.now(timezone.utc).date().isoformat()
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT fingerprint,state,result FROM run_operations WHERE key=?', (key,)).fetchone()
            if row:
                if row[0] != fingerprint:
                    raise HTTPException(409, 'That request key belongs to different inputs.')
                if row[1] == 'completed':
                    return json.loads(row[2])
                raise HTTPException(409, 'This run is active, failed, or interrupted. No automatic retry was made; check saved results before starting another run.')
            if live:
                if db.execute("SELECT COUNT(*) FROM run_operations WHERE live=1 AND state='running'").fetchone()[0]:
                    raise HTTPException(409, 'A live run is active or interrupted. Resolve it before spending more credits.')
                count = db.execute('SELECT COUNT(*) FROM run_operations WHERE live=1 AND day=?', (day,)).fetchone()[0]
                if count >= limit:
                    raise HTTPException(429, 'Daily live-run limit reached. It covers both AutoZen workflows and counts failed attempts.')
            db.execute('INSERT INTO run_operations VALUES(?,?,?,?,?,NULL)', (key, fingerprint, day, int(live), 'running'))
        return None

    def finish(self, key, result):
        with self.connect() as db:
            db.execute("UPDATE run_operations SET state='completed',result=? WHERE key=?", (json.dumps(result, ensure_ascii=False), key))

    def fail(self, key):
        with self.connect() as db:
            db.execute("UPDATE run_operations SET state='failed' WHERE key=?", (key,))

    def get_result(self, job_id):
        with self.connect() as db:
            rows = db.execute("SELECT result FROM run_operations WHERE state='completed' ORDER BY rowid DESC LIMIT 1000").fetchall()
        for row in rows:
            result = json.loads(row[0])
            if result.get('meta', {}).get('job_id') == job_id:
                return result
        return None

    def used_today(self):
        day = datetime.now(timezone.utc).date().isoformat()
        with self.connect() as db:
            return db.execute('SELECT COUNT(*) FROM run_operations WHERE live=1 AND day=?', (day,)).fetchone()[0]
