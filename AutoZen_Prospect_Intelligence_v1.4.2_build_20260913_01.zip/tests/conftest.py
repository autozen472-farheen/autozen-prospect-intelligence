"""All regression tests are offline. Any accidental real network call fails."""
import socket

import pytest

from app.adapters.live import FirecrawlSignalSource, FirecrawlHunterCompanySource
from app.schemas import WebsiteReview


@pytest.fixture(autouse=True)
def isolated_providers(monkeypatch, request):
    def deny_network(*args, **kwargs):
        raise AssertionError("Regression tests must not make real provider calls")

    monkeypatch.setattr(socket.socket, "connect", deny_network)
    monkeypatch.setattr(socket.socket, "connect_ex", deny_network)
    monkeypatch.setattr(socket, "getaddrinfo", deny_network)
    FirecrawlSignalSource._response_cache.clear()
    FirecrawlSignalSource._global_lock = None
    FirecrawlSignalSource._last_request_at = 0.0

    async def no_pacing(self):
        return None

    monkeypatch.setattr(FirecrawlSignalSource, "_wait_for_global_slot", no_pacing)
    # Legacy adapter tests isolate Hunter/search behavior with a synthetic site
    # verification double. v126 tests exercise the real website logic separately.
    if request.node.path.name != 'test_v126_websites.py':
        async def legacy_websites(self, items, eligible, brief):
            for item in items:
                if item.domain in eligible:
                    item.website = WebsiteReview(status='confirmed_supplier', country='United Arab Emirates')
            return 0, 0
        monkeypatch.setattr(FirecrawlHunterCompanySource, '_verify_websites', legacy_websites)
    yield
    FirecrawlSignalSource._response_cache.clear()
    FirecrawlSignalSource._global_lock = None
