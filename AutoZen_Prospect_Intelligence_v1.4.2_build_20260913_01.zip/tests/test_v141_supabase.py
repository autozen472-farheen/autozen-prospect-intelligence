"""Offline checks for the free Supabase persistence patch."""
from pathlib import Path

import httpx
import pytest
from fastapi import HTTPException

from app.config import Settings
from app.supabase_backend import (
    SupabaseClient,
    SupabaseError,
    SupabaseRunLedger,
    SupabaseStore,
)


def test_storage_backend_auto_selects_supabase_only_with_both_private_values():
    assert Settings(_env_file=None).resolved_storage_backend == "sqlite"
    assert Settings(
        _env_file=None,
        supabase_url="https://project.supabase.co",
        supabase_service_role_key="private-test-key",
    ).resolved_storage_backend == "supabase"
    with pytest.raises(ValueError):
        Settings(_env_file=None, storage_backend="supabase", supabase_url="https://project.supabase.co")


def test_supabase_http_errors_are_sanitized(monkeypatch):
    secret = "service-role-secret-value"

    def reject(*args, **kwargs):
        request = httpx.Request("GET", "https://project.supabase.co/rest/v1/test")
        return httpx.Response(401, request=request, text=f"invalid token {secret}")

    monkeypatch.setattr(httpx, "request", reject)
    client = SupabaseClient("https://project.supabase.co", secret)
    with pytest.raises(SupabaseError) as caught:
        client.rows("test", {"select": "*"})
    assert secret not in str(caught.value)
    assert "HTTP 401" in str(caught.value)


def test_new_secret_key_is_not_misused_as_a_bearer_jwt():
    current = SupabaseClient("https://project.supabase.co", "sb_secret_private-test-key")
    legacy = SupabaseClient("https://project.supabase.co", "legacy-jwt-test-key")
    assert "Authorization" not in current.headers
    assert legacy.headers["Authorization"] == "Bearer legacy-jwt-test-key"


class FakeStoreClient:
    def __init__(self):
        self.companies: set[str] = set()
        self.upserts: list[tuple[str, dict, str]] = []
        self.occurrences: list[tuple[str, dict, str]] = []

    def rpc(self, function, payload):
        if function == "autozen_upsert_company":
            domain = payload["p_domain"]
            created = domain not in self.companies
            self.companies.add(domain)
            return {"created": created}
        if function == "autozen_prospect_count":
            return len(self.companies)
        raise AssertionError(function)

    def upsert(self, table, payload, conflict):
        self.upserts.append((table, payload, conflict))

    def insert_ignore(self, table, payload, conflict):
        self.occurrences.append((table, payload, conflict))


def discovery(job="global_test", domain="clinic.test"):
    return {
        "request": {"niche": "Aesthetic clinics"},
        "meta": {
            "job_id": job,
            "mode": "live",
            "discovery": {
                "candidates": [
                    {
                        "domain": domain,
                        "source_title": "Clinic Test",
                        "source_url": f"https://{domain}/",
                        "snippet": "Aesthetic clinic in Dubai",
                    }
                ]
            },
        },
    }


def test_supabase_discovery_deduplicates_and_saves_audit_source():
    store = SupabaseStore("https://project.supabase.co", "private-test-key")
    fake = FakeStoreClient()
    store.client = fake
    first = store.save_discovery(discovery())
    second = store.save_discovery(discovery(job="global_again", domain="www.clinic.test"))
    assert first == {"new_companies": 1, "existing_companies": 0, "database_total": 1}
    assert second == {"new_companies": 0, "existing_companies": 1, "database_total": 1}
    assert fake.upserts[0][0] == "autozen_prospect_sources"
    assert fake.occurrences[0][0] == "autozen_prospect_occurrences"


class FakeLedgerClient:
    def __init__(self, action):
        self.action = action

    def rpc(self, function, payload):
        assert function == "autozen_reserve_run"
        return self.action


@pytest.mark.parametrize(
    ("action", "status"),
    [
        ({"action": "different_inputs"}, 409),
        ({"action": "active_or_interrupted"}, 409),
        ({"action": "live_run_active"}, 409),
        ({"action": "daily_limit"}, 429),
    ],
)
def test_supabase_ledger_maps_atomic_reservation_results(action, status):
    ledger = SupabaseRunLedger("https://project.supabase.co", "private-test-key")
    ledger.client = FakeLedgerClient(action)
    with pytest.raises(HTTPException) as caught:
        ledger.reserve("valid-request-key-123", "/global", {"x": 1}, True, 1)
    assert caught.value.status_code == status


def test_supabase_schema_is_private_and_has_atomic_run_guard():
    schema = (Path(__file__).parents[1] / "supabase_schema.sql").read_text(encoding="utf-8")
    assert "enable row level security" in schema.lower()
    assert "revoke all on public.autozen_prospect_companies from anon, authenticated" in schema.lower()
    assert "pg_advisory_xact_lock" in schema
    assert "autozen_reserve_run" in schema
