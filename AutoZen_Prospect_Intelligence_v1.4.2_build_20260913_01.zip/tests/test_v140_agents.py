"""Two-agent handoff, evidence grading and prospect persistence; offline only."""
import asyncio

from app.adapters.live import FirecrawlSignalSource, HunterCompanySource
from app.discovery import assess_result, discovery_bodies
from app.roles import role_priority
from app.schemas import (
    CompanyCandidate, Contact, DeliveryMeta, EmailStatus, EmailType, Evidence,
    LeadDelivery, LeadRecord, LeadRequest, Narrative, ProspectAssessment,
    ScoreBreakdown, SignalType,
)
from app.scoring import grade_for_score, score_candidate
from app.store import SQLiteStore
from app.website_verification import verify_website


def discovery(job="global_test", domain="clinic.test"):
    return {
        "request": {"niche": "Aesthetic clinics"},
        "meta": {
            "job_id": job, "mode": "live",
            "discovery": {"candidates": [{
                "domain": domain, "source_title": "Clinic Test",
                "source_url": f"https://{domain}/", "snippet": "Aesthetic clinic in Dubai",
                "requested_locations": ["Dubai, United Arab Emirates"],
            }]},
        },
    }


def test_discovery_deduplicates_by_domain_and_creates_database_handoff(tmp_path):
    store = SQLiteStore(tmp_path / "prospects.db")
    first = store.save_discovery(discovery())
    second = store.save_discovery(discovery(job="global_again", domain="www.clinic.test"))
    assert first == {"new_companies": 1, "existing_companies": 0, "database_total": 1}
    assert second == {"new_companies": 0, "existing_companies": 1, "database_total": 1}
    rows = store.list_prospects()
    assert rows[0]["domain"] == "clinic.test" and rows[0]["seen_count"] == 2
    seeds, missing = store.saved_discovery(["https://www.clinic.test/path"])
    assert len(seeds) == 1 and not missing and "clinic.test" in seeds[0].source_url


def test_demo_discovery_does_not_pollute_real_database(tmp_path):
    store = SQLiteStore(tmp_path / "prospects.db")
    value = discovery(domain="demo-business-1.example")
    value["meta"]["mode"] = "demo"
    assert store.save_discovery(value)["database_total"] == 0


def test_qualification_persists_grade_contact_evidence_and_reason(tmp_path):
    store = SQLiteStore(tmp_path / "prospects.db")
    store.save_discovery(discovery())
    company = CompanyCandidate(
        provider_id="clinic.test", name="Clinic Test", domain="clinic.test",
        website="https://clinic.test/", industry="Aesthetic clinic", city="Dubai",
        country="United Arab Emirates", employee_count=25, source_provider="first_party",
        source_url="https://clinic.test/about",
    )
    contact = Contact(name="Ava Owner", title="Owner", email="ava@clinic.test",
                      email_status=EmailStatus.VERIFIED, email_type=EmailType.PERSON_WORK,
                      source_provider="hunter", source_url="https://clinic.test/team")
    evidence = [Evidence(signal_type=SignalType.BOOKING_CONSULTATION,
                         title="Book a consultation", url="https://clinic.test/book",
                         snippet="Book an aesthetic consultation", source_provider="first_party", confidence=.9)]
    score = ScoreBreakdown(icp_fit=30, commercial_value=20, quotation_rfq=15,
                           reachability=15, evidence_quality=10, total=90)
    lead = LeadRecord(rank=1, company=company, contact=contact, evidence=evidence,
                      score=score, narrative=Narrative(why_now="Verified booking route.",
                      outreach_hook="Reference the booking workflow.", confidence=.9),
                      grade="A+", qualification_reason="Strong ICP and verified buyer workflow.")
    request = LeadRequest(industry="Aesthetic clinics", geographies=["Dubai"], desired_count=1)
    delivery = LeadDelivery(request=request, leads=[lead], meta=DeliveryMeta(
        job_id="leadjob_test", mode="live", requested_count=1, candidates_considered=1,
        qualified_count=1, duration_ms=1, assessments=[ProspectAssessment(
            domain="clinic.test", company_name="Clinic Test", status="qualified",
            grade="A+", score=90, qualification_reason="Strong ICP and verified buyer workflow.",
            evidence_urls=["https://clinic.test/book"], unknowns=[],
        )],
    ))
    store.save_delivery(delivery)
    saved = store.get_prospect("clinic.test")
    assert saved["grade"] == "A+" and saved["score"] == 90
    assert saved["qualification_reason"].startswith("Strong ICP")
    assert saved["people"][0]["email"] == "ava@clinic.test"
    assert saved["evidence"][0]["source_url"] == "https://clinic.test/book"


def test_generic_clinic_website_can_be_confirmed_with_first_party_facts():
    html = '''<title>Clinic Test Dubai</title>
    <script type="application/ld+json">{"@type":"MedicalBusiness","url":"https://clinic.test","name":"Clinic Test","numberOfEmployees":25,"address":{"addressLocality":"Dubai","addressCountry":"AE"}}</script>
    <h1>Aesthetic clinic</h1><p>Book an appointment or consultation with our team.</p><a href="/contact">Contact us</a>'''
    class Reader:
        requests = 1
        async def read(self, url, domain):
            return type("Page", (), {"url": "https://clinic.test/", "text": html})()
    item = type("Item", (), {"domain": "clinic.test", "source_url": "https://clinic.test/"})()
    request = LeadRequest(industry="Aesthetic clinics", geographies=["Dubai"],
                          employee_min=5, employee_max=50,
                          desired_signals=[SignalType.BOOKING_CONSULTATION])
    review = asyncio.run(verify_website(item, request, Reader()))
    assert review.status == "confirmed_business"
    assert review.employee_count == 25 and review.city == "Dubai"
    assert SignalType.BOOKING_CONSULTATION in {item.signal_type for item in review.signals}


def test_workflow_classification_and_generic_scoring_are_evidence_backed():
    classify = FirecrawlSignalSource._classify
    assert classify("Book a consultation today") == SignalType.BOOKING_CONSULTATION
    assert classify("Request a free estimate and site visit") == SignalType.SITE_VISIT_ESTIMATE
    assert classify("Contact sales using our enquiry form") == SignalType.ENQUIRY_FUNNEL
    request = LeadRequest(industry="Aesthetic clinics", geographies=["Dubai"],
                          employee_min=5, employee_max=50,
                          desired_signals=[SignalType.BOOKING_CONSULTATION])
    company = CompanyCandidate(provider_id="1", name="Clinic", domain="clinic.test",
        website="https://clinic.test", industry="Medical spa and aesthetic clinic",
        city="Dubai", country="United Arab Emirates", employee_count=20, source_provider="test")
    evidence = [Evidence(signal_type=SignalType.BOOKING_CONSULTATION, title="Booking",
        url="https://clinic.test/book", snippet="Book", source_provider="test", confidence=1)]
    contact = Contact(name="Owner", title="Owner", email="owner@clinic.test",
        email_status="verified", email_type="person_work", source_provider="test")
    score = score_candidate(request, company, evidence, contact)
    assert score.icp_fit == 30 and score.quotation_rfq == 12 and score.total >= 80


def test_buyer_hierarchy_and_grade_boundaries_are_stable():
    assert role_priority("Owner") > role_priority("Founder") > role_priority("Managing Director")
    assert role_priority("Managing Director") > role_priority("General Manager") > role_priority("Sales Director")
    assert grade_for_score(90, 40) == "A+"
    assert grade_for_score(89, 40) == "A"
    assert grade_for_score(79, 40) == "B"
    assert grade_for_score(39, 40) == "Reject"


def test_hunter_contact_rank_prefers_owner_over_sales_director():
    request = LeadRequest(target_roles=["Owner", "Sales Director"])
    owner = {"position": "Owner", "decision_maker": True,
             "verification": {"status": "valid"}, "confidence": 80}
    sales = {"position": "Sales Director", "decision_maker": True,
             "verification": {"status": "valid"}, "confidence": 99}
    assert HunterCompanySource._contact_rank(owner, request) > HunterCompanySource._contact_rank(sales, request)


def test_non_industrial_direct_discovery_uses_business_queries_and_screening():
    request = LeadRequest(industry="Aesthetic clinics", geographies=["Dubai"],
                          employee_min=5, employee_max=50)
    queries = [item["query"] for item in discovery_bodies(request)]
    assert all("supplier distributor" not in query for query in queries)
    result = assess_result({"url": "https://clinic.test/", "title": "Aesthetic Clinic Dubai",
                            "snippet": "Book an appointment. Contact us."}, request)
    assert result.eligible and result.company_like
