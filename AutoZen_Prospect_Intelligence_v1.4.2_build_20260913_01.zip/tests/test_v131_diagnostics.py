"""Real adapters with simulated transports only; tests/conftest.py blocks sockets."""
import asyncio
import json
import socket
import ssl

import httpx
import pytest

from app import access, global_discovery, main
from app.config import Settings
from app.global_discovery import GlobalRequest, discover_global, firecrawl_search, queries_for
from app.public_web import WebReadError
from app.search_diagnostics import SearchFailure, describe_search_error


SECRET = 'OFFLINE_SECRET_DO_NOT_SERIALIZE'


def brief():
    return GlobalRequest(niche='Industrial Distributor', locations=['Australia', 'United States'],
                         mode='live', website_checks=1)


def transport(monkeypatch, handler):
    original = httpx.AsyncClient
    options = []
    def client(**kw):
        options.append(kw)
        return original(transport=httpx.MockTransport(handler), **kw)
    monkeypatch.setattr(httpx, 'AsyncClient', client)
    return options


@pytest.mark.parametrize('kind,code', [
    (httpx.ConnectTimeout, 'search_connect_timeout'),
    (httpx.ReadTimeout, 'search_read_timeout'),
    (httpx.WriteTimeout, 'search_write_timeout'),
    (httpx.PoolTimeout, 'search_pool_timeout'),
    (httpx.ConnectError, 'search_connect_error'),
    (httpx.ReadError, 'search_read_error'),
    (httpx.WriteError, 'search_write_error'),
    (httpx.CloseError, 'search_close_error'),
    (httpx.LocalProtocolError, 'search_local_protocol_error'),
    (httpx.RemoteProtocolError, 'search_remote_protocol_error'),
    (httpx.ProxyError, 'search_proxy_error'),
    (httpx.UnsupportedProtocol, 'search_unsupported_protocol'),
    (httpx.DecodingError, 'search_decoding_error'),
    (httpx.TooManyRedirects, 'search_redirect_error'),
    (httpx.TimeoutException, 'search_timeout'),
    (httpx.NetworkError, 'search_network_error'),
    (httpx.ProtocolError, 'search_protocol_error'),
    (httpx.HTTPError, 'search_http_error'),
])
def test_exception_categories_timing_and_no_secret_leak(monkeypatch, caplog, kind, code):
    calls = []
    def fail(request):
        calls.append(request)
        raise kind(SECRET)
    options = transport(monkeypatch, fail)
    ticks = iter([1.0, 1.125])
    monkeypatch.setattr(global_discovery, 'perf_counter', lambda: next(ticks))
    result = asyncio.run(discover_global(brief(), api_key=SECRET))
    query = result['meta']['discovery']['queries'][0]
    detail = query['diagnostic']
    assert query['error'] == code and detail['code'] == code
    assert detail['error_type'] == kind.__name__
    assert detail['stage'] == 'awaiting_response_headers'
    assert detail['http_status'] is None and detail['response_received'] is False
    assert detail['underlying_cause'] == 'unknown'
    assert query['elapsed_ms'] == 125 and query['started_at'].endswith('+00:00')
    assert detail['client_timeout_seconds'] == 25 and detail['provider_timeout_ms'] == 20000
    assert detail['retry_attempted'] is False
    assert len(calls) == 1 and len(result['meta']['discovery']['queries']) == 1
    assert result['meta']['usage'] == {'search_requests': 1, 'search_credits_estimated': 2,
        'public_website_requests': 0, 'hunter_requests': 0, 'openai_requests': 0}
    assert result['meta']['candidate_count'] == 0 and result['leads'] == []
    assert SECRET not in json.dumps(result) and SECRET not in caplog.text
    assert 'Industrial Distributor' not in caplog.text
    assert 'global_search_failure' in caplog.text and code in caplog.text
    assert options == [{'timeout': 25, 'follow_redirects': False, 'trust_env': False}]
    assert json.loads(calls[0].content) == queries_for(brief())[0]


@pytest.mark.parametrize('cause,code', [
    (socket.gaierror(SECRET), 'dns_resolution_error'),
    (ssl.SSLCertVerificationError(SECRET), 'tls_certificate_verification_error'),
    (ssl.SSLError(SECRET), 'tls_error'),
    (ConnectionRefusedError(SECRET), 'connection_refused'),
    (ConnectionResetError(SECRET), 'connection_reset'),
])
def test_only_known_underlying_exception_categories_are_reported(monkeypatch, cause, code):
    def fail(request):
        wrapped = RuntimeError(SECRET)
        wrapped.__cause__ = cause
        raise httpx.ConnectError(SECRET) from wrapped
    transport(monkeypatch, fail)
    result = asyncio.run(discover_global(brief(), api_key=SECRET))
    detail = result['meta']['discovery']['queries'][0]['diagnostic']
    assert detail['underlying_cause'] == code
    assert detail['code'] == 'search_connect_error'
    assert SECRET not in json.dumps(result)


def test_no_cause_guesses_from_messages_or_suppressed_context():
    error = httpx.ConnectError('DNS failed; certificate problem; ' + SECRET)
    assert describe_search_error(error)['underlying_cause'] == 'unknown'
    error.__context__ = socket.gaierror(SECRET)
    assert describe_search_error(error)['underlying_cause'] == 'dns_resolution_error'
    error.__suppress_context__ = True
    assert describe_search_error(error)['underlying_cause'] == 'unknown'
    error.__cause__ = error
    assert describe_search_error(error)['underlying_cause'] == 'unknown'


def test_unknown_subclass_name_and_webread_message_are_not_serialized():
    private_class = type(SECRET, (httpx.ConnectError,), {})
    assert describe_search_error(private_class(SECRET))['error_type'] == 'ConnectError'
    unknown = describe_search_error(WebReadError(SECRET))
    assert unknown['code'] == 'search_failed' and SECRET not in json.dumps(unknown)
    assert describe_search_error(WebReadError('firecrawl_http_402 ' + SECRET))['code'] == 'search_failed'


def test_http_status_exception_classified_without_using_response_body():
    request = httpx.Request('POST', 'https://provider.example', headers={'Authorization': SECRET})
    response = httpx.Response(500, text=SECRET)
    detail = describe_search_error(httpx.HTTPStatusError(SECRET, request=request, response=response))
    assert detail['code'] == 'search_http_status_error' and SECRET not in json.dumps(detail)


def test_timeout_during_body_records_received_status(monkeypatch):
    class Interrupted(httpx.AsyncByteStream):
        async def __aiter__(self):
            yield b'{"success":'
            raise httpx.ReadTimeout(SECRET)
    transport(monkeypatch, lambda request: httpx.Response(200, stream=Interrupted()))
    result = asyncio.run(discover_global(brief(), api_key=SECRET))
    detail = result['meta']['discovery']['queries'][0]['diagnostic']
    assert detail['code'] == 'search_read_timeout'
    assert detail['stage'] == 'reading_response_body'
    assert detail['http_status'] == 200 and detail['response_received'] is True


@pytest.mark.parametrize('status,body,code,stage', [
    (401, SECRET, 'firecrawl_http_401', 'checking_response_status'),
    (402, SECRET, 'firecrawl_http_402', 'checking_response_status'),
    (429, SECRET, 'firecrawl_http_429', 'checking_response_status'),
    (503, SECRET, 'firecrawl_http_503', 'checking_response_status'),
    (200, SECRET, 'firecrawl_invalid_response', 'validating_response'),
    (200, '{"success":false}', 'firecrawl_unsuccessful_response', 'validating_response'),
    (200, '{"success":true,"data":null}', 'firecrawl_invalid_response', 'validating_response'),
    (200, 'x' * 2_000_001, 'firecrawl_response_too_large', 'reading_response_body'),
])
def test_http_and_payload_errors_keep_status_but_not_body(monkeypatch, status, body, code, stage):
    transport(monkeypatch, lambda request: httpx.Response(status, text=body))
    result = asyncio.run(discover_global(brief(), api_key=SECRET))
    detail = result['meta']['discovery']['queries'][0]['diagnostic']
    assert detail['code'] == code and detail['http_status'] == status
    assert detail['response_received'] is True and detail['stage'] == stage
    assert SECRET not in json.dumps(result)


def test_non_ascii_key_is_safe_error_without_sending(monkeypatch):
    calls = []
    transport(monkeypatch, lambda request: calls.append(request))
    result = asyncio.run(discover_global(brief(), api_key=SECRET + '\u200b'))
    detail = result['meta']['discovery']['queries'][0]['diagnostic']
    assert detail['code'] == 'search_encoding_error' and not calls
    assert SECRET not in json.dumps(result)


def test_success_records_timing_without_changing_search_or_contacts(monkeypatch):
    transport(monkeypatch, lambda request: httpx.Response(200, json={
        'success': True, 'data': {'web': [{'url': 'https://pump-supplier.com/', 'title': 'Supplier'}]}}))
    req = brief().model_copy(update={'locations': ['Australia'], 'country_codes': ['AU'], 'website_checks': 0})
    result = asyncio.run(discover_global(req, api_key=SECRET))
    query = result['meta']['discovery']['queries'][0]
    assert query['error'] is None and 'diagnostic' not in query
    assert query['elapsed_ms'] >= 0 and query['started_at'].endswith('+00:00')
    assert result['meta']['candidate_count'] == 1 and result['meta']['qualified_count'] == 0
    assert result['meta']['discovery']['candidates'][0]['status'] == 'needs_verification'


def test_failed_diagnostics_saved_replayed_and_count_towards_existing_cap(tmp_path, monkeypatch, caplog):
    password = 'offline-owner-password-only'
    settings = Settings(_env_file=None, app_environment='demo', data_mode='live', company_provider='auto',
        enable_live_runs=True, daily_live_run_limit=1, dashboard_username='owner', dashboard_password=password,
        firecrawl_api_key=SECRET, database_path=tmp_path/'jobs.db')
    monkeypatch.setattr(access, 'get_settings', lambda: settings)
    monkeypatch.setattr(main, 'get_settings', lambda: settings)
    attempts = []
    async def fail(key, body):
        attempts.append(body)
        raise SearchFailure(httpx.ReadTimeout(SECRET), 'awaiting_response_headers', None)
    monkeypatch.setattr(global_discovery, 'firecrawl_search', fail)
    async def scenario():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=main.app), base_url='https://offline') as client:
            payload = brief().model_dump()
            headers = {'Idempotency-Key': 'diagnostic-offline-12345'}
            route = '/v1/global/discover'
            first = await client.post(route, auth=('owner',password), json=payload, headers=headers)
            assert first.status_code == 200
            cached = await client.post(route, auth=('owner',password), json=payload, headers=headers)
            assert cached.json() == first.json()
            job = first.json()['meta']['job_id']
            assert (await client.get(f'/v1/global/jobs/{job}')).status_code == 401
            saved = await client.get(f'/v1/global/jobs/{job}', auth=('owner',password))
            assert saved.json() == first.json()
            assert saved.json()['meta']['discovery']['queries'][0]['error'] == 'search_read_timeout'
            blocked = await client.post(route, auth=('owner',password), json=payload,
                                       headers={'Idempotency-Key': 'another-offline-123456'})
            assert blocked.status_code == 429
            status = await client.get('/v1/status', auth=('owner',password))
            assert status.json()['live_runs_used_today'] == 1
            assert SECRET not in saved.text and password not in saved.text
    asyncio.run(scenario())
    assert len(attempts) == 1 and SECRET not in caplog.text and password not in caplog.text
