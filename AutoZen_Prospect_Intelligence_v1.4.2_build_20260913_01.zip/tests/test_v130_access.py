import asyncio
from pathlib import Path

import httpx
import pytest
from fastapi import HTTPException

from app import access, main
from app.config import Settings
from app.run_control import RunLedger


PASSWORD = 'test-only-long-password'


@pytest.fixture
def secured(tmp_path, monkeypatch):
    settings = Settings(_env_file=None, app_environment='demo', data_mode='live', company_provider='auto',
                        dashboard_username='owner', dashboard_password=PASSWORD, database_path=tmp_path/'app.db', firecrawl_api_key='test-key')
    monkeypatch.setattr(access, 'get_settings', lambda: settings)
    monkeypatch.setattr(main, 'get_settings', lambda: settings)
    return settings


async def client_request(path, method='GET', auth=None, json=None, headers=None):
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=main.app), base_url='https://offline') as client:
        return await client.request(method, path, auth=auth, json=json, headers=headers)


@pytest.mark.parametrize('path', ['/', '/global', '/v1/status', '/v1/readiness', '/v1/jobs', '/docs', '/static/global.js'])
def test_all_private_surfaces_require_login(secured, path):
    response = asyncio.run(client_request(path))
    assert response.status_code == 401 and 'Basic' in response.headers['www-authenticate']


def test_health_public_and_owner_can_open_both_workflows(secured):
    assert asyncio.run(client_request('/health')).status_code == 200
    for route in ['/', '/global', '/v1/status']:
        response = asyncio.run(client_request(route, auth=('owner', PASSWORD)))
        assert response.status_code == 200 and response.headers['x-frame-options'] == 'DENY'
    assert asyncio.run(client_request('/', auth=('owner', 'wrong'))).status_code == 401


def test_missing_password_fails_closed(secured):
    secured.dashboard_password = None
    assert asyncio.run(client_request('/')).status_code == 503
    assert asyncio.run(client_request('/health')).status_code == 200


def test_demo_can_run_but_live_cannot_spend_when_disabled(secured, monkeypatch):
    payload = {'niche':'Roofing','locations':['United States'], 'mode':'demo'}
    headers = {'Idempotency-Key':'demo-request-123456'}
    demo = asyncio.run(client_request('/v1/global/discover', 'POST', ('owner',PASSWORD), payload, headers))
    assert demo.status_code == 200 and demo.json()['meta']['usage']['search_requests'] == 0
    live = asyncio.run(client_request('/v1/global/discover', 'POST', ('owner',PASSWORD), payload | {'mode':'live'}, {'Idempotency-Key':'live-request-123456'}))
    assert live.status_code == 403
    prospect = asyncio.run(client_request('/v1/leads/generate', 'POST', ('owner',PASSWORD), {}, {'Idempotency-Key':'prospect-1234567890'}))
    assert prospect.status_code == 403


@pytest.mark.parametrize('headers', [{'Origin':'https://attacker.example'}, {'Sec-Fetch-Site':'cross-site'}, {'Origin':'null'}])
def test_cross_site_writes_blocked(secured, headers):
    response = asyncio.run(client_request('/v1/global/estimate', 'POST', ('owner',PASSWORD), {'niche':'Roofing','locations':['United States']}, headers))
    assert response.status_code == 403


def test_request_size_limit(secured):
    response = asyncio.run(client_request('/v1/global/estimate', 'POST', ('owner',PASSWORD), {'padding':'x'*2_000_001}))
    assert response.status_code == 413


def test_duplicate_same_key_returns_saved_result_and_conflict_stops(secured):
    payload = {'niche':'Roofing','locations':['United States'],'mode':'demo'}
    def call(data):
        return asyncio.run(client_request('/v1/global/discover','POST',('owner',PASSWORD),data,{'Idempotency-Key':'same-request-1234567'}))
    first, second = call(payload), call(payload)
    assert first.status_code == 200 and first.json() == second.json()
    assert call(payload | {'niche':'Dentists'}).status_code == 409
    job = first.json()['meta']['job_id']
    exported = asyncio.run(client_request(f'/v1/global/jobs/{job}/research.csv', auth=('owner',PASSWORD)))
    assert exported.status_code == 200 and 'not_verified' in exported.text
    assert asyncio.run(client_request(f'/v1/global/jobs/{job}')).status_code == 401


def test_missing_idempotency_key_is_rejected(secured):
    response = asyncio.run(client_request('/v1/global/discover','POST',('owner',PASSWORD),{'niche':'Roofing','locations':['United States']}))
    assert response.status_code == 400


def test_ledger_reservation_survives_new_instance_and_shared_cap(tmp_path):
    path = tmp_path/'ledger.db'
    ledger = RunLedger(path)
    assert ledger.reserve('global-request-12345','/global', {'x':1}, True, 1) is None
    with pytest.raises(HTTPException) as blocked:
        RunLedger(path).reserve('prospect-request-123','/prospect', {'x':1}, True, 1)
    assert blocked.value.status_code == 409
    ledger.fail('global-request-12345')
    with pytest.raises(HTTPException) as capped:
        RunLedger(path).reserve('prospect-request-123','/prospect', {'x':1}, True, 1)
    assert capped.value.status_code == 429
    assert RunLedger(path).used_today() == 1


def test_complete_results_are_idempotent_after_restart(tmp_path):
    path=tmp_path/'ledger.db'
    first=RunLedger(path)
    first.reserve('saved-request-123456','/global',{'x':1},True,1)
    first.finish('saved-request-123456',{'meta':{'job_id':'global_example'}})
    second=RunLedger(path)
    assert second.reserve('saved-request-123456','/global',{'x':1},True,1)['meta']['job_id']=='global_example'
    assert second.get_result('global_example')['meta']['job_id']=='global_example'


def test_live_route_limit_is_shared_with_supplier_route(secured, monkeypatch):
    secured.enable_live_runs = True
    calls = []
    async def discovery(request, api_key):
        calls.append(request.mode)
        return {'meta':{'job_id':'global_offline_live_test','mode':'live'}, 'leads':[]}
    monkeypatch.setattr(main,'discover_global',discovery)
    request={'niche':'Roofing','locations':['United States'],'mode':'live'}
    first=asyncio.run(client_request('/v1/global/discover','POST',('owner',PASSWORD),request,{'Idempotency-Key':'approved-live-123456'}))
    assert first.status_code==200 and calls==['live']
    cached=asyncio.run(client_request('/v1/global/discover','POST',('owner',PASSWORD),request,{'Idempotency-Key':'approved-live-123456'}))
    assert cached.json()==first.json() and len(calls)==1
    blocked=asyncio.run(client_request('/v1/leads/generate','POST',('owner',PASSWORD),{}, {'Idempotency-Key':'supplier-run-123456'}))
    assert blocked.status_code==429
