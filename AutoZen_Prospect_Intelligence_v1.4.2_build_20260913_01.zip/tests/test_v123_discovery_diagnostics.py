import asyncio
import httpx

from app.adapters.live import FirecrawlHunterCompanySource
from app.schemas import LeadRequest


def brief():
    return LeadRequest(
        industry='Industrial equipment distributors',
        products_or_services='pumps, valves',
        geographies=['United Arab Emirates'],
        employee_min=5,
        employee_max=500,
        desired_count=1,
        minimum_score=60,
    )


def test_v123_normalizes_list_shaped_firecrawl_data():
    payload={'data':[{'url':'https://alpha.example','title':'Pump distributor','description':'Pumps supplier RFQ'}]}
    rows=FirecrawlHunterCompanySource._rows_from_search_payload(payload)
    assert len(rows)==1 and rows[0]['url']=='https://alpha.example'


def test_v123_zero_focused_results_use_one_fallback_and_no_hunter_discover():
    search_calls=0
    company_calls=0
    hunter_discover_calls=0
    def handler(req: httpx.Request):
        nonlocal search_calls, company_calls, hunter_discover_calls
        if req.url.path.endswith('/search'):
            search_calls += 1
            if search_calls < 5:
                return httpx.Response(200, json={'data': {'web': []}})
            return httpx.Response(200, json={'data': [{'url':'https://fallback.example','title':'Pump valve distributor UAE','description':'Industrial pump supplier request a quote RFQ'}]})
        if req.url.path.endswith('/companies/find'):
            company_calls += 1
            domain=req.url.params['domain']
            return httpx.Response(200,json={'data':{'id':domain,'name':domain,'domain':domain,'metrics':{'employees':'11-50'},'geo':{'country':'United Arab Emirates'},'category':{'industry':'Wholesale'}}})
        if req.url.path.endswith('/discover'):
            hunter_discover_calls += 1
        return httpx.Response(404)
    source=FirecrawlHunterCompanySource('hunter','firecrawl',max_company_enrichments=3,transport=httpx.MockTransport(handler))
    source.web_discovery.min_interval_seconds=0
    companies=asyncio.run(source.discover(brief(),20))
    assert search_calls == 5
    assert company_calls == 1
    assert hunter_discover_calls == 0
    assert len(companies) == 1
    assert source.last_discovery_diagnostics['fallback_used'] is True
    assert source.last_discovery_diagnostics['raw_results'] == 1
    assert source.last_discovery_diagnostics['usable_domains'] == 1
    assert source.last_discovery_diagnostics['hunter_enrichment_attempts'] == 1


def test_v123_zero_all_web_results_does_not_call_hunter():
    from app.adapters.live import FirecrawlSignalSource
    FirecrawlSignalSource._response_cache.clear()
    hunter_calls=0
    def handler(req: httpx.Request):
        nonlocal hunter_calls
        if req.url.path.endswith('/search'):
            return httpx.Response(200,json={'data':{'web':[]}})
        if '/companies/' in req.url.path or req.url.path.endswith('/discover'):
            hunter_calls += 1
        return httpx.Response(404)
    source=FirecrawlHunterCompanySource('hunter','firecrawl',max_company_enrichments=3,transport=httpx.MockTransport(handler))
    source.web_discovery.min_interval_seconds=0
    companies=asyncio.run(source.discover(brief(),20))
    assert companies == []
    assert hunter_calls == 0
    assert source.last_discovery_diagnostics['queries_attempted'] == 5
