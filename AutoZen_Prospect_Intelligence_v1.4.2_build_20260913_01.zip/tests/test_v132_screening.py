"""Saved search-text replay and synthetic boundaries only; no live providers."""
import asyncio
import csv
import io
import json
from pathlib import Path
from urllib.parse import urlsplit

import httpx
import pytest

from app import access, main
from app.config import Settings
from app.discovery import assess_result
from app.factory import build_pipeline
from app.global_discovery import GlobalRequest, discover_global, research_csv
from app.public_web import Page
from app.result_screening import screen_source
from app.run_control import RunLedger
from app.schemas import LeadRequest

FIXTURE = Path(__file__).parent / 'fixtures' / 'global_australia_v131.json'


def saved():
    return json.loads(FIXTURE.read_text())


def seeds():
    return [{key: row[key] for key in ('source_url', 'source_title', 'snippet')}
            for row in saved()['meta']['discovery']['candidates']]


def offline_request(**changes):
    return GlobalRequest(**(saved()['request'] | {'mode': 'import', 'saved_discovery': seeds()} | changes))


async def forbidden(*args, **kwargs):
    raise AssertionError('No network call is allowed')


def test_saved_australia_separates_three_candidates_reference_and_exclusion():
    result = asyncio.run(discover_global(offline_request(), search=forbidden))
    meta, report = result['meta'], result['meta']['discovery']
    assert meta['candidate_count'] == 3 and meta['reference_count'] == 1
    assert [row['domain'] for row in report['candidates']] == ['wileyxaustralia.com.au', 'banlaw.com', 'bonfiglioli.com']
    assert report['raw_results'] == 5 and report['excluded_results'] == 1 and report['duplicate_results'] == 0
    assert report['excluded_entries'][0]['source_domain'] == 'aer.gov.au'
    assert report['excluded_entries'][0]['reason'] == 'government_source'
    reference = report['references'][0]
    assert reference['source_domain'] == 'atlascopco.com'
    assert reference['mentioned_business'] == 'NCPS Industrial'
    assert reference['prospect_domain'] is None and 'domain' not in reference
    assert reference['name_status'] == 'unverified_title_text'
    assert reference['status'] == 'reference_only'
    assert 'facts' not in reference
    assert all(value == 0 for value in meta['usage'].values())
    assert meta['qualified_count'] == 0 and result['leads'] == []
    for row in report['candidates']:
        assert row['status'] == 'needs_verification'
        assert row['website_status'] == 'not_checked' and not row['facts']
        assert row['requested_locations'] == []  # Imported geography is not trusted.


def test_live_path_uses_same_filter_with_only_one_simulated_search():
    calls = []
    async def simulated(key, body):
        calls.append(body)
        return seeds()
    req = GlobalRequest(**saved()['request'])
    result = asyncio.run(discover_global(req, api_key='offline-only', search=simulated))
    assert len(calls) == 1 and calls[0]['limit'] == 5
    assert result['meta']['usage']['search_requests'] == 1
    assert result['meta']['candidate_count'] == 3
    assert result['meta']['discovery']['references'][0]['requested_locations'] == ['Australia']


def test_no_website_read_for_reference_or_excluded_source():
    class Reader:
        requests = 0
        domains = []
        async def read(self, url, domain):
            self.requests += 1
            self.domains.append(domain)
            assert domain not in {'aer.gov.au', 'atlascopco.com', 'ncpsindustrial.com.au'}
            return Page(url, 200, '<p>Synthetic business page; no published contacts.</p>')
    reader = Reader()
    result = asyncio.run(discover_global(offline_request(website_checks=5), reader=reader, search=forbidden))
    assert reader.requests == 3
    assert reader.domains == ['wileyxaustralia.com.au', 'banlaw.com', 'bonfiglioli.com']
    assert result['meta']['discovery']['references'][0]['website_status'] == 'not_checked'
    assert all(not row['facts'] for row in result['meta']['discovery']['candidates'])


def test_csv_only_contains_unqualified_candidate_rows():
    result = asyncio.run(discover_global(offline_request(), search=forbidden))
    rows = list(csv.DictReader(io.StringIO(research_csv(result))))
    assert len(rows) == 3
    assert all(row['status'] == 'needs_verification' and row['contact_verification'] == 'not_verified' for row in rows)
    assert 'atlascopco.com' not in research_csv(result) and 'aer.gov.au' not in research_csv(result)


@pytest.mark.parametrize('domain', ['aer.gov.au', 'agency.gov', 'sub.agency.gov', 'agency.gov.uk',
                                   'agency.gov.ae', 'agency.gov.in', 'agency.govt.nz'])
def test_known_government_suffixes(domain):
    assert screen_source(domain, f'https://{domain}/', 'Who is your distributor?').disposition == 'excluded'


@pytest.mark.parametrize('domain', ['gov.au.supplier.com', 'gov-supplies.com', 'agencygov.au',
                                   'government-tools.com', 'govt.nz.supplier.com', 'roofers.com.au'])
def test_business_hostnames_are_not_excluded_by_substring(domain):
    assert screen_source(domain, f'https://{domain}/', 'Supplier of government equipment').disposition == 'candidate'


@pytest.mark.parametrize('url,title,snippet', [
    ('https://maker.com/dealers/some-company', 'Dealer profile', ''),
    ('https://maker.com/authorized-tools-distributors-some-company', 'Some Company — Authorized Distributor', ''),
    ('https://maker.com/authorised-distributors/some-company', 'Some Company – Authorised Distributor', ''),
    ('https://maker.com/contact', 'Find a distributor', ''),
    ('https://maker.com/contact', 'Dealer locator', ''),
    ('https://maker.com/distributor-locator/', 'Where to buy', ''),
    ('https://maker.com/profile', 'Some Company - Certified Dealer', 'Email sales@some-company.com'),
])
def test_reference_patterns_are_not_hardcoded_to_australia(url, title, snippet):
    assert screen_source(urlsplit(url).hostname, url, title, snippet).disposition == 'reference'


@pytest.mark.parametrize('title,snippet', [
    ('Contact Us - Official Distributor for Industrial Equipment', ''),
    ('Some Company - Authorized Distributor', 'sales@some-company.com'),
    ('Some Company - Authorized Distributor', 'sales@au.some-company.com'),
    ('Australian pump distributor', 'We sell products made by leading manufacturers.'),
    ('Contact Us - Banlaw', 'Australia / International'),
    ('Find Your Contact: Sales & Distributors | Bonfiglioli Australia', ''),
])
def test_own_company_pages_are_not_rejected_just_for_mentioning_distributors(title, snippet):
    assert screen_source('some-company.com', 'https://some-company.com/contact/', title, snippet).disposition == 'candidate'


def test_same_manufacturer_can_have_own_candidate_and_two_separate_references():
    rows = [
        {'source_url': 'https://maker.com/', 'source_title': 'Maker company'},
        {'source_url': 'https://maker.com/dealers/alpha', 'source_title': 'Alpha — Authorized Distributor'},
        {'source_url': 'https://maker.com/dealers/beta', 'source_title': 'Beta — Authorized Distributor'},
    ]
    async def search(*args):
        return rows
    req = GlobalRequest(niche='Pumps', locations=['Australia', 'United States'], mode='live', website_checks=0)
    result = asyncio.run(discover_global(req, api_key='offline-only', search=search))
    report = result['meta']['discovery']
    assert len(report['candidates']) == 1 and len(report['references']) == 2
    assert report['duplicate_results'] == 3
    assert all(row['requested_locations'] == ['Australia', 'United States'] for row in report['references'])


def test_import_recomputes_classifications_and_does_not_trust_facts():
    rows = seeds()
    rows[1].update(domain='ncpsindustrial.com.au', prospect_domain='ncpsindustrial.com.au', status='qualified',
                   facts=[{'field': 'email', 'value': 'invented@example.com'}])
    result = asyncio.run(discover_global(offline_request(saved_discovery=rows), search=forbidden))
    assert result['meta']['discovery']['references'][0]['prospect_domain'] is None
    assert 'invented@example.com' not in json.dumps(result)


def test_filtered_only_output_is_honest_and_csv_has_header_only():
    result = asyncio.run(discover_global(offline_request(saved_discovery=[seeds()[1], seeds()[2]]), search=forbidden))
    assert result['meta']['candidate_count'] == 0
    assert len(result['meta']['discovery']['references']) == 1
    assert list(csv.DictReader(io.StringIO(research_csv(result)))) == []
    assert any('screening' in message for message in result['meta']['warnings'])


@pytest.mark.parametrize('index,reason', [(1, 'distributor_reference'), (2, 'government_source')])
def test_supplier_handoff_rejects_unsafe_old_global_seeds(index, reason):
    row = seeds()[index]
    assessment = assess_result({'url': row['source_url'], 'title': row['source_title'], 'snippet': row['snippet']},
                               LeadRequest(industry='Industrial distributors', geographies=['Australia']))
    assert not assessment.eligible and not assessment.company_like
    assert assessment.reason == reason


def test_old_supplier_handoff_makes_no_provider_calls_for_reference_only_input():
    settings = Settings(_env_file=None, data_mode='live', company_provider='hunter', narrative_mode='template',
                        hunter_api_key='offline-hunter', firecrawl_api_key='offline-firecrawl')
    pipeline = build_pipeline(settings)
    source = pipeline.company_source.fallback
    source.web_discovery.search = forbidden
    async def no_reads(items, eligible, request):
        assert not items and not eligible
        return 0, 0
    source._verify_websites = no_reads
    def no_hunter(request):
        pytest.fail('Reference-only input must not call Hunter')
    source.transport = httpx.MockTransport(no_hunter)
    brief = LeadRequest(saved_discovery=[seeds()[1], seeds()[2]])
    batch = asyncio.run(source.discover_batch(brief, 3))
    assert batch.companies == [] and batch.diagnostics.excluded_results == 2
    assert batch.diagnostics.hunter_enrichment_attempts == 0
    assert not batch.diagnostics.fallback_used and not batch.diagnostics.queries


def test_authenticated_offline_replay_persists_audit_and_does_not_use_live_allowance(tmp_path, monkeypatch):
    password = 'offline-only-owner-password'
    settings = Settings(_env_file=None, data_mode='live', app_environment='demo',
                        enable_live_runs=False, dashboard_username='owner', dashboard_password=password,
                        database_path=tmp_path / 'app.db')
    monkeypatch.setattr(main, 'get_settings', lambda: settings)
    monkeypatch.setattr(access, 'get_settings', lambda: settings)
    async def scenario():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=main.app), base_url='https://offline') as client:
            response = await client.post('/v1/global/discover', json=offline_request().model_dump(),
                                         auth=('owner', password), headers={'Idempotency-Key': 'screening-offline-12345'})
            assert response.status_code == 200
            result = response.json()
            job = result['meta']['job_id']
            assert result['meta']['candidate_count'] == 3
            assert (await client.get(f'/v1/global/jobs/{job}')).status_code == 401
            assert (await client.get(f'/v1/global/jobs/{job}', auth=('owner', password))).json() == result
            exported = await client.get(f'/v1/global/jobs/{job}/research.csv', auth=('owner', password))
            assert len(list(csv.DictReader(io.StringIO(exported.text)))) == 3
            assert RunLedger(settings.database_path).used_today() == 0
    asyncio.run(scenario())
