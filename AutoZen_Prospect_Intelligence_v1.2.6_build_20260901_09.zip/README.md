# AutoZen Prospect Intelligence v1.2.6

Evidence-backed global B2B prospecting engine. It discovers companies, verifies ICP fit and geography, researches quotation/RFQ/project/technical-sales evidence, finds requested decision-makers, preserves email verification status, scores prospects deterministically, and exports ranked outreach-ready records.

## Score (100)
- ICP fit: 30
- Commercial/B2B value: 20
- Quotation/RFQ evidence: 20
- Decision-maker & reachability: 15
- Evidence quality: 15

The engine never sends outreach. Weak or unsupported prospects are rejected rather than invented to fill a quota.

## Current operating guardrails

- Firecrawl discovers company domains, or you can reuse a saved AutoZen result JSON without new discovery searches.
- Up to six shortlisted websites are checked before choosing company lookups. Public HTTPS reads have a shared 24-request cap, including robots checks and redirects. No access restrictions are bypassed.
- Automatic Hunter company enrichment is hard-capped at three attempts per run, including failures. Larger old environment values are clamped to three.
- A single controlled fallback search runs only when focused discovery yields no usable domains.
- Provider diagnostics explain whether results were absent, filtered, or rejected.
- Demo mode uses fictional UAE industrial distributors and never sends messages.

## What changed in this release

Supplier-comparison articles and manufacturer brand pages are screened before lookup. A first-party supplier/product match and a published physical address are required before spending a Hunter company lookup. Published exact employee counts or structured headcount ranges can complete the profile without Hunter company enrichment. Hunter can fill a missing headcount; a published address can fill missing Hunter location fields. Conflicting Hunter records are not silently overwritten.

Every accepted first-party fact keeps its source and method. Unknown facts remain unknown. The qualified-lead CSV contains only delivered leads; the separate Review CSV contains clearly labelled research outside the qualified delivery, including unchecked findings. Uploaded result JSON provides only discovery URLs/text, never trusted qualification decisions.

The cost estimate now counts search results, the possible fallback, both research sources, and bounded retries. The dashboard asks before a potentially billable run. This is a planning estimate, **not** an account balance check or an enforced cash budget.

See `AUTOZEN_V1_2_6_RELEASE_NOTES.md` for validation and `DEPLOYMENT.md` for the single controlled check. Render and live provider behavior have not been verified for this build.

## Important limitations

- This remains Agent 1. It does not send email or autonomously perform sales/client work.
- The shortlist is a heuristic based on search text. It is not proof of employee count, buying intent, RFQ volume, a local legal entity, or willingness to buy automation.
- Results can still be zero if Hunter coverage, buyer availability, or scoring does not meet the brief. Missing data is not invented. Accept-all email status is not a guarantee of deliverability.
- Most websites do not publish employee counts. JavaScript-only, blocked, HTTP-only, or unsupported pages can remain unverified. This focused English-language industrial-supplier check is not a completed global/niche-adaptive agent.
- Published quotation routes indicate a sales process, not quotation volume, lost revenue, buying intent, consent to outreach, or independently audited company facts.
- The configured size-range gate retains the existing overlap policy for provider headcount bands. Exact employee counts, when supplied, take precedence.
- The application has no authentication or server-side per-account budget. A confirmation dialog protects only normal dashboard clicks. Do not treat an unlisted public URL as access control or expose live keys through a publicly usable service without access protection.
- Job data stored under `/tmp` can disappear after a service restart/redeploy. Export important results beforehand.
