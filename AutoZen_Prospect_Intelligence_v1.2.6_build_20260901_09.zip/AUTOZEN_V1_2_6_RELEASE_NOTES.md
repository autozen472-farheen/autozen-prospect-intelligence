# AutoZen 1.2.6 — website-first verification

Build identity: `20260901-09`. Completed and validated September 2, 2026.

## What the previous run proved

The supplied v1.2.5 result had 160 search rows, 112 distinct domains, 51 shortlist-eligible domains, three Hunter company attempts and zero complete profiles. The recorded issues were a missing Hunter record, an out-of-range/other-geography company, and a company with missing size/location. The export does not contain the raw Hunter payloads; it cannot by itself distinguish incomplete provider data from a field-parsing problem.

## Focused changes

- Re-screen and deterministically order discovery findings. Reject comparison articles and manufacturer brand pages before company lookups.
- Check at most six supplier websites, with no more than 24 direct HTTPS requests including robots and redirects. Read a source page and up to two linked contact/about/company-profile pages.
- Require supplier/product evidence plus a published physical address before considering Hunter company lookup. Marketing service areas alone do not establish location.
- Accept explicit own-workforce statements or own-organization structured employee counts/ranges, with provenance. Do not turn approximate counts, customer counts, conflicting counts or missing data into exact employee facts.
- Use a complete first-party profile without a Hunter company lookup. Otherwise Hunter can supply the missing headcount, and verified website facts can fill absent location fields. Do not overwrite conflicting provider identity, size or location.
- Keep the automatic company pool, Hunter company attempts and contact lookups capped at three. Website publication does not bypass the existing buyer/email/evidence/score gates.
- Reuse a previous AutoZen result JSON as untrusted discovery URLs/text. Ignore saved qualification labels and facts. Unsupported configurations fail before discovery rather than spending on another provider.
- Keep useful research available through a separate Review CSV. Qualified exports remain qualified-only; fact sources appear in JSON, qualified CSV and the dashboard. Spreadsheet-formula prefixes are escaped.

## Offline validation

The packaged suite includes historical search/result fixtures, synthetic company pages and mocked Hunter responses. Tests cover successful first-party qualification, missing Hunter location fallback, missing/contradictory facts, deterministic shortlist selection, lookup caps, private/mixed DNS results, safe redirects, robots restrictions, access denials, page/budget limits, source identity, conflicting headcounts, formula-safe exports, API/storage behavior and dashboard import/confirmation behavior.

No provider credits were spent. Synthetic successful cases are not verified leads. Live websites, Render deployment, Docker construction and visual/iPad layout have not been validated here. Network-independent tests cannot establish actual provider coverage or guarantee a lead.

## One controlled acceptance check, then a decision

Follow `DEPLOYMENT.md`. Reuse the existing result JSON for a one-lead run after activation and explicit cost confirmation. If data coverage still prevents qualification, export the research and choose the requirement trade-off explicitly. Do not keep paying for repeated discovery or silently broaden eligibility.

Agent 1's output contract is now research facts + provenance + unknowns + qualification status. Reuse this contract for the next global-prospecting capability. Personalization, outreach drafting, sales help and client operations are still future work, not shipped employees. The business goal is usable research that supports buyer conversations, not a larger number of agent screens.

## Remaining limitations and operating risk

This is a focused English-language industrial-supplier verifier. It does not independently audit company claims, infer current buying intent, guarantee contact deliverability, send messages, run unattended sales, or replace customer discovery. Many websites will not publish employee counts. Protected/JS-only/HTTP-only pages may remain unverified. Headcount ranges retain the existing overlap rule. Direct requests use hosting resources and can take time; no fixed completion SLA is promised.

The existing service has no app authentication or account-wide cash budget. Preserve any external access protection and do not expose paid-provider actions publicly. Keep keys in deployment environment settings only. `/tmp` job storage is not durable; export before redeployment. ZIP contents include historical public search findings for regression tests, not credentials.

Technical references used for implementation: [Schema.org employee count](https://schema.org/numberOfEmployees), [Hunter company enrichment](https://hunter.io/api/company-enrichment), [Python HTTPS client](https://docs.python.org/3/library/http.client.html).
