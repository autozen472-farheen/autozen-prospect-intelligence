# Deploy AutoZen Lead Researcher v1.2.6

## Files

- `AutoZen_Prospect_Intelligence_v1.2.6_build_20260901_09.zip`
- `Dockerfile_AutoZen_v1.2.6`

Keep the ZIP compressed and upload both files to the same folder at the root of your existing GitHub repository. Preserve the v1.2.5 files for rollback. Never upload API keys. Uploading files need not switch the active Dockerfile; review auto-deploy settings before committing.

For a deliberate release switch, set the existing Render service's Dockerfile Path to `./Dockerfile_AutoZen_v1.2.6`, keep the Docker build context at the repository root, and deploy that commit. Alternatively, if your existing workflow uses a root file named `Dockerfile`, replace that file's content with the supplied versioned Dockerfile when ready to activate. Use one activation method, not both. The external Dockerfile copies the exact versioned ZIP above. The `Dockerfile` inside the archive is for extracted-source deployment, not the two-file method.

Before redeploying, export any important existing results. The configured `/tmp` database is not durable. If the service already has access protection, preserve it. This release does not add authentication.

## Render environment

Keep these values in the Render service environment:

```text
APP_ENVIRONMENT=demo
DATA_MODE=live
COMPANY_PROVIDER=hunter
NARRATIVE_MODE=template
DATABASE_PATH=/tmp/autozen-prospect-intelligence.db
HUNTER_CANDIDATE_ATTEMPTS_PER_RUN=3
FIRECRAWL_RESULTS_PER_COMPANY=5
```

Store `HUNTER_API_KEY` and `FIRECRAWL_API_KEY` privately in Render. Never add real keys to GitHub or the ZIP.

## First live test

First confirm the header or `/health` reports version `1.2.6`, build `20260901-09`. Merely loading the dashboard or requesting `/v1/cost-estimate` does not call providers.

Use industrial equipment distributors / Pumps, valves / United Arab Emirates / 5–500 employees / 1 lead / minimum score 60. Under **Reuse previous research**, choose `leadjob_427439df594c4f13.json`, the result JSON already downloaded. Do not choose the qualified CSV or a Firecrawl search export in this input. Do not select a company CSV at the same time.

Review the confirmation and your provider balance before running once. In saved-research mode the default setup estimates **zero discovery searches**, at most **6 Hunter credits** and **24 Firecrawl credits** of research/retry headroom. The direct public-page checks use hosting resources but no provider API credits. Published website signals can skip Firecrawl research too; actual usage may be lower. OpenAI token costs, if enabled, are additional. These estimates are not a cash budget or a provider balance check.

Without saved research, the default estimate remains 104 Firecrawl credits of total headroom. Do not accidentally start a fresh discovery run when you intend to reuse the JSON.

Acceptance: diagnostics must show saved research used, zero discovery queries, no more than six website checks / 24 direct requests / three Hunter company attempts, and sourced facts separated from unknowns. A qualified lead still needs company fit, appropriate sales evidence, a requested buyer role, usable personal work email, and the score threshold. Download the job JSON and, if needed, **Review CSV**.

If zero leads qualify, stop after this check. The next decision is explicit: retain strict qualified-buyer requirements, or choose a separate company-research workflow with missing size/buyer data labelled. Do not raise caps, buy credits, weaken gates silently, or repeat runs hoping for different coverage. The next planned capability is global prospecting on the shared core, not an indefinite series of UAE patches.

## Validation boundary

This build was tested offline against the supplied search exports and failed v1.2.5 result, with synthetic HTML and Hunter responses. No live company pages were verified, no provider credits were spent, and no Render deployment was performed. Browser/iPad visual rendering and Docker image construction remain unverified. Tests cannot guarantee live provider coverage or a nonzero delivery.

## Rollback

Restore the prior Dockerfile Path `./Dockerfile_AutoZen_v1.2.5` (or the previous active Dockerfile content) and deploy the retained prior ZIP/commit. Database contents under `/tmp` may not survive either deployment.
