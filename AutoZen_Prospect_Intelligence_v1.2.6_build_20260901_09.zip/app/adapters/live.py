from __future__ import annotations

import asyncio
import hashlib
import json
import random
import re
import time
from datetime import date, timedelta
from urllib.error import HTTPError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

import httpx

from app.adapters.base import CompanyDiscovery
from app.discovery import (
    HUNTER_COMPANY_CAP, FIRECRAWL_MAX_ATTEMPTS, assess_result,
    discovery_bodies, domain_from_url, excluded_domain, search_rows,
)

from app.schemas import (
    CompanyCandidate,
    Contact,
    DiscoveryCandidate,
    DiscoveryDiagnostics,
    DiscoveryQuery,
    EmailStatus,
    EmailType,
    Evidence,
    LeadRequest,
    PhoneType,
    SignalType,
)
from app.roles import title_matches_requested_roles
from app.scoring import hard_filter_failures
from app.website_verification import verify_shortlist
from app.schemas import SourceFact


class ProviderError(RuntimeError):
    def __init__(self, message: str, *, code: str | None = None) -> None:
        super().__init__(message)
        self.code = code


def _domain_from_url(value: str | None) -> str:
    if not value:
        return ""
    candidate = value if "://" in value else f"https://{value}"
    return urlparse(candidate).netloc.lower().removeprefix("www.")


class ApolloCompanySource:
    base_url = "https://api.apollo.io/api/v1"

    def __init__(self, api_key: str, timeout_seconds: float = 30) -> None:
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds

    @property
    def headers(self) -> dict[str, str]:
        return {"accept": "application/json", "x-api-key": self.api_key}

    async def discover(
        self, request: LeadRequest, candidate_limit: int
    ) -> list[CompanyCandidate]:
        params: list[tuple[str, str | int]] = [
            ("q_organization_keyword_tags[]", request.industry),
            ("organization_num_employees_ranges[]", f"{request.employee_min},{request.employee_max}"),
            ("page", 1),
            ("per_page", min(candidate_limit, 100)),
        ]
        params.extend(("organization_locations[]", geo) for geo in request.geographies)
        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            response = await client.post(
                f"{self.base_url}/mixed_companies/search",
                headers=self.headers,
                params=params,
            )
        if response.status_code >= 400:
            raise ProviderError(
                f"Apollo company search failed ({response.status_code}): {response.text[:300]}"
            )
        payload = response.json()
        rows = payload.get("organizations") or payload.get("accounts") or []
        companies: list[CompanyCandidate] = []
        for row in rows:
            website = row.get("website_url") or row.get("website") or ""
            domain = row.get("primary_domain") or _domain_from_url(website)
            if not domain:
                continue
            companies.append(
                CompanyCandidate(
                    provider_id=str(row.get("id") or row.get("organization_id") or domain),
                    name=row.get("name") or domain,
                    domain=domain,
                    website=website or f"https://{domain}",
                    industry=row.get("industry") or request.industry,
                    city=row.get("city"),
                    state=row.get("state"),
                    country=row.get("country"),
                    employee_count=row.get("estimated_num_employees")
                    or row.get("num_employees"),
                    technologies=row.get("technologies") or [],
                    active_job_count=row.get("num_current_jobs"),
                    source_provider="apollo",
                )
            )
        return companies

    async def find_contact(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> Contact:
        params: list[tuple[str, str | int | bool]] = [
            ("q_organization_domains_list[]", company.domain),
            ("include_similar_titles", True),
            ("page", 1),
            ("per_page", 5),
        ]
        params.extend(("person_titles[]", role) for role in request.target_roles)
        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            response = await client.post(
                f"{self.base_url}/mixed_people/api_search",
                headers=self.headers,
                params=params,
            )
            if response.status_code >= 400:
                raise ProviderError(
                    f"Apollo people search failed ({response.status_code}): {response.text[:300]}"
                )
            people = response.json().get("people") or []
            if not people:
                return Contact(source_provider="apollo")
            person = people[0]
            person_id = person.get("id") or person.get("person_id")
            match_response = await client.post(
                f"{self.base_url}/people/match",
                headers=self.headers,
                params={"id": person_id, "domain": company.domain},
            )
        matched = (
            match_response.json().get("person", {})
            if match_response.status_code < 400
            else person
        )
        email = matched.get("email")
        linkedin_url = matched.get("linkedin_url") or person.get("linkedin_url")
        return Contact(
            name=matched.get("name") or person.get("name"),
            title=matched.get("title") or person.get("title"),
            email=email,
            email_status=(
                EmailStatus.UNKNOWN if email else EmailStatus.UNAVAILABLE
            ),
            email_type=(
                EmailType.PERSON_WORK if email else EmailType.UNAVAILABLE
            ),
            phone=None,
            linkedin_url=linkedin_url,
            source_provider="apollo",
            source_url=linkedin_url,
        )


class HunterCompanySource:
    """Free Discover plus tightly budgeted enrichment and contact lookup."""

    base_url = "https://api.hunter.io/v2"

    def __init__(
        self,
        api_key: str,
        max_company_enrichments: int = HUNTER_COMPANY_CAP,
        timeout_seconds: float = 30,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.api_key = api_key.strip()
        self.max_company_enrichments = min(HUNTER_COMPANY_CAP, max(0, max_company_enrichments))
        self.timeout_seconds = timeout_seconds
        self.transport = transport

    @property
    def headers(self) -> dict[str, str]:
        return {"accept": "application/json", "X-API-KEY": self.api_key}

    async def discover(
        self, request: LeadRequest, candidate_limit: int
    ) -> list[CompanyCandidate]:
        enrichment_limit = min(candidate_limit, self.max_company_enrichments)
        discover_rows: list[dict[str, object]] = []
        seen_domains: set[str] = set()
        async with httpx.AsyncClient(
            timeout=self.timeout_seconds, transport=self.transport
        ) as client:
            # Start narrowly. If Hunter returns too few companies, retry with the
            # same location, size, and HVAC keywords but without its broad
            # industry taxonomy. Discover calls are free; enrichment remains
            # capped, so the fallback improves recall without increasing the
            # configured credit ceiling.
            for body in self._discover_bodies(request):
                response = await client.post(
                    f"{self.base_url}/discover", headers=self.headers, json=body
                )
                if response.status_code >= 400:
                    raise ProviderError(
                        f"Hunter Discover failed ({response.status_code}): {response.text[:300]}"
                    )
                rows = response.json().get("data") or []
                for row in rows:
                    domain = _domain_from_url(row.get("domain"))
                    if not domain or domain in seen_domains:
                        continue
                    seen_domains.add(domain)
                    discover_rows.append(row)
                if len(discover_rows) >= enrichment_limit:
                    break

            companies: list[CompanyCandidate] = []
            enrichment_attempts = 0
            for row in discover_rows:
                if enrichment_attempts >= enrichment_limit:
                    break
                domain = _domain_from_url(row.get("domain"))
                if not domain:
                    continue
                enrichment_attempts += 1
                enriched = await client.get(
                    f"{self.base_url}/companies/find",
                    headers=self.headers,
                    params={"domain": domain},
                )
                if enriched.status_code == 404:
                    continue
                if enriched.status_code >= 400:
                    raise ProviderError(
                        "Hunter company enrichment failed "
                        f"({enriched.status_code}): {enriched.text[:300]}"
                    )
                company = self._company_from_payload(
                    enriched.json().get("data") or {}, row, request
                )
                if company is not None:
                    companies.append(company)
                if len(companies) >= enrichment_limit:
                    break
            return companies

    async def find_contact(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> Contact:
        params = {
            "domain": company.domain,
            "type": "personal",
            "decision_maker": "true",
            "job_titles": ",".join(request.target_roles),
            "verification_status": "valid,accept_all",
            "required_field": "full_name,position",
            # Free accounts allow up to ten rows per Domain Search. Returning
            # several already-filtered buyers lets us rank the best requested
            # role without revealing unrelated HR/technical contacts.
            "limit": "10",
        }
        async with httpx.AsyncClient(
            timeout=self.timeout_seconds, transport=self.transport
        ) as client:
            response = await client.get(
                f"{self.base_url}/domain-search",
                headers=self.headers,
                params=params,
            )
        if response.status_code >= 400:
            raise ProviderError(
                f"Hunter decision-maker search failed ({response.status_code}): "
                f"{response.text[:300]}"
            )
        emails = [
            row
            for row in (response.json().get("data") or {}).get("emails") or []
            if self._is_usable_buyer_row(row, request)
        ]
        if not emails:
            return Contact(
                phone=company.public_phone,
                phone_type=(
                    PhoneType.GENERIC_COMPANY
                    if company.public_phone
                    else PhoneType.UNAVAILABLE
                ),
                source_provider="hunter",
                source_url=company.source_url,
            )
        best = max(emails, key=lambda row: self._contact_rank(row, request))
        linkedin_url = self._linkedin_url(best.get("linkedin"))
        source_url = linkedin_url or self._best_email_source(best)
        direct_phone = best.get("phone_number")
        return Contact(
            name=" ".join(
                part
                for part in (best.get("first_name"), best.get("last_name"))
                if part
            )
            or None,
            title=best.get("position") or best.get("position_raw"),
            email=best.get("value"),
            email_status=HunterContactVerifier._status(
                (best.get("verification") or {}).get("status")
            ),
            email_type=(
                EmailType.PERSON_WORK
                if best.get("type") == "personal"
                else EmailType.GENERIC_COMPANY
                if best.get("type") == "generic"
                else EmailType.UNKNOWN
            ),
            phone=direct_phone or company.public_phone,
            phone_type=(
                PhoneType.PERSON
                if direct_phone
                else PhoneType.GENERIC_COMPANY
                if company.public_phone
                else PhoneType.UNAVAILABLE
            ),
            linkedin_url=linkedin_url,
            source_provider="hunter",
            source_url=source_url,
        )

    @staticmethod
    def _is_usable_buyer_row(
        row: dict[str, object], request: LeadRequest
    ) -> bool:
        requested_role = title_matches_requested_roles(
            str(row.get("position") or row.get("position_raw") or ""),
            request.target_roles,
        )
        verification = row.get("verification")
        status = (
            str(verification.get("status") or "")
            if isinstance(verification, dict)
            else ""
        )
        return bool(
            requested_role
            and row.get("decision_maker") is True
            and row.get("type") == "personal"
            and row.get("value")
            and status in {"valid", "accept_all"}
        )

    @staticmethod
    def _discover_body(request: LeadRequest) -> dict[str, object]:
        return HunterCompanySource._discover_bodies(request)[0]

    @staticmethod
    def _discover_bodies(request: LeadRequest) -> list[dict[str, object]]:
        country_codes = {
            "united states": "US",
            "usa": "US",
            "us": "US",
            "united arab emirates": "AE",
            "uae": "AE",
            "united kingdom": "GB",
            "uk": "GB",
            "canada": "CA",
            "australia": "AU",
            "new zealand": "NZ",
        }
        locations = []
        for geography in request.geographies:
            code = country_codes.get(geography.strip().lower())
            if code:
                locations.append({"country": code})
        headcount = HunterCompanySource._headcount_bands(
            request.employee_min, request.employee_max
        )
        if len(locations) == len(request.geographies) and headcount:
            base: dict[str, object] = {
                "headquarters_location": {"include": locations},
                "headcount": headcount,
            }
            body: dict[str, object] = {
                **base,
                "keywords": {
                    "include": HunterCompanySource._industry_keywords(
                        request.industry
                    ),
                    "match": "any",
                },
            }
            relevant_industries = HunterCompanySource._industry_filters(
                request.industry
            )
            if relevant_industries:
                body["industry"] = {"include": relevant_industries}
                # Hunter applies filter families together. A second keyword-only
                # pass prevents a sparse taxonomy match from limiting discovery
                # to just a few companies.
                return [
                    body,
                    {
                        **base,
                        "keywords": body["keywords"],
                    },
                ]
            return [body]
        return [{
            "query": (
                f"{request.industry} companies headquartered in "
                f"{', '.join(request.geographies)} with approximately "
                f"{request.employee_min}-{request.employee_max} employees"
            )
        }]

    @staticmethod
    def _industry_keywords(industry: str) -> list[str]:
        """Expand narrow ICP labels for discovery, never for qualification."""
        normalised = " ".join(industry.lower().replace("&", "and").split())
        if normalised in {
            "hvac",
            "heating",
            "air conditioning",
            "heating and air conditioning",
            "mechanical services",
        }:
            return [
                "HVAC",
                "heating",
                "air conditioning",
                "mechanical services",
            ]
        return [industry]

    @staticmethod
    def _industry_filters(industry: str) -> list[str]:
        """Use Hunter's service categories to avoid HVAC recruiters/vendors."""
        normalised = " ".join(industry.lower().replace("&", "and").split())
        if normalised in {
            "hvac",
            "heating",
            "air conditioning",
            "heating and air conditioning",
            "mechanical services",
        }:
            return [
                "Specialty Trade Contractors",
                "Building Equipment Contractors",
                "Repair and Maintenance",
                "Facilities Services",
            ]
        return []

    @staticmethod
    def _headcount_bands(minimum: int, maximum: int) -> list[str]:
        bands = [
            (1, 10, "1-10"),
            (11, 50, "11-50"),
            (51, 200, "51-200"),
            (201, 500, "201-500"),
            (501, 1_000, "501-1000"),
            (1_001, 5_000, "1001-5000"),
            (5_001, 10_000, "5001-10000"),
        ]
        return [label for low, high, label in bands if minimum <= low and high <= maximum]

    @staticmethod
    def _company_from_payload(
        data: dict[str, object], discover_row: dict[str, object], request: LeadRequest
    ) -> CompanyCandidate | None:
        domain = _domain_from_url(str(data.get("domain") or discover_row.get("domain") or ""))
        if not domain:
            return None
        metrics = data.get("metrics") if isinstance(data.get("metrics"), dict) else {}
        employee_min, employee_max = HunterCompanySource._parse_headcount(
            str(metrics.get("employees") or "")
        )
        count = metrics.get("employeesCount")
        count = count if type(count) is int and count > 0 else None
        geo = data.get("geo") if isinstance(data.get("geo"), dict) else {}
        category = data.get("category") if isinstance(data.get("category"), dict) else {}
        # Treat Hunter's category fields as the company's own industry.  Do not
        # promote the requested industry merely because it appears in a broad
        # description or tag: a recruiter that *serves HVAC clients*, for
        # example, is not itself an HVAC contractor.
        category_industry = str(category.get("industry") or "").strip()
        category_subindustry = str(category.get("subIndustry") or "").strip()
        category_text = " ".join(
            part for part in (category_industry, category_subindustry) if part
        )
        industry = category_text or "Unknown"
        linkedin = data.get("linkedin") if isinstance(data.get("linkedin"), dict) else {}
        linkedin_url = HunterCompanySource._linkedin_url(linkedin.get("handle"))
        site = data.get("site") if isinstance(data.get("site"), dict) else {}
        phones = site.get("phoneNumbers") if isinstance(site.get("phoneNumbers"), list) else []
        return CompanyCandidate(
            provider_id=str(data.get("id") or domain),
            name=str(data.get("name") or discover_row.get("organization") or domain),
            domain=domain,
            website=f"https://{domain}",
            industry=industry,
            city=str(geo.get("city") or "") or None,
            state=str(geo.get("state") or "") or None,
            country=str(geo.get("country") or "") or None,
            employee_count=count,
            employee_count_min=employee_min,
            employee_count_max=employee_max,
            technologies=[str(item) for item in (data.get("tech") or [])][:30],
            public_phone=(str(phones[0]) if phones else str(data.get("phone") or "") or None),
            source_provider="hunter",
            source_url=linkedin_url or f"https://{domain}",
        )

    @staticmethod
    def _parse_headcount(value: str) -> tuple[int | None, int | None]:
        value = value.strip().replace(",", "").replace(" ", "").replace("–", "-")
        def number(token: str) -> int:
            return int(float(token[:-1]) * 1000) if token.upper().endswith("K") else int(token)
        token = r"(?:\d+(?:\.\d+)?[Kk]|\d+)"
        match = re.fullmatch(rf"({token})-({token})", value)
        if match:
            low, high = number(match.group(1)), number(match.group(2))
            return (low, high) if 0 < low <= high else (None, None)
        plus = re.fullmatch(rf"({token})\+", value)
        if plus:
            low = number(plus.group(1))
            return (low, 1_000_000) if 0 < low <= 1_000_000 else (None, None)
        if value.isdigit() and int(value) > 0:
            return int(value), int(value)
        return None, None

    @staticmethod
    def _linkedin_url(value: object) -> str | None:
        candidate = str(value or "").strip()
        if not candidate:
            return None
        if candidate.startswith("http://") or candidate.startswith("https://"):
            return candidate
        return f"https://www.linkedin.com/{candidate.lstrip('/')}"

    @staticmethod
    def _best_email_source(row: dict[str, object]) -> str | None:
        sources = row.get("sources") if isinstance(row.get("sources"), list) else []
        for source in sources:
            if isinstance(source, dict) and source.get("still_on_page") and source.get("uri"):
                return str(source["uri"])
        for source in sources:
            if isinstance(source, dict) and source.get("uri"):
                return str(source["uri"])
        return None

    @staticmethod
    def _contact_rank(row: dict[str, object], request: LeadRequest) -> tuple[int, int, int, int]:
        title = str(row.get("position") or row.get("position_raw") or "").lower()
        target_match = any(role.lower() in title for role in request.target_roles)
        status = (row.get("verification") or {}).get("status") if isinstance(row.get("verification"), dict) else None
        status_rank = {"valid": 3, "accept_all": 2, "unknown": 1}.get(str(status), 0)
        return (
            1 if target_match else 0,
            1 if row.get("decision_maker") is True else 0,
            status_rank,
            int(row.get("confidence") or 0),
        )


class FirecrawlSignalSource:
    base_url = "https://api.firecrawl.dev/v2"

    # All Firecrawl users in this process share one pacing gate and response cache.
    # Discovery and evidence research are separate adapters, so per-instance
    # semaphores alone cannot prevent them from collectively exceeding req/min.
    _global_lock: asyncio.Lock | None = None
    _last_request_at: float = 0.0
    _response_cache: dict[str, tuple[float, dict[str, object]]] = {}

    def __init__(
        self,
        api_key: str,
        results_per_company: int = 5,
        timeout_seconds: float = 45,
        transport: httpx.AsyncBaseTransport | None = None,
        max_attempts: int = 2,
        max_concurrency: int = 1,
        min_interval_seconds: float = 3.25,
        cache_ttl_seconds: float = 900.0,
    ) -> None:
        self.api_key = api_key.strip()
        self.results_per_company = results_per_company
        self.timeout_seconds = timeout_seconds
        self.transport = transport
        self.max_attempts = min(FIRECRAWL_MAX_ATTEMPTS, max(1, max_attempts))
        self.min_interval_seconds = max(0.0, min_interval_seconds)
        self.cache_ttl_seconds = max(0.0, cache_ttl_seconds)
        self._request_semaphore = asyncio.Semaphore(max(1, max_concurrency))

    async def research(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> list[Evidence]:
        if company.first_party_signals:
            return [Evidence(**signal.model_dump(), source_provider='first_party_website') for signal in company.first_party_signals]
        signal_terms = {
            SignalType.QUOTATION_RFQ: '"request a quote" quotation RFQ enquiry pricing',
            SignalType.PROJECT_TENDER: 'projects tenders bids procurement EPC contract',
            SignalType.TECHNICAL_SALES: 'technical sales distributor solutions products catalogue',
            SignalType.EXPANSION: 'expansion "new branch" "new office" launch acquisition',
            SignalType.RECENT_NEWS: 'news announcement',
        }
        desired_terms = " ".join(signal_terms[item] for item in request.desired_signals)
        query = f'"{company.name}" {desired_terms}'
        body = {
            "query": query,
            "limit": self.results_per_company,
            "sources": ["web", "news"],
            "tbs": self._time_filter(request.freshness_days),
        }
        payload = await self.search(body)
        rows = search_rows(payload)
        output: list[Evidence] = []
        for row in rows:
            url = row.get("url") or ""
            title = row.get("title") or "Untitled result"
            snippet = row.get("snippet") or row.get("description") or ""
            combined = f"{title} {snippet}".lower()
            signal_type = self._classify(combined)
            exact_domain = _domain_from_url(url) == company.domain
            name_match = company.name.lower() in combined
            confidence = 0.9 if exact_domain else 0.78 if name_match else 0.55
            if not url or confidence < 0.6:
                continue
            output.append(
                Evidence(
                    signal_type=signal_type,
                    title=title,
                    url=url,
                    snippet=snippet[:800],
                    source_provider="firecrawl",
                    published_at=self._parse_relative_date(row.get("date")),
                    confidence=confidence,
                )
            )
        return output

    async def search(self, body: dict[str, object]) -> dict[str, object]:
        """Run a cached, globally paced Firecrawl search with bounded retries."""
        # Namespace cached results by credential and transport. This prevents
        # one configured tenant/test transport from reusing another one's web
        # results while preserving cache hits inside the same deployment.
        credential_namespace = hashlib.sha256(
            self.api_key.encode("utf-8")
        ).hexdigest()[:16]
        transport_namespace = (
            str(id(self.transport)) if self.transport is not None else "default"
        )
        body_key = json.dumps(
            body, sort_keys=True, separators=(",", ":"), default=str
        )
        cache_key = f"{credential_namespace}:{transport_namespace}:{body_key}"
        cached = self._response_cache.get(cache_key)
        now = time.monotonic()
        if cached and (now - cached[0]) <= self.cache_ttl_seconds:
            return cached[1]

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        last_error: Exception | None = None
        async with self._request_semaphore:
            for attempt in range(1, self.max_attempts + 1):
                try:
                    await self._wait_for_global_slot()
                    status_code, response_text, payload = await self._search_once(body, headers)
                except (httpx.TimeoutException, httpx.TransportError, OSError) as error:
                    last_error = error
                    if attempt >= self.max_attempts:
                        break
                    await asyncio.sleep(self._retry_delay(attempt))
                    continue

                if status_code < 400:
                    data = payload.get("data", payload) if isinstance(payload, dict) else payload
                    valid_shape = isinstance(data, list) or (
                        isinstance(data, dict) and any(isinstance(data.get(key), list) for key in ("web", "news"))
                    )
                    if not valid_shape or (isinstance(payload, dict) and payload.get("success") is False):
                        raise ProviderError("Firecrawl returned malformed or unsuccessful search data", code="firecrawl_invalid_response")
                    self._response_cache[cache_key] = (time.monotonic(), payload)
                    self._prune_cache()
                    return payload

                # Retry only temporary/provider-pressure failures. A 429 gets a
                # longer cooldown so the retry does not immediately hit the same
                # rolling provider window.
                if status_code not in {408, 409, 425, 429, 500, 502, 503, 504}:
                    raise ProviderError(
                        f"Firecrawl search failed ({status_code})",
                        code=f"firecrawl_http_{status_code}",
                    )
                last_error = ProviderError(
                    f"Firecrawl temporary failure ({status_code})",
                    code=f"firecrawl_http_{status_code}",
                )
                if attempt < self.max_attempts:
                    delay = 15.0 if status_code == 429 else self._retry_delay(attempt)
                    await asyncio.sleep(delay)

        raise ProviderError(
            f"Firecrawl research unavailable after {self.max_attempts} attempts",
            code=getattr(last_error, "code", None) or "firecrawl_unavailable",
        )

    async def _wait_for_global_slot(self) -> None:
        if FirecrawlSignalSource._global_lock is None:
            FirecrawlSignalSource._global_lock = asyncio.Lock()
        async with FirecrawlSignalSource._global_lock:
            elapsed = time.monotonic() - FirecrawlSignalSource._last_request_at
            wait_for = self.min_interval_seconds - elapsed
            if wait_for > 0:
                await asyncio.sleep(wait_for)
            FirecrawlSignalSource._last_request_at = time.monotonic()

    def _prune_cache(self) -> None:
        if len(self._response_cache) <= 256:
            return
        cutoff = time.monotonic() - self.cache_ttl_seconds
        stale = [key for key, (created, _) in self._response_cache.items() if created < cutoff]
        for key in stale:
            self._response_cache.pop(key, None)

    async def _search_once(
        self, body: dict[str, object], headers: dict[str, str]
    ) -> tuple[int, str, dict[str, object]]:
        try:
            async with httpx.AsyncClient(
                timeout=self.timeout_seconds, transport=self.transport
            ) as client:
                response = await client.post(
                    f"{self.base_url}/search", headers=headers, json=body
                )
            try:
                payload = response.json() if response.content else {}
            except ValueError:
                payload = {}
            return response.status_code, response.text, payload
        except httpx.LocalProtocolError:
            if self.transport is not None:
                raise
            return await asyncio.to_thread(self._search_with_urllib, body, headers)

    @staticmethod
    def _retry_delay(attempt: int) -> float:
        # Short exponential backoff with small jitter; bounded to keep UI runs responsive.
        return min(4.0, (0.75 * (2 ** (attempt - 1))) + random.uniform(0.0, 0.25))

    def _search_with_urllib(
        self, body: dict[str, object], headers: dict[str, str]
    ) -> tuple[int, str, dict[str, object]]:
        request = Request(
            f"{self.base_url}/search",
            data=json.dumps(body).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        try:
            with urlopen(request, timeout=self.timeout_seconds) as response:
                response_text = response.read().decode("utf-8", errors="replace")
                payload = json.loads(response_text) if response_text else {}
                return response.status, response_text, payload
        except HTTPError as error:
            response_text = error.read().decode("utf-8", errors="replace")
            try:
                payload = json.loads(response_text) if response_text else {}
            except json.JSONDecodeError:
                payload = {}
            return error.code, response_text, payload

    @staticmethod
    def _time_filter(freshness_days: int) -> str:
        if freshness_days <= 1:
            return "qdr:d"
        if freshness_days <= 7:
            return "qdr:w"
        if freshness_days <= 31:
            return "qdr:m"
        return "qdr:y"

    @staticmethod
    def _classify(text: str) -> SignalType:
        if re.search(r"\b(rfq|request for quotation|request a quote|quotation|quote request|send enquiry|price enquiry)\b", text):
            return SignalType.QUOTATION_RFQ
        if re.search(r"\b(tender|bid|project|epc|procurement|contract award|vendor registration)\b", text):
            return SignalType.PROJECT_TENDER
        if re.search(r"\b(technical sales|distributor|distribution|product catalogue|product catalog|solutions provider|authorized dealer|authorised dealer)\b", text):
            return SignalType.TECHNICAL_SALES
        if re.search(r"\b(expand\w*|new location|new office|new branch|acquir\w*|launch\w*)\b", text):
            return SignalType.EXPANSION
        return SignalType.RECENT_NEWS

    @staticmethod
    def _parse_relative_date(value: str | None) -> date | None:
        if not value:
            return None
        iso_match = re.match(r"^(\d{4})-(\d{2})-(\d{2})", value)
        if iso_match:
            try:
                return date.fromisoformat(iso_match.group(0))
            except ValueError:
                return None
        relative = re.match(r"^(\d+)\s+(day|week|month|year)s?\s+ago$", value.lower())
        if not relative:
            return None
        amount = int(relative.group(1))
        unit = relative.group(2)
        days = amount * {"day": 1, "week": 7, "month": 30, "year": 365}[unit]
        return date.today() - timedelta(days=days)


class FirecrawlHunterCompanySource(HunterCompanySource):
    """Wide web discovery first; Hunter enrichment only for the best web candidates."""

    supports_saved_discovery = True

    excluded_domains = {
        "linkedin.com", "facebook.com", "instagram.com", "x.com", "twitter.com",
        "youtube.com", "yelp.com", "yellowpages.com", "indeed.com", "glassdoor.com",
        "ziprecruiter.com", "reddit.com", "wikipedia.org", "crunchbase.com",
        "zoominfo.com", "signalhire.com", "rocketreach.co", "apollo.io",
    }

    def __init__(self, hunter_api_key: str, firecrawl_api_key: str,
                 max_company_enrichments: int = HUNTER_COMPANY_CAP, timeout_seconds: float = 45,
                 transport: httpx.AsyncBaseTransport | None = None) -> None:
        super().__init__(hunter_api_key, max_company_enrichments=max_company_enrichments,
                         timeout_seconds=timeout_seconds, transport=transport)
        self.web_discovery = FirecrawlSignalSource(
            firecrawl_api_key, results_per_company=10,
            timeout_seconds=timeout_seconds, transport=transport,
        )

    async def discover(self, request: LeadRequest, candidate_limit: int) -> list[CompanyCandidate]:
        batch = await self.discover_batch(request, candidate_limit)
        # Legacy adapter callers only. The application uses the request-local batch.
        report = batch.diagnostics
        self.last_discovery_diagnostics = {
            "queries_attempted": len(report.queries), "raw_results": report.raw_results,
            "usable_domains": report.eligible_domains, "filtered_domains": report.excluded_results,
            "fallback_used": report.fallback_used,
            "hunter_enrichment_attempts": report.hunter_enrichment_attempts,
            "hunter_qualified_companies": report.enriched_companies,
        }
        return batch.companies

    async def discover_batch(self, request: LeadRequest, candidate_limit: int) -> CompanyDiscovery:
        enrichment_limit = min(candidate_limit, self.max_company_enrichments)
        report = DiscoveryDiagnostics()
        by_domain: dict[str, DiscoveryCandidate] = {}
        eligible: set[str] = set()
        seen: set[str] = set()

        def ingest(rows):
            report.raw_results += len(rows)
            for row in rows:
                domain = domain_from_url(str(row.get("url") or ""))
                if domain:
                    report.duplicate_results += int(domain in seen)
                    seen.add(domain)
                assessment = assess_result(row, request)
                if not assessment.company_like:
                    report.excluded_results += 1
                    continue
                previous = by_domain.get(domain)
                if previous is None or (assessment.eligible and domain not in eligible) or (assessment.eligible == (domain in eligible) and previous.shortlist_score < assessment.score):
                    by_domain[domain] = DiscoveryCandidate(
                        domain=domain, source_title=str(row.get("title") or domain)[:300],
                        source_url=str(row.get("url") or ""),
                        snippet=str(row.get("description") or row.get("snippet") or "")[:800],
                        shortlist_score=assessment.score,
                        reasons=[assessment.reason] if assessment.reason else ["lookup_budget_not_selected"],
                    )
                if assessment.eligible:
                    eligible.add(domain)

        async def collect(body: dict[str, object]) -> bool:
            query = DiscoveryQuery(query=str(body["query"]))
            report.queries.append(query)
            try:
                payload = await self.web_discovery.search(body)
            except ProviderError as error:
                query.error = error.code or "firecrawl_unavailable"
                report.stopped_reason = query.error
                return False
            rows = search_rows(payload)
            query.results = len(rows)
            ingest(rows)
            return True

        if request.saved_discovery:
            report.saved_research_used = True
            ingest([{'url': item.source_url, 'title': item.source_title, 'snippet': item.snippet} for item in request.saved_discovery])
        else:
            for body in self._web_discovery_bodies(request, enrichment_limit):
                if not await collect(body):
                    break

        # One conservative fallback query if the focused queries produced no
        # usable company domains. This costs one additional Firecrawl search,
        # not a Hunter discovery/enrichment sweep.
        if not eligible and not report.stopped_reason and not request.saved_discovery:
            report.fallback_used = True
            await collect(self._fallback_discovery_body(request, enrichment_limit))

        report.unique_domains = len(seen)
        report.review_domains = len(by_domain)
        report.eligible_domains = len(eligible)
        report.candidates = sorted(by_domain.values(), key=lambda row: (row.domain in eligible, row.shortlist_score), reverse=True)
        if not report.stopped_reason:
            report.website_http_requests, report.website_checks = await self._verify_websites(report.candidates, eligible, request)
        report.candidates.sort(key=lambda item: (
            item.website.status != 'confirmed_supplier',
            not bool(item.website.employee_count or item.website.employee_count_min),
            -item.shortlist_score, item.domain,
        ))
        companies: list[CompanyCandidate] = []
        async with httpx.AsyncClient(timeout=self.timeout_seconds, transport=self.transport) as client:
            for item in report.candidates:
                if report.stopped_reason or len(companies) >= enrichment_limit:
                    break
                if item.domain not in eligible or item.website.status != 'confirmed_supplier':
                    continue
                website_company = self._website_company(item, request)
                if item.website.employee_count or item.website.employee_count_min:
                    failures = hard_filter_failures(request, website_company)
                    if failures:
                        item.status = 'not_qualified'
                        item.reasons = [reason.replace(' ', '_') + '_mismatch' for reason in failures]
                        continue
                    item.reasons = ['awaiting_qualification']
                    companies.append(website_company)
                    continue
                if report.hunter_enrichment_attempts >= enrichment_limit:
                    continue
                report.hunter_enrichment_attempts += 1
                item.hunter_attempted = True
                try:
                    response = await client.get(f"{self.base_url}/companies/find", headers=self.headers, params={"domain": item.domain})
                except (httpx.TimeoutException, httpx.TransportError, OSError):
                    item.reasons = ["hunter_unavailable"]
                    report.stopped_reason = "hunter_unavailable"
                    break
                item.hunter_http_status = response.status_code
                if response.status_code == 404:
                    item.reasons = ["hunter_record_not_found"]
                    continue
                if response.status_code >= 400:
                    item.reasons = [f"hunter_http_{response.status_code}"]
                    report.stopped_reason = item.reasons[0]
                    break
                try:
                    data = response.json().get("data")
                    if not isinstance(data, dict) or not data:
                        raise ValueError("empty company data")
                except (ValueError, AttributeError):
                    item.reasons = ["hunter_invalid_response"]
                    continue
                metrics = data.get('metrics') if isinstance(data.get('metrics'), dict) else {}
                geo = data.get('geo') if isinstance(data.get('geo'), dict) else {}
                # Small allowlist: no raw provider body, contacts, tokens or headers.
                item.hunter_fields = {
                    'domain': str(data.get('domain') or '')[:255],
                    'employees': str(metrics.get('employees') or '')[:40],
                    'employeesCount': metrics.get('employeesCount') if type(metrics.get('employeesCount')) is int else None,
                    'country': str(geo.get('country') or '')[:100],
                    'city': str(geo.get('city') or '')[:100],
                }
                if self._negative_company_category(data):
                    item.status = "not_qualified"
                    item.reasons = ["industry_mismatch"]
                    continue
                try:
                    company = self._company_from_payload(
                        data, {"domain": item.domain, "organization": item.source_title}, request
                    )
                except (TypeError, ValueError, AttributeError):
                    item.reasons = ["hunter_invalid_response"]
                    continue
                if company is None:
                    item.reasons = ["hunter_invalid_response"]
                    continue
                if company.domain != item.domain:
                    item.reasons = ["hunter_domain_mismatch"]
                    continue
                # Industry assignment records the observed search match, not a
                # claim that Hunter independently verified this exact label.
                company.industry = request.industry
                company.source_provider = "first_party+hunter"
                company.source_url = item.source_url
                company.verification_facts = list(item.website.facts)
                company.first_party_signals = list(item.website.signals)
                # Fill missing fields only. A conflicting parent/HQ record is not
                # silently converted into the local operating entity.
                if not company.location_text:
                    company.country, company.city = item.website.country, item.website.city
                company.public_phone = company.public_phone or item.website.public_phone
                if company.employee_count is not None or company.employee_count_min is not None:
                    company.verification_facts.append(SourceFact(field='employee_count', value=company.employee_count_text,
                        source_url=f'{self.base_url}/companies/find?domain={item.domain}', method='hunter_company_enrichment'))
                missing = []
                if company.employee_count is None and (company.employee_count_min is None or company.employee_count_max is None):
                    missing.append("employee_count_unverified")
                if not company.location_text:
                    missing.append("company_location_unverified")
                failures = [reason.replace(" ", "_") + "_mismatch" for reason in hard_filter_failures(request, company)]
                if missing or failures:
                    item.reasons = missing + [r for r in failures if not (r == "employee_range_mismatch" and "employee_count_unverified" in missing) and not (r == "geography_mismatch" and "company_location_unverified" in missing)]
                    item.status = "needs_verification" if missing else "not_qualified"
                    continue
                item.reasons = ["awaiting_qualification"]
                companies.append(company)

        if report.stopped_reason:
            for item in report.candidates:
                if not item.hunter_attempted and item.domain in eligible:
                    item.reasons = ["provider_stopped_before_lookup"]
        report.enriched_companies = len(companies)
        return CompanyDiscovery(companies, report)

    async def _verify_websites(self, items, eligible, request):
        return await verify_shortlist(items, eligible, request)

    @staticmethod
    def _website_company(item, request):
        website = item.website
        return CompanyCandidate(provider_id=item.domain, name=website.name or item.domain,
            domain=item.domain, website=f'https://{item.domain}', industry=request.industry,
            country=website.country, city=website.city, employee_count=website.employee_count,
            employee_count_min=website.employee_count_min, employee_count_max=website.employee_count_max,
            public_phone=website.public_phone, source_provider='first_party_website',
            source_url=website.pages[0] if website.pages else item.source_url,
            verification_facts=website.facts, first_party_signals=website.signals)


    @staticmethod
    def _rows_from_search_payload(payload: dict[str, object]) -> list[dict[str, object]]:
        """Normalize Firecrawl v2 search shapes (list or web/news buckets)."""
        return search_rows(payload)

    @staticmethod
    def _fallback_discovery_body(request: LeadRequest, enrichment_limit: int) -> dict[str, object]:
        body = discovery_bodies(request)[0]
        product = request.products_or_services.split(",")[0].strip() or request.industry
        body["query"] = f'{product} {", ".join(request.geographies)} supplier distributor -jobs -directory'[:500]
        return body

    @staticmethod
    def _web_discovery_bodies(request: LeadRequest, enrichment_limit: int) -> list[dict[str, object]]:
        return discovery_bodies(request)

    @classmethod
    def _is_excluded_domain(cls, domain: str) -> bool:
        return excluded_domain(domain)

    @staticmethod
    def _web_candidate_score(row: dict[str, object], request: LeadRequest) -> int:
        assessment = assess_result(row, request)
        return assessment.score if assessment.eligible else 0

    @staticmethod
    def _verified_industry_result(row: dict[str, object], industry: str) -> bool:
        # Compatibility helper retained for provider tests and older callers.
        text = " ".join(str(row.get(field) or "") for field in ("title", "description", "snippet")).lower()
        if any(term in text for term in ("recruiting", "recruitment", "staffing", "job board", "directory", "wikipedia")):
            return False
        tokens = [t for t in re.findall(r"[a-z0-9]+", industry.lower()) if len(t) > 3 and t not in {"company", "companies", "industrial", "equipment", "distributor", "distributors", "supplier", "suppliers"}]
        return not tokens or any(token in text for token in tokens) or any(x in text for x in ("distributor", "supplier", "trading"))

    @staticmethod
    def _negative_company_category(data: dict[str, object]) -> bool:
        category = data.get("category") if isinstance(data.get("category"), dict) else {}
        text = " ".join(str(category.get(field) or "") for field in ("industry", "subIndustry")).lower()
        return any(term in text for term in (
            "human resources", "staffing", "recruiting", "software development",
            "advertising services", "marketing services",
        ))


class HunterContactVerifier:
    base_url = "https://api.hunter.io/v2"

    def __init__(self, api_key: str, timeout_seconds: float = 30) -> None:
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds

    async def verify_or_find(
        self, company: CompanyCandidate, contact: Contact
    ) -> Contact:
        if (
            contact.email
            and contact.source_provider == "hunter"
            and contact.email_status
            in {
                EmailStatus.VERIFIED,
                EmailStatus.ACCEPT_ALL,
                EmailStatus.INVALID,
                EmailStatus.RISKY,
            }
        ):
            return contact
        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            if not contact.email and contact.name:
                response = await client.get(
                    f"{self.base_url}/email-finder",
                    params={
                        "domain": company.domain,
                        "full_name": contact.name,
                        "api_key": self.api_key,
                    },
                )
                if response.status_code == 200:
                    data = response.json().get("data") or {}
                    contact.email = data.get("email")
                    if contact.email:
                        contact.email_type = EmailType.PERSON_WORK
                    verification = data.get("verification") or {}
                    contact.email_status = self._status(verification.get("status"))
                    contact.source_provider = "apollo+hunter"
                    return contact
            if contact.email:
                response = await client.get(
                    f"{self.base_url}/email-verifier",
                    params={"email": contact.email, "api_key": self.api_key},
                )
                if response.status_code == 200:
                    data = response.json().get("data") or {}
                    contact.email_status = self._status(data.get("status"))
                    contact.source_provider = "apollo+hunter"
        return contact

    @staticmethod
    def _status(value: str | None) -> EmailStatus:
        mapping = {
            "valid": EmailStatus.VERIFIED,
            "accept_all": EmailStatus.ACCEPT_ALL,
            "invalid": EmailStatus.INVALID,
            "disposable": EmailStatus.INVALID,
            "webmail": EmailStatus.RISKY,
            "unknown": EmailStatus.UNKNOWN,
        }
        return mapping.get(value or "", EmailStatus.UNKNOWN)
