const form = document.querySelector("#lead-form");
const runButton = document.querySelector("#run-button");
const errorBox = document.querySelector("#form-error");
const emptyState = document.querySelector("#empty-state");
const loadingState = document.querySelector("#loading-state");
const deliverySection = document.querySelector("#delivery");
const fileInput = document.querySelector("#csv-file");
const fileLabel = document.querySelector("#file-label");
const researchInput = document.querySelector("#research-file");

let lastDelivery = null;
let loadingTimer = null;

const loadingSteps = [
  ["Discovering companies", "Applying the industry, geography and company-size filters."],
  ["Checking supplier websites", "Reading public company and contact pages before capped provider lookups."],
  ["Qualifying contacts", "Matching decision-makers and preserving the provider's email status."],
  ["Scoring and ranking", "Calculating ICP fit, commercial value, quotation/RFQ evidence, reachability and evidence quality."],
];

function splitList(value) {
  return value.split(",").map((item) => item.trim()).filter(Boolean);
}

function numberValue(selector) {
  return Number(document.querySelector(selector).value);
}

function selectedSignals() {
  return [...document.querySelectorAll('input[name="signals"]:checked')].map((item) => item.value);
}

function showError(message) {
  errorBox.textContent = message;
  errorBox.hidden = false;
}

function clearError() {
  errorBox.textContent = "";
  errorBox.hidden = true;
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];
    if (char === '"' && quoted && next === '"') {
      cell += '"';
      index += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === "," && !quoted) {
      row.push(cell.trim());
      cell = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && next === "\n") index += 1;
      row.push(cell.trim());
      if (row.some(Boolean)) rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += char;
    }
  }
  row.push(cell.trim());
  if (row.some(Boolean)) rows.push(row);
  if (rows.length < 2) throw new Error("The CSV has no company rows.");

  const headers = rows[0].map((header) => header.trim().toLowerCase());
  const required = ["company_name", "domain", "industry", "country", "employee_count"];
  const missing = required.filter((header) => !headers.includes(header));
  if (missing.length) throw new Error(`CSV is missing required columns: ${missing.join(", ")}.`);

  const records = rows.slice(1).map((values) => Object.fromEntries(headers.map((header, i) => [header, values[i] || ""])));
  const grouped = new Map();
  for (const record of records) {
    const key = record.domain.toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/$/, "");
    if (!key) continue;
    if (!grouped.has(key)) {
      grouped.set(key, {
        name: record.company_name,
        domain: key,
        website: record.website || `https://${key}`,
        industry: record.industry,
        city: record.city || null,
        state: record.state || null,
        country: record.country || null,
        employee_count: record.employee_count ? Number(record.employee_count) : null,
        technologies: record.technologies ? record.technologies.split("|").map((item) => item.trim()).filter(Boolean) : [],
        active_job_count: record.active_job_count ? Number(record.active_job_count) : null,
        contact_name: record.contact_name || null,
        contact_title: record.contact_title || null,
        contact_email: record.contact_email || null,
        email_type: record.email_type || "unknown",
        contact_phone: record.contact_phone || null,
        phone_type: record.phone_type || "unknown",
        linkedin_url: record.linkedin_url || null,
        company_source_url: record.company_source_url || null,
        contact_source_url: record.contact_source_url || null,
        evidence: [],
      });
    }
    if (record.signal_type && record.signal_title && record.signal_url) {
      grouped.get(key).evidence.push({
        signal_type: record.signal_type,
        title: record.signal_title,
        url: record.signal_url,
        snippet: record.signal_snippet || "",
        published_at: record.signal_date || null,
        confidence: record.signal_confidence ? Number(record.signal_confidence) : 0.7,
      });
    }
  }
  return [...grouped.values()];
}

async function buildRequest() {
  const minEmployees = numberValue("#employee-min");
  const maxEmployees = numberValue("#employee-max");
  const signals = selectedSignals();
  if (maxEmployees < minEmployees) throw new Error("Maximum employees must be greater than or equal to minimum employees.");
  if (!signals.length) throw new Error("Select at least one evidence type to prioritize.");

  const request = {
    industry: document.querySelector("#industry").value.trim(),
    products_or_services: document.querySelector("#products-or-services").value.trim(),
    geographies: splitList(document.querySelector("#geographies").value),
    employee_min: minEmployees,
    employee_max: maxEmployees,
    desired_count: numberValue("#desired-count"),
    target_roles: splitList(document.querySelector("#target-roles").value),
    desired_signals: signals,
    freshness_days: 90,
    minimum_score: numberValue("#minimum-score"),
    // The selected signals are ranking preferences, not mandatory filters.
    // Leads without a verified current trigger remain eligible and are clearly
    // labelled as having no current timing evidence.
    require_timing_signal: false,
  };
  if (fileInput.files.length) {
    request.seed_companies = parseCsv(await fileInput.files[0].text());
    if (request.seed_companies.length > 100) throw new Error("Import at most 100 unique companies per run.");
  }
  if (researchInput.files.length) {
    if (fileInput.files.length) throw new Error("Choose either previous research JSON or a company CSV, not both.");
    if (researchInput.files[0].size > 2_000_000) throw new Error("Previous research JSON must be under 2 MB.");
    let saved;
    try { saved = JSON.parse(await researchInput.files[0].text()); }
    catch { throw new Error("This is not a valid JSON file. Use the AutoZen result JSON button."); }
    const candidates = saved.meta?.discovery?.candidates;
    if (!Array.isArray(candidates) || !candidates.length || candidates.length > 200) throw new Error("This JSON needs 1–200 saved AutoZen discovery findings.");
    request.saved_discovery = candidates.map((item) => ({
      source_url: String(item.source_url || ""), source_title: String(item.source_title || "").slice(0, 300),
      snippet: String(item.snippet || "").slice(0, 800),
    }));
  }
  return request;
}

function startLoading() {
  emptyState.hidden = true;
  deliverySection.hidden = true;
  loadingState.hidden = false;
  runButton.disabled = true;
  let index = 0;
  const update = () => {
    const [title, copy] = loadingSteps[index % loadingSteps.length];
    document.querySelector("#loading-title").textContent = title;
    document.querySelector("#loading-copy").textContent = copy;
    index += 1;
  };
  update();
  loadingTimer = window.setInterval(update, 2600);
}

function stopLoading() {
  window.clearInterval(loadingTimer);
  loadingState.hidden = true;
  runButton.disabled = false;
}

function appendText(parent, tag, text, className) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  element.textContent = text;
  parent.appendChild(element);
  return element;
}

function safeHttpUrl(value) {
  try {
    const url = new URL(value);
    return ["http:", "https:"].includes(url.protocol) ? url.href : null;
  } catch {
    return null;
  }
}

function renderLead(lead) {
  const card = document.createElement("article");
  card.className = "lead-card";
  const top = document.createElement("div");
  top.className = "lead-top";
  appendText(top, "div", `#${lead.rank}`, "rank-badge");
  const identity = document.createElement("div");
  appendText(identity, "h3", lead.company.name, "company-title");
  const location = [lead.company.city, lead.company.state, lead.company.country].filter(Boolean).join(", ");
  const employeeText = lead.company.employee_count ?? (
    lead.company.employee_count_min && lead.company.employee_count_max
      ? `${lead.company.employee_count_min}-${lead.company.employee_count_max}`
      : "?"
  );
  appendText(identity, "p", `${lead.company.industry} · ${location || "Location unavailable"} · ${employeeText} employees`, "company-meta");
  top.appendChild(identity);
  const score = document.createElement("div");
  score.className = "score-badge";
  appendText(score, "strong", String(lead.score.total));
  appendText(score, "span", "SCORE / 100");
  top.appendChild(score);
  card.appendChild(top);

  const body = document.createElement("div");
  body.className = "lead-body";
  appendText(body, "p", lead.narrative.why_now, "reason");
  appendText(body, "p", `Outreach angle: ${lead.narrative.outreach_hook}`, "hook");

  const contacts = document.createElement("div");
  contacts.className = "contact-row";
  const contactLabel = [lead.contact.name, lead.contact.title].filter(Boolean).join(" · ") || "Decision-maker unavailable";
  appendText(contacts, "span", contactLabel, "contact-chip");
  if (lead.contact.email) appendText(contacts, "span", `${lead.contact.email} · ${lead.contact.email_type} · ${lead.contact.email_status}`, "contact-chip");
  if (lead.contact.phone) appendText(contacts, "span", `${lead.contact.phone} · ${lead.contact.phone_type}`, "contact-chip");
  const companySource = safeHttpUrl(lead.company.source_url);
  if (companySource) {
    const link = appendText(contacts, "a", "Company source", "contact-chip");
    link.href = companySource;
    link.target = "_blank";
    link.rel = "noreferrer";
  }
  const contactSource = safeHttpUrl(lead.contact.source_url);
  if (contactSource) {
    const link = appendText(contacts, "a", "Contact source", "contact-chip");
    link.href = contactSource;
    link.target = "_blank";
    link.rel = "noreferrer";
  }
  for (const evidence of lead.evidence) appendText(contacts, "span", evidence.signal_type.replaceAll("_", " "), "signal-chip");
  body.appendChild(contacts);

  for (const fact of lead.company.verification_facts || []) {
    appendText(body, "p", `${fact.field.replaceAll("_", " ")}: ${fact.value} — ${fact.method.replaceAll("_", " ")}`, "company-meta");
    const href = safeHttpUrl(fact.source_url);
    if (href) {
      const link = appendText(body, "a", "Fact source", "company-meta");
      link.href = href; link.target = "_blank"; link.rel = "noreferrer";
    }
  }

  const evidenceList = document.createElement("div");
  evidenceList.className = "evidence-list";
  for (const evidence of lead.evidence) {
    const item = document.createElement("div");
    item.className = "evidence-item";
    appendText(item, "span", "↗", "signal-chip");
    const detail = document.createElement("div");
    const link = document.createElement("a");
    link.textContent = evidence.title;
    const href = safeHttpUrl(evidence.url);
    if (href) {
      link.href = href;
      link.target = "_blank";
      link.rel = "noreferrer";
    }
    detail.appendChild(link);
    appendText(detail, "p", `${evidence.published_at || "Undated"} · ${Math.round(evidence.confidence * 100)}% evidence confidence`);
    item.appendChild(detail);
    evidenceList.appendChild(item);
  }
  if (lead.evidence.length) body.appendChild(evidenceList);
  card.appendChild(body);
  return card;
}

function renderDelivery(delivery) {
  lastDelivery = delivery;
  const count = delivery.leads.length;
  document.querySelector("#delivery-title").textContent = `${count} ranked lead${count === 1 ? "" : "s"}`;
  document.querySelector("#delivery-meta").textContent =
    `${delivery.meta.job_id} · ${delivery.meta.mode.toUpperCase()} · ` +
    `v${delivery.meta.engine_version} · build ${delivery.meta.build_id} · ${delivery.meta.duration_ms} ms`;

  const warning = document.querySelector("#delivery-warning");
  warning.hidden = !delivery.meta.warnings.length;
  warning.textContent = delivery.meta.warnings.join(" ");

  const scores = delivery.leads.map((lead) => lead.score.total);
  const average = scores.length ? Math.round(scores.reduce((sum, value) => sum + value, 0) / scores.length) : 0;
  const summary = document.querySelector("#score-summary");
  summary.replaceChildren();
  const summaryRows = [
    ["Complete company profiles", delivery.meta.candidates_considered],
    ["Qualified delivery", count],
    ["Average score", average],
  ];
  for (const [label, value] of summaryRows) {
    const box = document.createElement("div");
    box.className = "summary-card";
    appendText(box, "span", label);
    appendText(box, "strong", String(value));
    summary.appendChild(box);
  }

  const list = document.querySelector("#lead-list");
  list.replaceChildren();
  if (!delivery.leads.length) {
    const reasons = delivery.meta.rejection_summary || {};
    const details = [
      ["industry mismatch", reasons.industry],
      ["employee-range mismatch", reasons.employee_range],
      ["geography mismatch", reasons.geography],
      ["missing required sales-process evidence", reasons.missing_required_sales_signal],
      ["unusable buyer contact", reasons.unusable_contact],
      ["below minimum score", reasons.below_minimum_score],
      ["provider failure", reasons.provider_failure],
    ].filter(([, count]) => Number(count) > 0)
      .map(([label, count]) => `${count} ${label}`)
      .join("; ");
    appendText(
      list,
      "p",
      details ? `No leads passed. Reasons: ${details}.` :
        delivery.meta.discovery?.raw_results > 0 ? "Search returned results, but no leads completed qualification. See discovery and review details below." :
        delivery.meta.discovery?.stopped_reason ? "Discovery could not complete. See the provider error below." : "No qualified leads were returned.",
      "alert warning",
    );
  } else {
    for (const lead of delivery.leads) list.appendChild(renderLead(lead));
  }

  renderDiscovery(delivery.meta.discovery);
  const reviewExport = document.querySelector("#review-export");
  reviewExport.hidden = !delivery.meta.discovery;
  reviewExport.href = `/v1/jobs/${encodeURIComponent(delivery.meta.job_id)}/review.csv`;
  document.querySelector("#csv-export").href = `/v1/jobs/${encodeURIComponent(delivery.meta.job_id)}/export.csv`;
  const jsonBlob = new Blob([JSON.stringify(delivery, null, 2)], { type: "application/json" });
  document.querySelector("#json-export").href = URL.createObjectURL(jsonBlob);
  document.querySelector("#json-export").download = `${delivery.meta.job_id}.json`;
  deliverySection.hidden = false;
}

const reasonLabels = {
  lookup_budget_not_selected: "Not checked: company lookup budget reserved for higher-ranked findings",
  provider_stopped_before_lookup: "Not checked: provider work stopped before this company lookup",
  hunter_record_not_found: "Hunter has no company record; company remains unverified",
  employee_count_unverified: "Employee count unavailable; size requirement not verified",
  company_location_unverified: "Company location unavailable; target location not verified",
  target_location_unverified: "Search text does not establish the target location",
  other_market_in_title: "Search page targets another market; location needs review",
  hunter_domain_mismatch: "Hunter returned a different domain; identity needs review",
  hunter_invalid_response: "Hunter returned incomplete or malformed company data",
  hunter_unavailable: "Hunter request could not complete",
  firecrawl_unavailable: "Firecrawl search could not complete",
  firecrawl_invalid_response: "Firecrawl returned incomplete or malformed search data",
  firecrawl_http_401: "Firecrawl authentication failed (HTTP 401)",
  firecrawl_http_402: "Firecrawl reported insufficient credits or a payment requirement (HTTP 402)",
  firecrawl_http_403: "Firecrawl access denied (HTTP 403)",
  firecrawl_http_429: "Firecrawl rate limit reached (HTTP 429)",
  hunter_http_401: "Hunter authentication failed (HTTP 401)",
  hunter_http_402: "Hunter reported insufficient credits or a payment requirement (HTTP 402)",
  hunter_http_403: "Hunter access denied (HTTP 403)",
  hunter_http_429: "Hunter rate limit reached (HTTP 429)",
  employee_count_mismatch: "Reported company size is outside the requested range",
  employee_range_mismatch: "Reported company size is outside the requested range",
  geography_mismatch: "Reported location does not match the requested geography",
  industry_mismatch: "Reported company category does not match this brief",
  unusable_contact: "Requested buyer and usable personal work email not verified",
  below_minimum_score: "Below the requested qualification score",
  missing_required_sales_signal: "Required sales evidence was not found",
  provider_unavailable: "Evidence provider unavailable; qualification incomplete",
  qualification_provider_error: "A provider request failed during qualification",
  qualification_error: "Qualification encountered an unexpected error",
  website_check_budget_not_selected: "Not website-checked: the six-company check limit was reached",
  website_supplier_or_product_unconfirmed: "Read website did not establish this supplier/product match",
  website_location_unverified: "No matching physical company address was established from the pages read",
  website_conflicting_headcounts: "Published employee counts conflict; size remains unverified",
  website_robots_disallowed: "Website robots policy disallows this read; no bypass attempted",
  website_robots_unavailable: "Could not establish website robots permission",
  website_robots_crawl_delay: "Website requests slower crawling; skipped in this bounded run",
  website_access_challenge: "Website access challenge; no bypass attempted",
  website_unavailable: "Public website could not be read",
  website_dns_blocked_or_unavailable: "Website address could not be safely resolved",
  website_url_blocked: "Website URL failed the safe public-page checks",
  website_budget_reached: "Public website request budget reached",
  requested_count_reached: "Qualified but outside the requested delivery count",
};

function renderDiscovery(report) {
  const section = document.querySelector("#discovery-details");
  section.replaceChildren();
  section.hidden = !report;
  if (!report) return;
  appendText(section, "h3", "Discovery and verification");
  if (report.saved_research_used) appendText(section, "p", "Reused saved research. No new discovery searches were made; saved findings were re-screened.", "company-meta");
  appendText(section, "p", `${report.website_checks || 0} website checks · ${report.website_http_requests || 0} direct page requests (including robots and redirects)`, "company-meta");
  appendText(section, "p", `${report.raw_results} search results · ${report.unique_domains} distinct domains · ${report.eligible_domains} shortlist-eligible · ${report.hunter_enrichment_attempts} Hunter company attempts · ${report.enriched_companies} complete profiles`, "company-meta");
  if (report.stopped_reason) appendText(section, "p", `Provider work stopped: ${reasonLabels[report.stopped_reason] || report.stopped_reason}.`, "alert warning");
  const queryDetails = document.createElement("details");
  appendText(queryDetails, "summary", `Search details (${report.queries.length} queries)`);
  for (const query of report.queries) appendText(queryDetails, "p", `${query.results} results — ${query.query}${query.error ? ` — ${query.error}` : ""}`, "company-meta");
  section.appendChild(queryDetails);
  const review = report.candidates.filter((item) => item.status !== "qualified");
  appendText(section, "h3", `Review findings (${review.length}) — outside this delivery`);
  appendText(section, "p", "Unverified findings are not qualified leads. Missing facts remain unknown. Any qualified overflow is labelled separately. Qualified-lead CSV exports exclude this review list.", "company-meta");
  for (const item of review) {
    const card = document.createElement("details");
    card.className = "review-card";
    if (item.hunter_attempted) card.open = true;
    appendText(card, "summary", `${item.domain} — ${item.status.replaceAll("_", " ")}`);
    appendText(card, "p", item.source_title);
    appendText(card, "p", item.reasons.map((reason) => reasonLabels[reason] || reason.replaceAll("_", " ")).join("; "), "review-reason");
    if (item.hunter_http_status) appendText(card, "p", `Hunter HTTP status: ${item.hunter_http_status}`, "company-meta");
    if (item.website && item.website.status !== "not_checked") {
      appendText(card, "p", `Website check: ${item.website.status.replaceAll("_", " ")}`, "company-meta");
      for (const fact of item.website.facts || []) {
        appendText(card, "p", `${fact.field.replaceAll("_", " ")}: ${fact.value} (${fact.method.replaceAll("_", " ")})`, "company-meta");
        const factUrl = safeHttpUrl(fact.source_url);
        if (factUrl) { const link = appendText(card, "a", "Published fact source"); link.href = factUrl; link.target = "_blank"; link.rel = "noreferrer"; }
      }
    }
    const href = safeHttpUrl(item.source_url);
    if (href) {
      const link = appendText(card, "a", "Search source");
      link.href = href; link.target = "_blank"; link.rel = "noreferrer";
    }
    appendText(card, "p", item.snippet, "company-meta");
    section.appendChild(card);
  }
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  clearError();
  if (runButton.disabled) return;
  runButton.disabled = true;
  try {
    const request = await buildRequest();
    const estimateResponse = await fetch("/v1/cost-estimate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request),
    });
    if (!estimateResponse.ok) throw new Error("Cannot check the credit estimate. No lead-generation request was sent.");
    const estimate = await estimateResponse.json();
    const creditNote = `${estimate.saved_research_used ? "Reusing saved research; no discovery searches. " : ""}Estimated upper credit usage: Hunter ${estimate.hunter.estimated_max_credits}; Firecrawl ${estimate.firecrawl.estimated_max_credits} including any research and retries. Up to ${estimate.website_verification?.http_requests_max || 0} direct website requests. Actual cash charges depend on your provider plans.`;
    document.querySelector("#cost-note").textContent = creditNote;
    if ((estimate.hunter.estimated_max_credits || estimate.firecrawl.estimated_max_credits) && !window.confirm(`${creditNote}\n\nStart this run?`)) {
      runButton.disabled = false;
      return;
    }
    startLoading();
    const response = await fetch("/v1/leads/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request),
    });
    const payload = await response.json();
    if (!response.ok) {
      const detail = typeof payload.detail === "string" ? payload.detail : JSON.stringify(payload.detail);
      throw new Error(detail || `Engine failed with status ${response.status}.`);
    }
    stopLoading();
    renderDelivery(payload);
  } catch (error) {
    stopLoading();
    emptyState.hidden = false;
    showError(error.message || "The engine could not complete this run.");
  }
});

fileInput.addEventListener("change", () => {
  fileLabel.textContent = fileInput.files[0]?.name || "Choose CSV";
});
researchInput.addEventListener("change", () => {
  document.querySelector("#research-label").textContent = researchInput.files[0]?.name || "Choose JSON";
});

document.querySelector("#reset-button").addEventListener("click", () => {
  form.reset();
  fileInput.value = "";
  researchInput.value = "";
  document.querySelector("#research-label").textContent = "Choose JSON";
  fileLabel.textContent = "Choose CSV";
  clearError();
});

fetch("/v1/status")
  .then((response) => response.json())
  .then((status) => {
    document.querySelector("#engine-mode").textContent =
      `${status.data_mode.toUpperCase()} MODE · v${status.engine_version} · BUILD ${status.build_id}`;
    document.querySelector(".status-dot").classList.add("ready");
  })
  .catch(() => {
    document.querySelector("#engine-mode").textContent = "ENGINE UNAVAILABLE";
  });
