"""Conservative first-party publication checks, not inferred firmographics."""
from __future__ import annotations

import asyncio
import json
import re
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit

from app.discovery import WEBSITE_COMPANY_CAP, _tokens, domain_from_url, selection_key
from app.public_web import PublicWebReader, WebReadError
from app.schemas import DiscoveryCandidate, LeadRequest, SeedEvidence, SignalType, SourceFact, WebsiteReview
from app.scoring import _geography_matches

COUNTRIES = {'ae': 'United Arab Emirates', 'uae': 'United Arab Emirates',
    'us': 'United States', 'usa': 'United States', 'gb': 'United Kingdom', 'uk': 'United Kingdom',
    'au': 'Australia', 'ca': 'Canada', 'nz': 'New Zealand', 'in': 'India'}
UAE_CITIES = {'dubai', 'abu dhabi', 'sharjah', 'ajman', 'fujairah', 'ras al khaimah', 'umm al quwain'}


def address_matches(geographies, country, city):
    country = COUNTRIES.get(country.lower(), country)
    for target in geographies:
        canonical = COUNTRIES.get(target.lower(), target)
        if target.lower() in UAE_CITIES:
            if country.lower() == 'united arab emirates' and _geography_matches([target], city or ''):
                return True
        elif canonical.lower() in {x.lower() for x in COUNTRIES.values()}:
            if canonical.lower() == country.lower():
                return True
        elif _geography_matches([target], ', '.join(x for x in [city, country] if x)):
            return True
    return False


class Document(HTMLParser):
    def __init__(self, html: str):
        super().__init__(convert_charrefs=True)
        self.parts, self.links, self.ld, self.addresses = [], [], [], []
        self.title = ''
        self._title = False
        self._script = None
        self._script_parts = []
        self._ignore = 0
        self._address = None
        self.feed(html)
        self.text = re.sub(r'[ \t]+', ' ', ''.join(self.parts))[:120_000]

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'script':
            self._script = attrs.get('type', '').lower()
            self._script_parts = []
        elif tag in {'style', 'svg', 'noscript'}:
            self._ignore += 1
        elif tag == 'title':
            self._title = True
        elif tag == 'a' and attrs.get('href'):
            self.links.append(attrs['href'])
        elif tag == 'address':
            self._address = []
        if tag in {'p', 'div', 'li', 'br', 'footer', 'section', 'h1', 'h2', 'address'}:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag == 'script':
            if self._script == 'application/ld+json':
                try:
                    self.ld.append(json.loads(''.join(self._script_parts)))
                except (ValueError, RecursionError):
                    pass
            self._script = None
        elif tag in {'style', 'svg', 'noscript'}:
            self._ignore = max(0, self._ignore - 1)
        elif tag == 'title':
            self._title = False
        elif tag == 'address' and self._address is not None:
            self.addresses.append(' '.join(self._address))
            self._address = None
        if tag in {'p', 'div', 'li', 'footer', 'section', 'h1', 'h2', 'address'}:
            self.parts.append('\n')

    def handle_data(self, data):
        if self._script is not None:
            self._script_parts.append(data)
            return
        if self._ignore:
            return
        if self._title:
            self.title += data
        if self._address is not None:
            self._address.append(data)
        self.parts.append(data)


def organization_nodes(value, depth=0):
    if depth > 20:
        return
    if isinstance(value, list):
        for item in value[:100]:
            yield from organization_nodes(item, depth + 1)
    elif isinstance(value, dict):
        if '@graph' in value:
            yield from organization_nodes(value['@graph'], depth + 1)
        types = value.get('@type', [])
        types = [types] if isinstance(types, str) else types
        if isinstance(types, list) and set(t for t in types if isinstance(t, str)) & {'Organization', 'Corporation', 'LocalBusiness', 'Store', 'WholesaleStore', 'HardwareStore'}:
            yield value


def exact_headcount(value):
    def valid(n):
        return type(n) is int and 0 < n <= 1_000_000
    if valid(value):
        return value, None, None
    if isinstance(value, dict):
        if valid(value.get('value')):
            return value['value'], None, None
        lo, hi = value.get('minValue'), value.get('maxValue')
        if valid(lo) and valid(hi) and lo <= hi:
            return None, lo, hi
    return None, None, None


def add_fact(review, field, value, url, excerpt, method='first_party_publication'):
    if not any(f.field == field and f.value == str(value) and f.source_url == url for f in review.facts):
        review.facts.append(SourceFact(field=field, value=str(value), source_url=url, excerpt=excerpt[:400], method=method))


def extract_facts(doc: Document, url: str, domain: str, request: LeadRequest, review: WebsiteReview):
    for payload in doc.ld:
        for node in organization_nodes(payload):
            identity = node.get('url') or node.get('@id')
            if not isinstance(identity, str) or domain_from_url(urljoin(url, identity)) != domain:
                continue
            if isinstance(node.get('legalName') or node.get('name'), str):
                review.name = (node.get('legalName') or node['name'])[:200]
            count, lo, hi = exact_headcount(node.get('numberOfEmployees'))
            if count or lo:
                label = str(count) if count else f'{lo}-{hi}'
                add_fact(review, 'employee_count', label, url, json.dumps({'numberOfEmployees': node['numberOfEmployees']})[:400], 'first_party_structured_data')
                review.employee_count, review.employee_count_min, review.employee_count_max = count, lo, hi
            addresses = node.get('address', [])
            addresses = addresses if isinstance(addresses, list) else [addresses]
            for address in addresses:
                if not isinstance(address, dict):
                    continue
                country = address.get('addressCountry')
                if isinstance(country, dict):
                    country = country.get('name')
                if not isinstance(country, str):
                    continue
                country = COUNTRIES.get(country.lower(), country)
                city = address.get('addressLocality') if isinstance(address.get('addressLocality'), str) else None
                location = ', '.join(x for x in [city, country] if x)
                if address_matches(request.geographies, country, city):
                    review.country, review.city = country, city
                    add_fact(review, 'location', location, url, json.dumps(address)[:400], 'first_party_structured_address')
            phone = node.get('telephone')
            if isinstance(phone, str) and re.fullmatch(r'[+\d ()-]{7,30}', phone):
                review.public_phone = phone

    # Exact own-workforce statements only: not clients, years, engineers, or 'over N'.
    for match in re.finditer(r'\bwe\s+(?:employ|have)\s+(\d{1,6})\s+(?:employees|staff members|people)\b', doc.text, re.I):
        count = int(match.group(1))
        if count:
            review.employee_count, review.employee_count_min, review.employee_count_max = count, None, None
            add_fact(review, 'employee_count', count, url, match.group(0))

    # A location in marketing text or areaServed is not a physical address.
    locations = list(doc.addresses)
    lines = [line.strip() for line in doc.text.splitlines() if line.strip()]
    for i, line in enumerate(lines):
        if re.search(r'\b(?:registered office|office address|physical address|p\.?\s*o\.?\s*box|warehouse address)\b', line, re.I):
            locations.append(' '.join(lines[i:i + 3])[:350])
    for address in locations:
        if len(address) > 400 or not _geography_matches(request.geographies, address):
            continue
        for geography in request.geographies:
            if _geography_matches([geography], address):
                if geography.lower() in UAE_CITIES:
                    review.country, review.city = 'United Arab Emirates', geography
                elif geography.lower() in COUNTRIES or geography.lower() in {x.lower() for x in COUNTRIES.values()}:
                    review.country = COUNTRIES.get(geography.lower(), geography)
                else:
                    # Preserve the published address without inventing a country
                    # classification for an arbitrary city/region request.
                    review.city = geography
                add_fact(review, 'location', ', '.join(x for x in [review.city, review.country] if x), url, address, 'first_party_address_text')
                break

    counts = {fact.value for fact in review.facts if fact.field == 'employee_count'}
    if len(counts) > 1:
        review.employee_count = review.employee_count_min = review.employee_count_max = None
        if 'website_conflicting_headcounts' not in review.reasons:
            review.reasons.append('website_conflicting_headcounts')


async def verify_website(item: DiscoveryCandidate, request: LeadRequest, reader: PublicWebReader) -> WebsiteReview:
    review = WebsiteReview()
    pending = [item.source_url]
    supplier = product = False
    visited = set()
    for _ in range(3):
        if not pending:
            break
        url = pending.pop(0)
        if url in visited:
            continue
        visited.add(url)
        try:
            page = await reader.read(url, item.domain)
        except WebReadError as error:
            review.reasons.append(str(error))
            break  # No other route after access/robots/transport failures.
        doc = Document(page.text)
        review.pages.append(page.url)
        text = doc.text.lower()
        if re.search(r'verify you are human|access denied|checking your browser|captcha', (doc.title + ' ' + text[:1200]).lower()):
            review.reasons.append('website_access_challenge')
            break
        targets = _tokens(request.products_or_services) or (_tokens(request.industry) - {'industrial', 'equipment', 'distributor', 'supplier'})
        product = product or bool(targets & _tokens(text)) or not targets
        supplier = supplier or bool(re.search(r'\b(?:suppliers?|distributors?|trading)\b', doc.title, re.I) or re.search(r'\b(?:we (?:supply|distribute)|we are .{0,90}(?:supplier|distributor|trading)|(?:leading|authorized|authorised) (?:supplier|distributor))\b', text))
        extract_facts(doc, page.url, item.domain, request, review)
        if re.search(r'\b(?:request (?:a )?quote|request for quotation|send (?:an )?enquiry|rfq)\b', text):
            review.signals.append(SeedEvidence(signal_type=SignalType.QUOTATION_RFQ, title=doc.title[:250] or 'Published quotation route', url=page.url, snippet='Supplier website publishes a quotation/enquiry route. Volume and need are not verified.', confidence=0.8))
        if supplier and product:
            review.signals.append(SeedEvidence(signal_type=SignalType.TECHNICAL_SALES, title=doc.title[:250] or 'Published supplier products', url=page.url, snippet='First-party supplier/product evidence; not proof of buying intent.', confidence=0.8))
        links = []
        for link in doc.links:
            try:
                absolute = urljoin(page.url, link).split('#')[0]
                path = urlsplit(absolute).path.lower()
            except ValueError:
                continue
            if domain_from_url(absolute) == item.domain and re.search(r'(?:contact|about|company-profile)', path) and absolute not in visited:
                links.append(absolute)
        pending.extend(sorted(set(links), key=lambda u: ('contact' not in u.lower(), len(u)))[:3])
        pending = list(dict.fromkeys(pending))
    review.signals = list({(s.signal_type, s.url): s for s in review.signals}.values())[:6]
    if not review.pages:
        review.status = 'unavailable'
    elif not supplier or not product:
        review.status = 'not_supplier'
        review.reasons.append('website_supplier_or_product_unconfirmed')
    elif not review.country and not review.city:
        review.status = 'needs_verification'
        review.reasons.append('website_location_unverified')
    else:
        review.status = 'confirmed_supplier'
        if not review.employee_count and not review.employee_count_min:
            review.reasons.append('employee_count_unverified')
    return review


async def verify_shortlist(items, eligible, request, reader=None):
    reader = reader or PublicWebReader()
    selected = sorted((item for item in items if item.domain in eligible), key=selection_key)[:WEBSITE_COMPANY_CAP]
    semaphore = asyncio.Semaphore(2)
    async def check(item):
        async with semaphore:
            item.website = await verify_website(item, request, reader)
            item.reasons = list(item.website.reasons)
            if item.website.status == 'confirmed_supplier':
                item.reasons = ['lookup_budget_not_selected'] + item.reasons
            else:
                item.status = 'needs_verification'
    await asyncio.gather(*(check(item) for item in selected))
    for item in items:
        if item.website.status == 'not_checked' and item.domain in eligible:
            item.reasons = ['website_check_budget_not_selected']
    return reader.requests, len(selected)
