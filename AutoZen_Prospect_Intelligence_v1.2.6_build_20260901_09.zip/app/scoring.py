import re
from app.schemas import CompanyCandidate, Contact, EmailStatus, Evidence, LeadRequest, ScoreBreakdown, SignalType


def _normalise(value: str) -> str:
    return " ".join(value.lower().replace("&", "and").replace("/", " ").split())


def _token_overlap(left: str, right: str) -> bool:
    stop = {"and", "the", "of", "for", "company", "companies", "distributor", "distributors", "supplier", "suppliers"}
    left_tokens = {x for x in _normalise(left).split() if len(x) > 2 and x not in stop}
    right_tokens = {x for x in _normalise(right).split() if len(x) > 2 and x not in stop}
    return bool(left_tokens & right_tokens)


def _industry_matches(requested: str, actual: str) -> bool:
    if _token_overlap(requested, actual):
        return True
    r, a = _normalise(requested), _normalise(actual)
    groups = [
        {"industrial equipment", "industrial supplies", "machinery", "engineering", "technical trading"},
        {"pump", "pumps", "valve", "valves", "fluid handling"},
        {"compressor", "compressors", "compressed air"},
        {"instrumentation", "controls", "automation", "process control"},
        {"water treatment", "wastewater", "filtration", "desalination"},
        {"electrical", "elv", "switchgear", "power distribution"},
        {"fire safety", "fire protection", "safety equipment"},
        {"hvac", "heating", "air conditioning", "mechanical services"},
    ]
    return any(any(x in r for x in g) and any(x in a for x in g) for g in groups)


def _geography_matches(geographies: list[str], location: str) -> bool:
    loc = _normalise(location)
    groups = [
        {"united states", "usa", "u.s.", "us"},
        {"united kingdom", "uk", "u.k.", "great britain"},
        {"united arab emirates", "uae"},
    ]
    for geography in geographies:
        req = _normalise(geography)
        if req in {'uae', 'united arab emirates'} and any(re.search(r'(?<!\w)' + city + r'(?!\w)', loc) for city in ['dubai', 'abu dhabi', 'sharjah', 'ajman']):
            return True
        if re.search(r'(?<!\w)' + re.escape(req) + r'(?!\w)', loc):
            return True
        for g in groups:
            if req in g and any(re.search(r'(?<!\w)' + re.escape(alias) + r'(?!\w)', loc) for alias in g):
                return True
    return False


def _employee_range_matches(request: LeadRequest, company: CompanyCandidate) -> bool:
    if company.employee_count is not None:
        return request.employee_min <= company.employee_count <= request.employee_max
    if company.employee_count_min is None or company.employee_count_max is None:
        return False
    return company.employee_count_max >= request.employee_min and company.employee_count_min <= request.employee_max


def hard_filter_failures(request: LeadRequest, company: CompanyCandidate) -> list[str]:
    failures=[]
    if not _industry_matches(request.industry, company.industry): failures.append("industry")
    if not _employee_range_matches(request, company): failures.append("employee range")
    if not _geography_matches(request.geographies, company.location_text): failures.append("geography")
    return failures


def passes_hard_filters(request: LeadRequest, company: CompanyCandidate) -> bool:
    return not hard_filter_failures(request, company)


def score_candidate(request: LeadRequest, company: CompanyCandidate, evidence: list[Evidence], contact: Contact) -> ScoreBreakdown:
    # 30 points: target-company fit
    icp_fit = 0
    if _industry_matches(request.industry, company.industry): icp_fit += 12
    if _employee_range_matches(request, company): icp_fit += 8
    if _geography_matches(request.geographies, company.location_text): icp_fit += 10

    # 20 points: commercial/B2B value proxy. Only evidence-backed signals earn the full score.
    commercial_value = 8 if _industry_matches(request.industry, company.industry) else 0
    if company.employee_count is not None or (company.employee_count_min is not None and company.employee_count_max is not None):
        commercial_value += 4
    types = {e.signal_type for e in evidence}
    if SignalType.TECHNICAL_SALES in types: commercial_value += 4
    if SignalType.PROJECT_TENDER in types: commercial_value += 4
    commercial_value = min(20, commercial_value)

    # 20 points: direct evidence of a quotation/RFQ/project-selling motion.
    quotation_rfq = 0
    weights = {SignalType.QUOTATION_RFQ: 14, SignalType.PROJECT_TENDER: 8, SignalType.TECHNICAL_SALES: 5}
    best={}
    for item in evidence:
        if item.signal_type in weights and (item.signal_type not in best or item.confidence > best[item.signal_type].confidence):
            best[item.signal_type]=item
    quotation_rfq = min(20, round(sum(weights[t] * e.confidence for t,e in best.items())))

    # 15 points: can AutoZen reach the requested buyer?
    reachability=0
    title=_normalise(contact.title or "")
    if title and any(_normalise(role) in title or title in _normalise(role) for role in request.target_roles): reachability += 5
    elif title and any(x in title for x in ("owner","founder","chief","president","director","head","manager")): reachability += 3
    if contact.email_status == EmailStatus.VERIFIED: reachability += 8
    elif contact.email_status == EmailStatus.ACCEPT_ALL: reachability += 5
    elif contact.email_status == EmailStatus.RISKY: reachability += 2
    if contact.phone: reachability += 2
    reachability=min(15, reachability)

    # 15 points: source diversity, confidence and first-party evidence.
    evidence_quality=0
    valid=[e for e in evidence if e.url.startswith("http")]
    unique_urls={e.url for e in valid}
    evidence_quality += min(6, len(unique_urls)*2)
    if valid: evidence_quality += round(max(e.confidence for e in valid)*5)
    first_party=[e for e in valid if company.domain in e.url]
    if first_party: evidence_quality += 4
    evidence_quality=min(15,evidence_quality)

    total=min(100, icp_fit+commercial_value+quotation_rfq+reachability+evidence_quality)
    return ScoreBreakdown(icp_fit=icp_fit, commercial_value=commercial_value, quotation_rfq=quotation_rfq, reachability=reachability, evidence_quality=evidence_quality, total=total)
