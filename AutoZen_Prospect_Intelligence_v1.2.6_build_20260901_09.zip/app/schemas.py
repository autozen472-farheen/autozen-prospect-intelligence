from __future__ import annotations

from datetime import date, datetime, timezone
from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field, model_validator

from app.version import BUILD_ID, ENGINE_VERSION


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class SignalType(str, Enum):
    QUOTATION_RFQ = "quotation_rfq"
    PROJECT_TENDER = "project_tender"
    TECHNICAL_SALES = "technical_sales"
    EXPANSION = "expansion"
    RECENT_NEWS = "recent_news"


class EmailStatus(str, Enum):
    VERIFIED = "verified"
    ACCEPT_ALL = "accept_all"
    RISKY = "risky"
    INVALID = "invalid"
    UNKNOWN = "unknown"
    UNAVAILABLE = "unavailable"


class EmailType(str, Enum):
    PERSON_WORK = "person_work"
    GENERIC_COMPANY = "generic_company"
    PERSONAL = "personal"
    UNKNOWN = "unknown"
    UNAVAILABLE = "unavailable"


class PhoneType(str, Enum):
    PERSON = "person"
    GENERIC_COMPANY = "generic_company"
    UNKNOWN = "unknown"
    UNAVAILABLE = "unavailable"


class SeedEvidence(BaseModel):
    signal_type: SignalType
    title: str = Field(min_length=2, max_length=300)
    url: str
    snippet: str = Field(default="", max_length=2_000)
    published_at: date | None = None
    confidence: float = Field(default=0.7, ge=0, le=1)


class CompanySeed(BaseModel):
    """Provider-neutral company input used for CSV/API imports."""

    name: str = Field(min_length=2, max_length=200)
    domain: str = Field(min_length=3, max_length=255)
    website: str | None = None
    industry: str = Field(min_length=2, max_length=150)
    city: str | None = None
    state: str | None = None
    country: str | None = None
    employee_count: int | None = Field(default=None, ge=1, le=1_000_000)
    technologies: list[str] = Field(default_factory=list)
    active_job_count: int | None = Field(default=None, ge=0, le=1_000_000)
    contact_name: str | None = None
    contact_title: str | None = None
    contact_email: str | None = None
    email_type: EmailType = EmailType.UNKNOWN
    contact_phone: str | None = None
    phone_type: PhoneType = PhoneType.UNKNOWN
    linkedin_url: str | None = None
    company_source_url: str | None = None
    contact_source_url: str | None = None
    evidence: list[SeedEvidence] = Field(default_factory=list, max_length=20)


class SourceFact(BaseModel):
    field: str
    value: str
    source_url: str
    excerpt: str = ""
    method: str = "first_party_publication"


class SavedDiscoverySeed(BaseModel):
    source_url: str = Field(min_length=10, max_length=2000)
    source_title: str = Field(default="", max_length=300)
    snippet: str = Field(default="", max_length=800)


class LeadRequest(BaseModel):
    industry: str = Field(default="Industrial equipment distributors", min_length=2, max_length=150)
    products_or_services: str = Field(default="", max_length=300)
    geographies: list[str] = Field(default_factory=lambda: ["United Arab Emirates"])
    employee_min: int = Field(default=5, ge=1, le=100_000)
    employee_max: int = Field(default=500, ge=1, le=100_000)
    desired_count: int = Field(default=10, ge=1, le=50)
    target_roles: list[str] = Field(
        default_factory=lambda: [
            "Managing Director",
            "General Manager",
            "Sales Director",
            "Commercial Director",
            "Head of Sales",
            "Owner",
            "Founder",
        ]
    )
    desired_signals: list[SignalType] = Field(
        default_factory=lambda: [SignalType.QUOTATION_RFQ, SignalType.PROJECT_TENDER, SignalType.TECHNICAL_SALES]
    )
    freshness_days: int = Field(default=90, ge=7, le=730)
    minimum_score: int = Field(default=40, ge=0, le=100)
    # Timing signals improve ranking, but are not a hidden eligibility gate by
    # default. The dashboard labels these as signals to *prioritize*, so an
    # otherwise valid ICP match must not disappear simply because no recent
    # hiring/expansion event was found.
    require_timing_signal: bool = False
    seed_companies: list[CompanySeed] = Field(
        default_factory=list,
        max_length=100,
        exclude=True,
        description=(
            "Optional provider-neutral companies imported from CSV or another data "
            "source. Omitted from the stored response payload."
        ),
    )
    saved_discovery: list[SavedDiscoverySeed] = Field(default_factory=list, max_length=200, exclude=True)

    @model_validator(mode="after")
    def validate_ranges(self) -> "LeadRequest":
        if self.seed_companies and self.saved_discovery:
            raise ValueError("Use either a company CSV or previous research JSON, not both")
        if self.employee_max < self.employee_min:
            raise ValueError("employee_max must be greater than or equal to employee_min")
        if not self.geographies:
            raise ValueError("At least one geography is required")
        if not self.target_roles:
            raise ValueError("At least one target role is required")
        return self


class CompanyCandidate(BaseModel):
    provider_id: str
    name: str
    domain: str
    website: str
    industry: str
    city: str | None = None
    state: str | None = None
    country: str | None = None
    employee_count: int | None = None
    employee_count_min: int | None = None
    employee_count_max: int | None = None
    technologies: list[str] = Field(default_factory=list)
    active_job_count: int | None = None
    public_phone: str | None = None
    source_provider: str
    source_url: str | None = None
    verification_facts: list[SourceFact] = Field(default_factory=list)
    first_party_signals: list[SeedEvidence] = Field(default_factory=list)

    @property
    def location_text(self) -> str:
        return ", ".join(
            part for part in (self.city, self.state, self.country) if part
        )

    @property
    def employee_count_text(self) -> str:
        if self.employee_count is not None:
            return str(self.employee_count)
        if self.employee_count_min is not None and self.employee_count_max is not None:
            return f"{self.employee_count_min}-{self.employee_count_max}"
        return "Unknown"


class Evidence(BaseModel):
    signal_type: SignalType
    title: str
    url: str
    snippet: str
    source_provider: str
    published_at: date | None = None
    observed_at: datetime = Field(default_factory=utc_now)
    confidence: float = Field(ge=0, le=1)


class Contact(BaseModel):
    name: str | None = None
    title: str | None = None
    email: str | None = None
    email_status: EmailStatus = EmailStatus.UNAVAILABLE
    email_type: EmailType = EmailType.UNAVAILABLE
    phone: str | None = None
    phone_type: PhoneType = PhoneType.UNAVAILABLE
    linkedin_url: str | None = None
    source_provider: str
    source_url: str | None = None


class ScoreBreakdown(BaseModel):
    icp_fit: int = Field(ge=0, le=30)
    commercial_value: int = Field(ge=0, le=20)
    quotation_rfq: int = Field(ge=0, le=20)
    reachability: int = Field(ge=0, le=15)
    evidence_quality: int = Field(ge=0, le=15)
    total: int = Field(ge=0, le=100)


class Narrative(BaseModel):
    why_now: str
    outreach_hook: str
    confidence: float = Field(ge=0, le=1)
    warnings: list[str] = Field(default_factory=list)


class LeadRecord(BaseModel):
    rank: int = Field(ge=1)
    company: CompanyCandidate
    contact: Contact
    evidence: list[Evidence]
    score: ScoreBreakdown
    narrative: Narrative


class WebsiteReview(BaseModel):
    status: Literal["not_checked", "confirmed_supplier", "needs_verification", "not_supplier", "unavailable"] = "not_checked"
    reasons: list[str] = Field(default_factory=list)
    pages: list[str] = Field(default_factory=list)
    name: str | None = None
    country: str | None = None
    city: str | None = None
    employee_count: int | None = None
    employee_count_min: int | None = None
    employee_count_max: int | None = None
    public_phone: str | None = None
    facts: list[SourceFact] = Field(default_factory=list)
    signals: list[SeedEvidence] = Field(default_factory=list)


class DiscoveryCandidate(BaseModel):
    """A search finding, never a qualified lead or an inferred company profile."""

    domain: str
    source_title: str
    source_url: str
    snippet: str = ""
    shortlist_score: int = 0
    status: Literal["needs_verification", "not_qualified", "qualified", "not_selected"] = "needs_verification"
    reasons: list[str] = Field(default_factory=list)
    hunter_attempted: bool = False
    hunter_http_status: int | None = None
    website: WebsiteReview = Field(default_factory=WebsiteReview)
    hunter_fields: dict[str, str | int | None] = Field(default_factory=dict)


class DiscoveryQuery(BaseModel):
    query: str
    results: int = 0
    error: str | None = None


class DiscoveryDiagnostics(BaseModel):
    queries: list[DiscoveryQuery] = Field(default_factory=list)
    raw_results: int = 0
    unique_domains: int = 0
    excluded_results: int = 0
    duplicate_results: int = 0
    review_domains: int = 0
    eligible_domains: int = 0
    hunter_enrichment_attempts: int = 0
    enriched_companies: int = 0
    fallback_used: bool = False
    stopped_reason: str | None = None
    saved_research_used: bool = False
    website_checks: int = 0
    website_http_requests: int = 0
    candidates: list[DiscoveryCandidate] = Field(default_factory=list)


class DeliveryMeta(BaseModel):
    job_id: str
    mode: Literal["mock", "live", "import"]
    generated_at: datetime = Field(default_factory=utc_now)
    requested_count: int
    candidates_considered: int
    qualified_count: int
    duration_ms: int = Field(ge=0)
    warnings: list[str] = Field(default_factory=list)
    rejection_summary: dict[str, int] = Field(default_factory=dict)
    discovery: DiscoveryDiagnostics | None = None
    engine_version: str = ENGINE_VERSION
    build_id: str = BUILD_ID


class LeadDelivery(BaseModel):
    request: LeadRequest
    meta: DeliveryMeta
    leads: list[LeadRecord]


class OutcomeEvent(BaseModel):
    job_id: str
    company_domain: str
    outcome: Literal[
        "approved",
        "rejected",
        "contacted",
        "replied",
        "booked",
        "converted",
    ]
    note: str | None = Field(default=None, max_length=1_000)
    recorded_at: datetime = Field(default_factory=utc_now)
