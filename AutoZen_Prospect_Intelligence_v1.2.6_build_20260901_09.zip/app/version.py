"""Single source of truth for AutoZen release and deployment identity."""

ENGINE_VERSION = "1.2.6"
BUILD_ID = "20260901-09"
BUILD_LABEL = f"v{ENGINE_VERSION} · build {BUILD_ID}"
