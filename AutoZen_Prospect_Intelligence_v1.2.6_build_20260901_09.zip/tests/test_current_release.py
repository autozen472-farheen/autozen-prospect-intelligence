import asyncio
from pathlib import Path

import yaml

from app.config import Settings
from app.factory import build_pipeline
from app.schemas import LeadRequest
from app.version import BUILD_ID, ENGINE_VERSION


def test_default_demo_returns_ranked_uae_industrial_leads(tmp_path) -> None:
    settings = Settings(
        data_mode="mock",
        narrative_mode="template",
        database_path=tmp_path / "test.db",
    )
    delivery = asyncio.run(
        build_pipeline(settings).run(LeadRequest(desired_count=3, minimum_score=40))
    )

    assert len(delivery.leads) == 3
    assert all(
        lead.company.country == "United Arab Emirates" for lead in delivery.leads
    )
    assert all(lead.score.total >= 40 for lead in delivery.leads)
    assert all(lead.evidence for lead in delivery.leads)


def test_release_identity() -> None:
    assert ENGINE_VERSION == "1.2.6"
    assert BUILD_ID == "20260901-09"


def test_default_hunter_cap_and_render_blueprint_match() -> None:
    assert Settings().hunter_candidate_attempts_per_run == 3
    root = Path(__file__).parents[1]
    blueprint = yaml.safe_load((root / "render.yaml").read_text(encoding="utf-8"))
    env = {
        item["key"]: item.get("value")
        for item in blueprint["services"][0]["envVars"]
    }
    assert env["HUNTER_CANDIDATE_ATTEMPTS_PER_RUN"] == "3"
