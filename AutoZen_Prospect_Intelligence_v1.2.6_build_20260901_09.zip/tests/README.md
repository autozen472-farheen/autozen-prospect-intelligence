# Current release tests

This suite covers the AutoZen industrial-distributor schema, Firecrawl discovery breadth, request pacing and caching, controlled fallback discovery, visible diagnostics, Hunter enrichment limits, release identity, and the safe UAE demo.

Run `python -m pytest` with the project dependencies and pytest installed. The suite blocks real outbound connections; provider behavior is simulated. The four JSON files in `fixtures/firecrawl` and `fixtures/failed_v125_job.json` are supplied historical exports, not freshly executed searches. v126 cases exercise the real public-page reader, parser, company selection, saved-research flow and pipeline with synthetic HTML/HTTP responses. Legacy adapter cases use a documented synthetic website double to isolate the older provider logic.

Run `node --test tests/dashboard_logic.cjs` for seven dashboard-logic cases. These use a minimal DOM double, not a rendered layout. Run `node --check app/static/app.js` for syntax validation.

Neither suite spends provider credits, sends email, or deploys anything. A successful offline suite cannot confirm current provider coverage, billing, or live deployment health.

The obsolete Villow/HVAC-era suite remains preserved in the V1.2.3 archive and is intentionally not part of this release.
