// Offline DOM logic double only. No browser rendering or provider calls.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {test}=require('node:test');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'app/static/global.html'),'utf8');
const script=fs.readFileSync(path.join(root,'app/static/global.js'),'utf8');
class Element {
  constructor(tag='div'){this.tag=tag;this.children=[];this.events={};this.value='';this.files=[];this.disabled=false;this.hidden=false;}
  set textContent(value){this.text=String(value);this.children=[];}
  get textContent(){return (this.text||'')+this.children.map(c=>c.textContent).join(' ');}
  set innerHTML(value){throw Error('Unsafe HTML');}
  appendChild(e){this.children.push(e);return e;}
  replaceChildren(){this.children=[];this.text='';}
  addEventListener(name,fn){this.events[name]=fn;}
  setAttribute(name,value){this[name]=value;}
  click(){}
}
const result={meta:{job_id:'global_offline',mode:'live',warnings:['Unqualified research.'],usage:{search_requests:1,public_website_requests:0},discovery:{queries:[],candidates:[{domain:'roof.co',source_title:'<script>evil()</script>',source_url:'javascript:evil()',snippet:'<img src=x onerror=evil()>',requested_locations:['United States'],website_status:'not_checked',facts:[],notes:['Not verified.']}]}},leads:[]};
async function setup({live=false,approve=true,fail=false}={}){
  const elements=new Map([...html.matchAll(/id="([^"]+)"/g)].map(m=>['#'+m[1],new Element()]));elements.set('.global-results',new Element());
  for(const [key,value]of Object.entries({niche:'Roofing contractors',locations:'United States','country-codes':'','result-limit':'5','website-limit':'3',mode:'demo'}))elements.get('#'+key).value=value;
  const calls=[];
  const context=vm.createContext({document:{querySelector:s=>{assert(elements.has(s),s);return elements.get(s);},createElement:t=>new Element(t)},crypto:require('node:crypto').webcrypto,URL,Blob,setTimeout:fn=>fn(),window:{confirm:()=>approve},fetch:async(url,options)=>{
    calls.push({url,options});
    if(url==='/v1/status')return {ok:true,json:async()=>({data_mode:'live',live_runs_enabled:live,engine_version:'1.3.0'})};
    if(url==='/v1/global/estimate')return {ok:true,json:async()=>({search_requests_max:1,search_credits_estimated_upper:2})};
    assert.equal(url,'/v1/global/discover');
    return {ok:!fail,json:async()=>fail?{detail:'Daily limit reached'}:structuredClone(result)};
  }});
  vm.runInContext(script,context);await new Promise(r=>setImmediate(r));
  return {elements,calls,context,submit:()=>elements.get('#global-form').events.submit({preventDefault(){}})};
}
test('demo remains available while live is off',async()=>{const s=await setup();assert(!s.elements.get('#run').disabled);await s.submit();assert.equal(s.calls.filter(c=>c.url==='/v1/global/discover').length,1);});
test('disabled live button explains why and makes no run',async()=>{const s=await setup();s.elements.get('#mode').value='live';s.context.refreshButton();assert(s.elements.get('#run').disabled);await s.submit();assert(!s.calls.some(c=>c.url==='/v1/global/discover'));assert.match(s.elements.get('#cost-note').textContent,/Live access is off/);});
test('cancelled cost confirmation does not spend',async()=>{const s=await setup({live:true,approve:false});s.elements.get('#mode').value='live';s.context.refreshButton();await s.submit();assert(!s.calls.some(c=>c.url==='/v1/global/discover'));assert(!s.elements.get('#run').disabled);});
test('double tap guarded, later retries reuse the same key',async()=>{const s=await setup({live:true});await Promise.all([s.submit(),s.submit()]);await s.submit();const calls=s.calls.filter(c=>c.url==='/v1/global/discover');assert.equal(calls.length,2);assert.equal(calls[0].options.headers['Idempotency-Key'],calls[1].options.headers['Idempotency-Key']);});
test('untrusted result text rendered literally and unsafe links omitted',async()=>{const s=await setup();s.context.render(result);const card=s.elements.get('#results').children[0];assert.match(card.textContent,/<script>evil/);assert(!card.children.some(c=>c.tag==='a'));assert.match(s.elements.get('#result-title').textContent,/research candidate/);});
test('saved research strips claimed qualification and rejects demo',async()=>{const s=await setup();const input=structuredClone(result);input.meta.discovery.candidates[0].status='qualified';input.meta.discovery.candidates[0].employee_count=42;const rows=s.context.savedRows(input);assert.deepEqual(Object.keys(rows[0]).sort(),['snippet','source_title','source_url']);input.meta.mode='demo';assert.throws(()=>s.context.savedRows(input),/Fictional/);});
test('offline import works with live off and zero page reads',async()=>{const s=await setup();s.elements.get('#mode').value='import';s.elements.get('#website-limit').value='0';s.elements.get('#saved-json').files=[{size:500,text:async()=>JSON.stringify({data:{web:[{url:'https://roof.co/',title:'Roof Co'}]}})}];s.context.refreshButton();assert(!s.elements.get('#run').disabled);await s.submit();const req=JSON.parse(s.calls.find(c=>c.url==='/v1/global/discover').options.body);assert.equal(req.mode,'import');assert.equal(req.saved_discovery.length,1);assert.equal(req.website_checks,0);});
test('errors restore controls and preserve the returned reason',async()=>{const s=await setup({fail:true});await s.submit();assert.match(s.elements.get('#error').textContent,/Daily limit/);assert(!s.elements.get('#run').disabled);});
