# AutoZen 1.3.0 — iPad activation

AutoZen only. Do not change villow-lead-engine.

## 1. Preserve results and upload

Download old AutoZen job JSON/CSV you want to keep before redeploying. Ephemeral storage can be cleared.

Upload both supplied files to the existing AutoZen GitHub repository, not Villow:

- AutoZen_Prospect_Intelligence_v1.3.0_build_20260902_02.zip
- Dockerfile_AutoZen_v1.3.0

Keep the ZIP compressed and preserve its name. Uploading does not by itself select the new Dockerfile.

## 2. Set private access

Open Render → autozen-prospect-intelligence → Environment → Edit.

| Setting | Value |
| --- | --- |
| DASHBOARD_USERNAME | autozen-owner |
| DASHBOARD_PASSWORD | Your own new strong password, at least 16 characters. Do not enter this explanatory sentence. |
| ENABLE_LIVE_RUNS | false |
| DAILY_LIVE_RUN_LIMIT | 1 |

Keep provider keys private and unchanged. Do not use Villow signing credentials. Keep the existing DATA_MODE, COMPANY_PROVIDER and NARRATIVE_MODE settings unchanged for now. The existing supplier setup uses live, hunter/auto and template.

Save the settings. Then open Settings → Dockerfile Path and enter:

    ./Dockerfile_AutoZen_v1.3.0

Save. If deployment does not start, choose Manual Deploy → Deploy latest commit. Do not create another service or buy a hosting upgrade in this step.

## 3. Check without provider spending

After Render says Live, open AutoZen and sign in with the new AutoZen login. Confirm v1.3.0 and build 20260902-02 on the supplier page or /v1/status.

Choose Global discovery. Leave Fictional demo selected and run once. Expected: fictional .example records, no verified contacts, zero search/public-page requests. Save the JSON and research CSV if desired.

Live buttons should explain that live access is off. The demo remains usable. A private browser tab must request login for the main page, global page and status page. /health may be public.

If login or the build fails, share only redacted error text. Do not expose passwords or provider keys and do not repeatedly trigger live searches.

## 4. Approve one live check later

Wait for the above checks and explicit acceptance of provider usage. A small global test is one niche, one named market, five search results and one website read. Its search estimate is two Firecrawl credits, no Hunter and no OpenAI. This is not a billing receipt or a free-tier balance check.

When approved, set ENABLE_LIVE_RUNS=true, apply the environment update, refresh, choose Live and confirm one run. Export its result before another deployment. Switch live runs off again when finished. Inspect saved diagnostics rather than repeating searches to fill a quota.

The daily limit is shared. Global discovery followed by supplier qualification uses two separate runs; decide the budget before increasing the default limit.

## Still not production-certified

- Global live coverage and output quality remain unverified.
- Non-industrial qualification is not implemented; those outputs stay research-only.
- Published contacts are unverified and are not consent to outreach.
- /tmp is not durable; restarts can erase results and usage counters. Agree persistent hosting, backups and costs separately.
- Interrupted runs are deliberately not retried automatically. Review provider activity and saved results; do not erase history to bypass the cap.
- Old v1.2.6 lacks access protection. Do not roll back to an exposed live endpoint.
- Villow remains paused at its separate five-step delivery checkpoint.

References: [Docker settings](https://render.com/docs/docker), [environment updates](https://render.com/docs/configure-environment-variables), [free-hosting limits](https://render.com/docs/free), [Firecrawl search](https://docs.firecrawl.dev/features/search).
