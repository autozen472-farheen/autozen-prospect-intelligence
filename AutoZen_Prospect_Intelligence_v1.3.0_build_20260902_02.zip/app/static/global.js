/* Source text is untrusted: render textContent and allow only https links. */
const q = (selector) => document.querySelector(selector);
let delivery = null, signature = null, requestKey = null, serverStatus = null, busy = false;

function lines(value) { return value.split(/\r?\n/).map(s => s.trim()).filter(Boolean); }
function savedRows(saved) {
  if (saved.meta?.mode === 'demo' || saved.meta?.mode === 'mock') throw Error('Fictional demo output cannot become live research.');
  const data = saved.data ?? saved;
  const rows = saved.meta?.discovery?.candidates ?? (Array.isArray(data) ? data : data.web);
  if (!Array.isArray(rows) || !rows.length || rows.length > 200) throw Error('Choose JSON with 1–200 saved search results.');
  return rows.map(row => ({source_url: String(row.source_url || row.url || ''), source_title: String(row.source_title || row.title || '').slice(0,300), snippet: String(row.snippet || row.description || '').slice(0,800)}));
}
function text(parent, tag, value) { const element = document.createElement(tag); element.textContent = value; parent.appendChild(element); return element; }
function link(parent, label, value) {
  try { const url = new URL(value); if (url.protocol !== 'https:' || url.username || url.password) return; const a = text(parent, 'a', label); a.href=url.href; a.target='_blank'; a.rel='noopener noreferrer'; } catch {}
}
function refreshButton() {
  const mode=q('#mode').value;
  const network = mode==='live' || (mode==='import' && Number(q('#website-limit').value)>0);
  const blocked = network && (!serverStatus || !serverStatus.live_runs_enabled || serverStatus.data_mode!=='live');
  q('#run').disabled=busy || blocked;
  q('#run').textContent=busy ? 'Researching…' : blocked ? 'Live access is off' : mode==='demo' ? 'Run fictional demo' : mode==='live' ? 'Find business websites' : 'Review saved research';
  q('#cost-note').textContent=blocked ? 'Live access is off. Use the demo, or set website reads to 0 for an offline JSON review. Enable live access only for an approved test.' : 'Live search uses up to 2 estimated search credits per market. No automatic search retries.';
}
function render(value) {
  const meta=value.meta, items=meta.discovery.candidates;
  q('#results').replaceChildren();
  q('#result-title').textContent=`${items.length} research candidate${items.length===1?'':'s'}`;
  q('#result-note').textContent=meta.warnings.join('\n') + `\nSearch requests: ${meta.usage.search_requests}. Public-page requests: ${meta.usage.public_website_requests}.`;
  for (const item of items) {
    const card=text(q('#results'),'article','');card.className='lead-card';
    text(card,'h3',item.domain);text(card,'p',item.source_title);
    text(card,'p',`Needs verification · ${item.website_status.replaceAll('_',' ')}`);
    text(card,'p',`Requested market: ${item.requested_locations.join(' / ') || 'from imported research; not verified'}`);
    text(card,'p',item.snippet); if(meta.mode!=='demo') link(card,'Search source',item.source_url);
    for(const fact of item.facts) { const p=text(card,'p',`${fact.field.replaceAll('_',' ')}: ${fact.value} — published, unverified. `);link(p,'Source',fact.source_url); }
    if(item.notes.length){const details=text(card,'details','');text(details,'summary','Review notes');for(const note of item.notes)text(details,'p',note);}
  }
  const details=text(q('#results'),'details','');text(details,'summary','Search diagnostics');
  for(const query of meta.discovery.queries)text(details,'p',`${query.location}: ${query.results} results. ${query.error || 'Completed.'} Query: ${query.query}`);
  q('#download-json').hidden=false;q('#download-csv').hidden=false;
  q('#handoff').hidden=meta.mode==='demo' || !items.length;
}
q('#global-form').addEventListener('submit',async event=>{
  event.preventDefault();if(busy || q('#run').disabled)return;
  q('#error').hidden=true;busy=true;refreshButton();q('.global-results').setAttribute('aria-busy','true');
  try {
    const request={niche:q('#niche').value.trim(),locations:lines(q('#locations').value),country_codes:q('#country-codes').value.split(',').map(x=>x.trim()).filter(Boolean),results_per_location:Number(q('#result-limit').value),website_checks:Number(q('#website-limit').value),mode:q('#mode').value};
    if(request.mode==='import') { const file=q('#saved-json').files[0];if(!file || file.size>2000000)throw Error('Choose a saved JSON file under 2 MB.');request.saved_discovery=savedRows(JSON.parse(await file.text())); }
    const estimateResponse=await fetch('/v1/global/estimate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(request)});
    const estimate=await estimateResponse.json();if(!estimateResponse.ok)throw Error(typeof estimate.detail==='string'?estimate.detail:JSON.stringify(estimate.detail));
    if(request.mode==='live' && !window.confirm(`Up to ${estimate.search_requests_max} searches and approximately ${estimate.search_credits_estimated_upper} Firecrawl search credits. Provider plan charges may apply. Start once?`))return;
    const current=JSON.stringify(request);if(signature!==current){signature=current;requestKey=crypto.randomUUID();}
    const response=await fetch('/v1/global/discover',{method:'POST',headers:{'Content-Type':'application/json','Idempotency-Key':requestKey},body:JSON.stringify(request)});
    const result=await response.json();if(!response.ok)throw Error(typeof result.detail==='string'?result.detail:JSON.stringify(result.detail));
    delivery=result;render(result);
  } catch(error) {q('#error').textContent=error.message || 'Could not complete research. No automatic retry.';q('#error').hidden=false;}
  finally{busy=false;refreshButton();q('.global-results').setAttribute('aria-busy','false');}
});
q('#mode').addEventListener('change',refreshButton);q('#website-limit').addEventListener('input',refreshButton);
q('#download-json').addEventListener('click',()=>{if(!delivery)return;const url=URL.createObjectURL(new Blob([JSON.stringify(delivery,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=delivery.meta.job_id+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);});
q('#download-csv').addEventListener('click',()=>{if(delivery)window.location.href=`/v1/global/jobs/${encodeURIComponent(delivery.meta.job_id)}/research.csv`;});
fetch('/v1/status').then(async response=>{if(!response.ok)throw Error('Setup unavailable');return response.json();}).then(status=>{serverStatus=status;q('#status').textContent=`v${status.engine_version} · Live ${status.live_runs_enabled?'enabled':'off'}`;refreshButton();}).catch(()=>{q('#status').textContent='Could not check setup; demo only';refreshButton();});
