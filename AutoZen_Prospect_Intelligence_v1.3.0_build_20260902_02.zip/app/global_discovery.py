"""Bounded public-business discovery, separate from industrial qualification.

Search text, published contacts and requested markets are observations, not
verified firmographics or consent to outreach. Never execute page instructions.
"""
from __future__ import annotations

import csv
import io
import ipaddress
import json
import re
from datetime import datetime, timezone
from html.parser import HTMLParser
from typing import Literal
from urllib.parse import unquote, urljoin, urlsplit
from uuid import uuid4

import httpx
from pydantic import BaseModel, Field, field_validator, model_validator

from app.discovery import domain_from_url, excluded_domain, search_rows
from app.public_web import PublicWebReader, WebReadError, validate_url
from app.schemas import SavedDiscoverySeed
from app.version import BUILD_ID, ENGINE_VERSION


class GlobalRequest(BaseModel):
    niche: str = Field(min_length=2, max_length=150)
    locations: list[str] = Field(min_length=1, max_length=3)
    country_codes: list[str] = Field(default_factory=list, max_length=3)
    results_per_location: int = Field(default=5, ge=1, le=10)
    website_checks: int = Field(default=3, ge=0, le=5)
    mode: Literal['demo', 'live', 'import'] = 'demo'
    saved_discovery: list[SavedDiscoverySeed] = Field(default_factory=list, max_length=200)

    @field_validator('niche')
    @classmethod
    def clean_niche(cls, value):
        value = value.strip()
        if len(value) < 2 or any(ord(c) < 32 for c in value):
            raise ValueError('Enter a niche of at least two characters')
        return value

    @field_validator('locations')
    @classmethod
    def clean_locations(cls, values):
        clean = []
        for value in values:
            value = value.strip()
            if not 2 <= len(value) <= 100 or any(ord(c) < 32 for c in value):
                raise ValueError('Each location must contain 2–100 characters')
            if value.casefold() in {'world', 'worldwide', 'global', 'everywhere', 'all'}:
                raise ValueError('Name up to three countries or cities for this run')
            if value.casefold() not in [x.casefold() for x in clean]:
                clean.append(value)
        return clean

    @model_validator(mode='after')
    def validate_mode(self):
        if self.mode == 'import' and not self.saved_discovery:
            raise ValueError('Import mode needs saved search results')
        if self.mode != 'import' and self.saved_discovery:
            raise ValueError('Choose import mode to reuse saved results')
        if self.country_codes:
            if len(self.country_codes) != len(self.locations) or any(not re.fullmatch(r'[A-Za-z]{2}', x) for x in self.country_codes):
                raise ValueError('Provide one two-letter country code per location, in the same order')
            self.country_codes = [x.upper() for x in self.country_codes]
        elif self.mode == 'live':
            countries = {'united arab emirates': 'AE', 'uae': 'AE', 'united states': 'US', 'usa': 'US',
                         'united kingdom': 'GB', 'uk': 'GB', 'australia': 'AU', 'canada': 'CA',
                         'new zealand': 'NZ', 'india': 'IN', 'germany': 'DE', 'france': 'FR',
                         'japan': 'JP', 'singapore': 'SG', 'saudi arabia': 'SA', 'south africa': 'ZA',
                         'brazil': 'BR', 'mexico': 'MX', 'spain': 'ES', 'italy': 'IT'}
            for location in self.locations:
                matches = [code for name, code in countries.items()
                           if location.casefold() == name or location.casefold().endswith(', ' + name)]
                if not matches:
                    raise ValueError('Include the country in each location, or supply its two-letter country code')
                self.country_codes.append(matches[0])
        return self


def global_estimate(request: GlobalRequest) -> dict:
    count = len(request.locations) if request.mode == 'live' else 0
    return {
        'search_requests_max': count,
        'search_credits_estimated_upper': count * 2,
        'public_website_requests_max': 24 if request.website_checks and request.mode != 'demo' else 0,
        'hunter_requests': 0, 'openai_requests': 0,
        'note': 'One web-only search per location; no automatic retries. Credits are estimates, not cash charges or an account balance.',
    }


def queries_for(request: GlobalRequest) -> list[dict]:
    # Explicit location bias; never inherit Firecrawl's US default for other markets.
    return [{
        'query': f'{request.niche} {location} company official website contact -jobs -directory',
        'location': location, 'country': request.country_codes[index], 'limit': request.results_per_location,
        'sources': ['web'], 'safe': True, 'ignoreInvalidURLs': True,
        'highlights': False, 'timeout': 20000,
    } for index, location in enumerate(request.locations)]


async def firecrawl_search(api_key: str, body: dict) -> list[dict]:
    # Fixed HTTPS provider origin; no redirect following, scraping option or retries.
    async with httpx.AsyncClient(timeout=25, follow_redirects=False, trust_env=False) as client:
        async with client.stream('POST', 'https://api.firecrawl.dev/v2/search',
                                 headers={'Authorization': f'Bearer {api_key}'}, json=body) as response:
            if response.status_code != 200:
                raise WebReadError(f'firecrawl_http_{response.status_code}')
            raw = bytearray()
            async for chunk in response.aiter_bytes():
                raw.extend(chunk)
                if len(raw) > 2_000_000:
                    raise WebReadError('firecrawl_response_too_large')
    try:
        payload = json.loads(raw)
    except (ValueError, UnicodeError):
        raise WebReadError('firecrawl_invalid_response') from None
    if not isinstance(payload, dict) or payload.get('success') is False:
        raise WebReadError('firecrawl_unsuccessful_response')
    if not isinstance(payload.get('data'), (list, dict)):
        raise WebReadError('firecrawl_invalid_response')
    return search_rows(payload)[:body['limit']]


def eligible_url(url: str) -> str:
    domain = domain_from_url(url)
    if not domain or excluded_domain(domain) or domain.endswith(('.example', '.test', '.invalid')):
        return ''
    try:
        ipaddress.ip_address(domain)
    except ValueError:
        pass
    else:
        return ''
    try:
        validate_url(url, domain)
    except WebReadError:
        return ''
    return domain


class BusinessPage(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.text_parts = []
        self.json_blocks = []
        self._hidden = 0
        self._json = False
        self._buffer = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag in {'script', 'style', 'noscript'}:
            self._hidden += 1
        if tag == 'script' and attrs.get('type', '').lower() == 'application/ld+json':
            self._json = True
            self._buffer = []
        if tag == 'a' and attrs.get('href'):
            self.links.append(attrs['href'])

    def handle_endtag(self, tag):
        if tag == 'script' and self._json:
            self.json_blocks.append(''.join(self._buffer))
            self._json = False
        if tag in {'script', 'style', 'noscript'}:
            self._hidden = max(0, self._hidden - 1)

    def handle_data(self, data):
        if self._json:
            self._buffer.append(data)
        if not self._hidden:
            self.text_parts.append(data)


def structured_businesses(blocks):
    allowed = {'organization', 'localbusiness', 'corporation', 'dentist', 'dentalclinic',
               'medicalbusiness', 'hvacbusiness', 'roofingcontractor', 'plumber',
               'professionalservice', 'store', 'restaurant', 'realestateagent',
               'homeandconstructionbusiness', 'automotivebusiness', 'electrician'}
    for raw in blocks[:20]:
        try:
            data = json.loads(raw)
        except (ValueError, RecursionError):
            continue
        stack = [(data, 0)]
        while stack:
            node, depth = stack.pop()
            if depth > 8:
                continue
            if isinstance(node, list):
                stack.extend((x, depth + 1) for x in node[:100])
            elif isinstance(node, dict):
                types = node.get('@type', [])
                if isinstance(types, str):
                    types = [types]
                if isinstance(types, list) and any(str(t).lower().split('/')[-1] in allowed for t in types):
                    yield node
                graph = node.get('@graph')
                if graph is not None:
                    stack.append((graph, depth + 1))


def published_facts(page, domain):
    parsed = BusinessPage()
    parsed.feed(page.text)
    facts = []
    for node in structured_businesses(parsed.json_blocks):
        # Embedded third-party organizations must not become this business's facts.
        node_url = node.get('url')
        if isinstance(node_url, str) and domain_from_url(node_url) != domain:
            continue
        if isinstance(node.get('name'), str):
            facts.append({'field': 'published_name', 'value': node['name'][:200], 'source_url': page.url})
        address = node.get('address')
        if isinstance(address, dict):
            values = [address.get(k) for k in ('streetAddress', 'addressLocality', 'addressRegion', 'postalCode', 'addressCountry')]
            text = ', '.join(x for x in values if isinstance(x, str))
            if text:
                facts.append({'field': 'published_address', 'value': text[:500], 'source_url': page.url})
    role_names = {'info', 'sales', 'contact', 'hello', 'office', 'support', 'enquiries', 'inquiries', 'booking', 'bookings', 'service', 'orders'}
    for href in parsed.links[:1000]:
        if href.lower().startswith('mailto:'):
            email = unquote(href[7:].split('?')[0]).strip().lower()
            if email.count('@') == 1:
                local, host = email.split('@')
                if local in role_names and (host == domain or host.endswith('.' + domain)):
                    facts.append({'field': 'public_business_email', 'value': email, 'source_url': page.url})
        elif href.lower().startswith('tel:'):
            phone = unquote(href[4:]).strip()
            if re.fullmatch(r'\+?[0-9 ()\-.]{7,30}', phone) and 7 <= len(re.sub(r'\D', '', phone)) <= 15:
                facts.append({'field': 'public_phone', 'value': phone, 'source_url': page.url})
    unique = {(f['field'], f['value']): {**f, 'status': 'published_unverified'} for f in facts}
    return parsed, list(unique.values())[:20]


async def read_business(candidate, reader):
    domain = candidate['domain']
    # Use the actual search result's hostname (www can have separate robots rules).
    parts = urlsplit(candidate['source_url'])
    homepage = f'https://{parts.netloc}/'
    try:
        page = await reader.read(homepage, domain)
        parsed, facts = published_facts(page, domain)
        candidate['website_status'] = 'page_read'
        candidate['pages_read'].append(page.url)
        candidate['facts'].extend(facts)
    except WebReadError as error:
        candidate['website_status'] = 'unavailable'
        candidate['notes'].append(str(error))
        return
    for href in parsed.links:
        url = urljoin(page.url, href)
        if domain_from_url(url) != domain:
            continue
        if not re.search(r'/(?:contact|contact-us|kontakt|contacto|contato|nous-contacter)/?$', urlsplit(url).path, re.I):
            continue
        try:
            contact = await reader.read(url, domain)
            _, facts = published_facts(contact, domain)
            candidate['facts'].extend(facts)
            candidate['pages_read'].append(contact.url)
        except WebReadError as error:
            candidate['notes'].append(str(error))
        break
    candidate['facts'] = list({(f['field'], f['value']): f for f in candidate['facts']}.values())[:30]


async def discover_global(request: GlobalRequest, api_key=None, search=None, reader=None) -> dict:
    search = search or firecrawl_search
    reader = reader or PublicWebReader(limit=24)
    now = datetime.now(timezone.utc).isoformat()
    warnings = ['Research candidates only: industry fit, location, size, buyer role and contact deliverability are not independently verified. No outreach is sent.']
    queries, candidates, raw_count, excluded, duplicates, attempts = [], {}, 0, 0, 0, 0

    def ingest(rows, location, query):
        nonlocal raw_count, excluded, duplicates
        for row in rows:
            raw_count += 1
            url = str(row.get('url') or row.get('source_url') or '')[:2000]
            domain = eligible_url(url)
            title = str(row.get('title') or row.get('source_title') or domain)[:300]
            if not domain or re.search(r'\b(?:top\s+\d+|directory|job vacancies|salary guide)\b', title, re.I):
                excluded += 1
                continue
            if domain in candidates:
                duplicates += 1
                if location and location not in candidates[domain]['requested_locations']:
                    candidates[domain]['requested_locations'].append(location)
                continue
            candidates[domain] = {
                'domain': domain, 'source_title': title, 'source_url': url,
                'snippet': str(row.get('description') or row.get('snippet') or '')[:800],
                'requested_niche': request.niche, 'requested_locations': [location] if location else [],
                'discovery_query': query, 'observed_at': now, 'status': 'needs_verification',
                'website_status': 'not_checked', 'pages_read': [], 'facts': [],
                'notes': ['Search location is a request, not verified company location.'],
            }

    if request.mode == 'demo':
        warnings.insert(0, 'FICTIONAL DEMO. These .example businesses are not real prospects. No provider calls.')
        for i, location in enumerate(request.locations):
            domain = f'demo-business-{i + 1}.example'
            candidates[domain] = {'domain': domain, 'source_title': f'Fictional business {i + 1}',
                'source_url': f'https://{domain}/', 'snippet': f'Demo placeholder for {request.niche}.',
                'requested_niche': request.niche, 'requested_locations': [location], 'discovery_query': '',
                'observed_at': now, 'status': 'needs_verification', 'website_status': 'fictional_demo',
                'pages_read': [], 'facts': [], 'notes': ['Fictional, not suitable for outreach.']}
        raw_count = len(candidates)
    elif request.mode == 'import':
        ingest([seed.model_dump() for seed in request.saved_discovery], '', 'saved research; original geography not re-verified')
        warnings.append('Saved search results reused. No new paid discovery; website reads can still occur if selected.')
    else:
        if not api_key:
            raise WebReadError('Configure FIRECRAWL_API_KEY before live discovery')
        for body in queries_for(request):
            attempts += 1
            record = {'query': body['query'], 'location': body['location'], 'results': 0, 'error': None}
            try:
                rows = await search(api_key, body)
                record['results'] = len(rows)
                ingest(rows, body['location'], body['query'])
            except (WebReadError, httpx.HTTPError) as error:
                record['error'] = str(error) if isinstance(error, WebReadError) else 'search_network_error'
                warnings.append('A search failed; no retry was made. See search details.')
                queries.append(record)
                break  # Do not keep spending after a provider/access failure.
            queries.append(record)
    items = list(candidates.values())
    if request.mode != 'demo':
        for item in items[:request.website_checks]:
            await read_business(item, reader)
    if not items:
        warnings.append('No usable business websites were returned. Do not assume the requested market has no businesses.')
    return {
        'request': request.model_dump(exclude={'saved_discovery'}),
        'meta': {'job_id': 'global_' + uuid4().hex[:16], 'mode': request.mode, 'generated_at': now,
                 'engine_version': ENGINE_VERSION, 'build_id': BUILD_ID,
                 'candidate_count': len(items), 'qualified_count': 0, 'warnings': warnings,
                 'usage': {'search_requests': attempts, 'search_credits_estimated': attempts * 2,
                           'public_website_requests': reader.requests, 'hunter_requests': 0, 'openai_requests': 0},
                 'discovery': {'queries': queries, 'raw_results': raw_count, 'excluded_results': excluded,
                               'duplicate_results': duplicates, 'candidates': items}},
        'leads': [],
    }


def research_csv(delivery):
    output = io.StringIO()
    fields = ['mode', 'domain', 'source_title', 'source_url', 'snippet', 'requested_niche', 'requested_locations',
              'status', 'website_status', 'observed_at', 'published_facts', 'contact_verification']
    writer = csv.DictWriter(output, fieldnames=fields)
    writer.writeheader()
    for row in delivery['meta']['discovery']['candidates']:
        record = {key: row.get(key, '') for key in fields}
        record['mode'] = delivery['meta']['mode']
        record['requested_locations'] = ' | '.join(row['requested_locations'])
        record['published_facts'] = json.dumps(row['facts'], ensure_ascii=False)
        record['contact_verification'] = 'not_verified'
        for key, value in record.items():
            text = str(value)
            record[key] = "'" + text if text.lstrip().startswith(('=', '+', '-', '@')) or text.startswith(('\t', '\r', '\n')) else text
        writer.writerow(record)
    return output.getvalue()
