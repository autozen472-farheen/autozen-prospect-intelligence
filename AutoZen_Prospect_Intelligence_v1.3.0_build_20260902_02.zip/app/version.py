"""Single source of truth for AutoZen release and deployment identity."""

ENGINE_VERSION = "1.3.0"
BUILD_ID = "20260902-02"
BUILD_LABEL = f"v{ENGINE_VERSION} · build {BUILD_ID}"
