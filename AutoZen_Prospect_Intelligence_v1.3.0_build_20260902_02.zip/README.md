# AutoZen Prospect Intelligence 1.3.0

Build 20260902-02. Two workflows in one existing AutoZen service. Villow is unchanged.

| Workflow | Route | Output |
| --- | --- | --- |
| Supplier qualification | / | Existing v1.2.6 industrial supplier research, contact checks and scoring, now behind login and run controls. |
| Global discovery | /global | Public business website candidates for a niche across up to three named markets. All results remain unqualified research. |

## Global discovery

- Fictional demo: no network calls; clearly marked .example records.
- Live: one Firecrawl web-only search per location, at most three locations and ten results per location. No automatic retries, no Hunter and no OpenAI. A provider failure stops remaining searches.
- Reuse JSON: accepts AutoZen discovery JSON or a Firecrawl web search export. Only URLs, titles and snippets become seeds. Set website reads to zero for fully offline review.
- Website reads: up to five businesses, two pages each, sharing a cap of 24 requests including robots and redirects. Private networks, blocked pages, cross-origin redirects and unsupported content are skipped. No login, CAPTCHA or robots restrictions are bypassed.
- Country codes are explicit or resolved from a small common-country map. Supply a two-letter code for other markets. Local-language niche text is accepted; automatic translation and global coverage are not validated.
- Published role-based same-domain business emails and tel: phone links are labelled published_unverified, never mailbox-verified or consented. No personal profiles are scraped.
- Requested location is not a verified company address. Size, buyer role, buying intent and deliverability remain unknown unless separately checked.
- This is bounded research automation, not an unattended workforce or unlimited scraper. No LLM is required for the global workflow.

## Handoff between workflows

Save Global discovery JSON, open Supplier qualification, enter a matching industrial supplier brief, and upload under Reuse previous research. This skips repeated discovery searches, but website checks, Hunter enrichment and RFQ research may still consume resources. Other niches remain research-only; the supplier criteria are not a general-purpose scorer for dentists, roofers or all businesses.

## Safety and storage

Hosted or live-configured deployments require owner HTTP Basic authentication over the host's HTTPS connection. Missing/short passwords fail closed except for the minimal /health endpoint. Store passwords and provider keys only in Render environment settings.

ENABLE_LIVE_RUNS defaults to false. DATA_MODE=live alone does not authorize execution. Live calls require an owner password of at least 16 characters. Both workflows share DAILY_LIVE_RUN_LIMIT=1 by default (configurable from 1 to 5). Imported research with public website reads also counts as a live run; zero-page offline imports do not.

Every run requires an Idempotency-Key. Same key and inputs return the saved result; changed inputs conflict. The dashboard retains the same key for retries while its page stays open. Failed and interrupted live runs count toward the UTC daily limit. Uncertain interrupted operations deliberately block new live work until reviewed; they do not retry automatically.

SQLite saves jobs, request keys and counters. These survive only if the database file survives. /tmp on an ephemeral host is not durable: restarts/redeployments can erase results and counters. This is not a provider-account budget or a zero-cost guarantee. Storage, backups, uptime and spending controls still need production validation.

## Validation and limits

164 offline Python tests and 15 Node dashboard-logic checks passed locally on Python 3.12.13. Tests include the prior 108 Python regressions, multi-market queries, provider response contracts, source labelling, imports, exports, login protection, shared limits and duplicate requests. Provider network calls are blocked in tests. No provider credits were spent.

Node tests use a DOM double, not a browser. The new Docker image, Render deployment, visual layout on iPad and global live search are not verified here. Docker runs Python tests at build time. This is a tested build candidate, not an already deployed or globally verified service.

Use DEPLOYMENT.md for activation. Earlier release notes in the working tree are historical; these two documents govern 1.3.0.

Local checks:

    python -m pip install -r requirements.lock
    python -m pytest
    node --test tests/dashboard_logic.cjs tests/global_dashboard.cjs
    python -m scripts.run_autozen_server

The dependency lock records the existing validation environment, not a security audit.

References: [Firecrawl search contract](https://docs.firecrawl.dev/api-reference/endpoint/search), [search credits](https://docs.firecrawl.dev/features/search), [Render Docker](https://render.com/docs/docker), [environment settings](https://render.com/docs/configure-environment-variables), [free-service limits](https://render.com/docs/free).
