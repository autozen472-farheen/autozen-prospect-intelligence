"""Single source of truth for AutoZen release and deployment identity."""

ENGINE_VERSION = "1.3.1"
BUILD_ID = "20260902-03"
BUILD_LABEL = f"v{ENGINE_VERSION} · build {BUILD_ID}"
