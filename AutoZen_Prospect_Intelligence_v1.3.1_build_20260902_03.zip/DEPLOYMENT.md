# AutoZen 1.3.1 — diagnostic update

AutoZen only. Leave villow-lead-engine unchanged. This is not a verified fix for the live connection failure.

## Step 1 — save results and upload the two files

Download any AutoZen job JSON/CSV you want to keep before an upload or deployment. The earlier failed Australia JSON has already been saved; preserve any other wanted results too. The current /tmp database is ephemeral, so redeployment can clear results and usage counters.

Upload these to the existing AutoZen GitHub repository, not Villow:

- AutoZen_Prospect_Intelligence_v1.3.1_build_20260902_03.zip
- Dockerfile_AutoZen_v1.3.1

Keep the ZIP compressed and its name unchanged. Keep the previous version's files. Do not overwrite the active Dockerfile. Uploading alone does not select the new Dockerfile; if GitHub uploads trigger auto-deploy, the old Dockerfile may redeploy.

## Step 2 — activate safely, without a live run

After the upload is confirmed, in Render → autozen-prospect-intelligence:

1. Environment → Edit: set ENABLE_LIVE_RUNS=false. Keep DAILY_LIVE_RUN_LIMIT=1. Save and deploy so the setting takes effect. Do not change provider keys, passwords, DATA_MODE or other limits.
2. Settings → Dockerfile Path: set `./Dockerfile_AutoZen_v1.3.1` and save. If needed, use Manual Deploy → Deploy latest commit once. Do not cancel and repeatedly restart a deployment.
3. Once Render says Live, open AutoZen, sign in and confirm v1.3.1, build 20260902-03. Global discovery should show Live off.

No new service, new provider key or paid hosting upgrade is required for this diagnostic update. Docker defaults also keep live off, but an existing Render environment value overrides those defaults—verify it rather than assuming it.

## Step 3 — check the deployment without spending

Run the existing Fictional demo once. It should show clearly labelled .example records and zero search/public-page requests. This verifies basic deployment behaviour, not Firecrawl connectivity. Keep live off and share the version screen. Do not run Supplier qualification or a new live search in this step.

The error tests were simulated offline. Real diagnostic details will appear only if a later approved live request fails. This release cannot reconstruct details missing from the old failed JSON.

## Any later live test needs a separate decision

The previously approved Australia test has already been attempted. This update does not authorize another paid run. Do not reset the database, change the date, increase the cap or redeploy to bypass the already-used daily allowance. If a redeployment clears its record, that is not a fresh budget approval. Keep live off until timing and spending are explicitly agreed.

For a separately approved test, use one market and at most five search results, and agree the number of website reads. Do not repeatedly search or change API keys on a guess. Export the result JSON, inspect the automatically expanded Search diagnostics, then disable live access again. A failed search may still have been processed or billed; estimate fields cannot settle that.

## Risk, rollback and remaining limits

- Preserve exports before deployments; the current database is not durable. Storage and production uptime remain separate decisions.
- This update improves observability, not lead quality or market coverage. No additional revenue or client-ready status is implied.
- Only a later controlled request can show what happens on Render. Offline tests and a working demo do not prove that connection works.
- If this release fails to deploy, keep live off and provide redacted error text. If rollback is necessary, select the preserved `./Dockerfile_AutoZen_v1.3.0`, not the older unprotected v1.2.6.
- No passwords, API keys or revealed-secret screenshots should be uploaded to GitHub or chat.
- Villow's separate five-step delivery checkpoint remains paused.

References: [Render Docker settings](https://render.com/docs/docker), [environment updates](https://render.com/docs/configure-environment-variables), [free-hosting limitations](https://render.com/docs/free).
