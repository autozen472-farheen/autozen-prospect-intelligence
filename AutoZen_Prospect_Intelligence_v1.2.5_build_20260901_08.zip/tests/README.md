# Current release tests

This suite covers the AutoZen industrial-distributor schema, Firecrawl discovery breadth, request pacing and caching, controlled fallback discovery, visible diagnostics, Hunter enrichment limits, release identity, and the safe UAE demo.

Run `python -m pytest` with the project dependencies and pytest installed. All 62 Python cases block real outbound connections; provider behavior is simulated. The four JSON files in `fixtures/firecrawl` are the supplied historical search exports, not freshly executed searches.

Run `node --test tests/dashboard_logic.cjs` for four dashboard-logic cases. These use a minimal DOM double, not Playwright or a rendered layout. Run `node --check app/static/app.js` for syntax validation.

Neither suite spends provider credits, sends email, or deploys anything. A successful offline suite cannot confirm current provider coverage, billing, or live deployment health.

The obsolete Villow/HVAC-era suite remains preserved in the V1.2.3 archive and is intentionally not part of this release.
