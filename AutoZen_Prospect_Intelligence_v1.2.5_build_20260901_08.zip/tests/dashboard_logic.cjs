// Offline logic tests with a minimal DOM double; not a browser/layout test.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { test } = require('node:test');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'app/static/index.html'), 'utf8');
const script = fs.readFileSync(path.join(root, 'app/static/app.js'), 'utf8');

class Element {
  constructor(tag = 'div') { this.tag = tag; this.children = []; this.events = {}; this.value = ''; this.files = []; this.disabled = false; this.classList = { add() {} }; }
  set textContent(value) { this.text = String(value); this.children = []; }
  get textContent() { return (this.text || '') + this.children.map(c => c.textContent).join(' '); }
  set innerHTML(value) { throw new Error('Unsafe innerHTML assignment'); }
  appendChild(child) { this.children.push(child); return child; }
  replaceChildren(...children) { this.children = children; this.text = ''; }
  addEventListener(event, handler) { this.events[event] = handler; }
  reset() {}
}

const report = {
  raw_results: 160, unique_domains: 129, eligible_domains: 39,
  hunter_enrichment_attempts: 3, enriched_companies: 0,
  queries: [{ query: 'Pumps UAE', results: 40 }],
  candidates: [{ domain: 'unverified.example', source_title: '<script>bad()</script>',
    source_url: 'javascript:bad()', snippet: '<img src=x onerror=bad()>',
    status: 'needs_verification', reasons: ['hunter_record_not_found'],
    hunter_attempted: true, hunter_http_status: 404 }],
};
const delivery = { leads: [], meta: { job_id: 'offline-test', mode: 'live', engine_version: '1.2.5',
  build_id: '20260901-08', duration_ms: 1, warnings: [], candidates_considered: 0, discovery: report } };

function setup({ approve = false, estimateOk = true } = {}) {
  const elements = new Map([...html.matchAll(/id="([^"]+)"/g)].map(m => ['#' + m[1], new Element()]));
  elements.set('.status-dot', new Element());
  const values = { industry: 'Industrial equipment distributors', 'products-or-services': 'Pumps, valves',
    geographies: 'United Arab Emirates', 'employee-min': '5', 'employee-max': '500', 'desired-count': '1',
    'minimum-score': '60', 'target-roles': 'Managing Director' };
  for (const [id, value] of Object.entries(values)) elements.get('#' + id).value = value;
  const calls = [];
  const context = vm.createContext({
    document: { querySelector(selector) { assert(elements.has(selector), `Missing HTML element: ${selector}`); return elements.get(selector); },
      querySelectorAll() { return [{ value: 'quotation_rfq' }]; }, createElement(tag) { return new Element(tag); } },
    window: { confirm: () => approve, setInterval: () => 1, clearInterval() {} },
    URL: class extends URL { static createObjectURL() { return 'blob:offline-test'; } }, Blob,
    fetch: async (url) => {
      calls.push(url);
      if (url === '/v1/status') return { json: async () => ({ data_mode: 'live', engine_version: '1.2.5', build_id: '20260901-08' }) };
      if (url === '/v1/cost-estimate') return { ok: estimateOk, json: async () => ({ hunter: { estimated_max_credits: 6 }, firecrawl: { estimated_max_credits: 104 } }) };
      assert.equal(url, '/v1/leads/generate');
      return { ok: true, json: async () => delivery };
    },
  });
  vm.runInContext(script, context);
  return { context, calls, elements, submit: () => elements.get('#lead-form').events.submit({ preventDefault() {} }) };
}

test('review is separate, literal text is safe, unsafe links are omitted', () => {
  const { context, elements } = setup();
  context.renderDelivery(delivery);
  const section = elements.get('#discovery-details');
  assert.match(section.textContent, /160 search results/);
  assert.match(section.textContent, /Unverified findings are not qualified leads/);
  assert.match(section.textContent, /Hunter has no company record/);
  assert.match(section.textContent, /<script>bad/);
  const card = section.children.find(c => c.className === 'review-card');
  assert(card.open && !card.children.some(c => c.tag === 'a'));
  assert.match(elements.get('#lead-list').textContent, /Search returned results/);
  assert.equal(elements.get('#delivery-title').textContent, '0 ranked leads');
  context.renderDiscovery(null);
  assert(section.hidden && !section.children.length);
});

test('cancelling cost confirmation makes no generate request', async () => {
  const { submit, calls, elements } = setup();
  await submit();
  assert(!calls.includes('/v1/leads/generate'));
  assert(!elements.get('#run-button').disabled);
  assert.match(elements.get('#cost-note').textContent, /104/);
});

test('failed estimate blocks generation', async () => {
  const { submit, calls, elements } = setup({ approve: true, estimateOk: false });
  await submit();
  assert(!calls.includes('/v1/leads/generate'));
  assert.match(elements.get('#form-error').textContent, /No lead-generation request was sent/);
  assert(!elements.get('#run-button').disabled);
});

test('approved run renders diagnostics and blocks duplicate submits', async () => {
  const { submit, calls, elements } = setup({ approve: true });
  await Promise.all([submit(), submit()]);
  assert.equal(calls.filter(x => x === '/v1/leads/generate').length, 1);
  assert(!elements.get('#delivery').hidden && !elements.get('#run-button').disabled);
  assert.match(elements.get('#discovery-details').textContent, /Hunter HTTP status: 404/);
});
