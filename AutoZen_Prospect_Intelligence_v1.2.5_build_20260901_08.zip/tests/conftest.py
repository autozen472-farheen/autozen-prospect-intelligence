"""All regression tests are offline. Any accidental real network call fails."""
import socket

import pytest

from app.adapters.live import FirecrawlSignalSource


@pytest.fixture(autouse=True)
def isolated_providers(monkeypatch):
    def deny_network(*args, **kwargs):
        raise AssertionError("Regression tests must not make real provider calls")

    monkeypatch.setattr(socket.socket, "connect", deny_network)
    monkeypatch.setattr(socket.socket, "connect_ex", deny_network)
    monkeypatch.setattr(socket, "getaddrinfo", deny_network)
    FirecrawlSignalSource._response_cache.clear()
    FirecrawlSignalSource._global_lock = None
    FirecrawlSignalSource._last_request_at = 0.0

    async def no_pacing(self):
        return None

    monkeypatch.setattr(FirecrawlSignalSource, "_wait_for_global_slot", no_pacing)
    yield
    FirecrawlSignalSource._response_cache.clear()
    FirecrawlSignalSource._global_lock = None
