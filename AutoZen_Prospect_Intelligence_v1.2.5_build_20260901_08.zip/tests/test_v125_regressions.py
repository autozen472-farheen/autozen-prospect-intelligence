import asyncio
import csv
import io
import json
from pathlib import Path

import httpx
import pytest

from app.adapters.live import FirecrawlHunterCompanySource, HunterCompanySource, ProviderError
from app.adapters.imported import ImportAwareCompanySource
from app.config import Settings
from app.costing import estimate_zero_cost_usage, search_credit_estimate
from app.discovery import assess_result, search_rows
from app.exporter import delivery_to_csv
from app.factory import build_pipeline
from app.schemas import CompanySeed, LeadDelivery, LeadRequest
from app.store import SQLiteStore


FIXTURES = Path(__file__).parent / "fixtures" / "firecrawl"


def brief(**overrides):
    return LeadRequest(**{
        "products_or_services": "Pumps, valves", "desired_count": 1,
        "minimum_score": 60, **overrides,
    })


def row(domain="alpha.example", title="Pump valve distributor UAE", description="Industrial pumps valves supplier request a quote RFQ"):
    return {"url": f"https://{domain}/products", "title": title, "description": description}


def profile(domain="alpha.example", **overrides):
    return {"domain": domain, "name": domain, "metrics": {"employeesCount": 42},
            "geo": {"country": "United Arab Emirates"}, "category": {"industry": "Wholesale"}, **overrides}


def source_with(rows, response):
    attempts = []
    def handler(request):
        assert request.url.path.endswith("/companies/find")
        attempts.append(request.url.params["domain"])
        return response(request) if callable(response) else response
    source = FirecrawlHunterCompanySource("offline-hunter", "offline-firecrawl", transport=httpx.MockTransport(handler))
    async def search(body):
        return {"data": {"web": rows}}
    source.web_discovery.search = search
    return source, attempts


def test_saved_exports_survive_factory_wrapper_and_storage(tmp_path):
    settings = Settings(data_mode="live", company_provider="hunter", narrative_mode="template",
                        hunter_api_key="offline-hunter", firecrawl_api_key="offline-firecrawl")
    pipeline = build_pipeline(settings)
    source = pipeline.company_source.fallback
    payloads = [json.loads(path.read_text()) for path in sorted(FIXTURES.glob("*.json"))]
    assert len(payloads) == 4
    searches, attempts = [], []
    async def search(body):
        searches.append(body)
        return {"success": True, "data": payloads[len(searches) - 1]}
    def handler(request):
        assert request.url.path.endswith("/companies/find")
        attempts.append(request.url.params["domain"])
        return httpx.Response(404, json={"errors": [{"details": "Synthetic missing record"}]})
    source.web_discovery.search = search
    source.transport = httpx.MockTransport(handler)
    delivery = asyncio.run(pipeline.run(brief()))
    report = delivery.meta.discovery
    assert (report.raw_results, report.unique_domains) == (160, 129)
    assert len(searches) == 4 and not report.fallback_used
    assert report.excluded_results > 0 and report.eligible_domains > 3
    assert len(attempts) == report.hunter_enrichment_attempts == 3
    assert not {"scienticoindia.com", "bestpartssales.com", "naftaar.com"}.intersection(attempts)
    assert report.review_domains == len(report.candidates) > 3
    assert not delivery.leads and delivery.meta.qualified_count == 0
    checked = [item for item in report.candidates if item.hunter_attempted]
    assert all(item.reasons == ["hunter_record_not_found"] for item in checked)
    assert all(item.hunter_http_status == 404 and item.status == "needs_verification" for item in checked)
    assert list(csv.DictReader(io.StringIO(delivery_to_csv(delivery)))) == []
    store = SQLiteStore(tmp_path / "replay.db")
    store.save_delivery(delivery)
    assert store.get_delivery(delivery.meta.job_id).meta.discovery == report
    legacy = delivery.model_dump(mode="json")
    legacy["meta"].pop("discovery")
    assert LeadDelivery.model_validate(legacy).meta.discovery is None


@pytest.mark.parametrize("domain,title,description", [
    ("glassdoor.co.uk", "Pump distributor UAE", "Industrial supplier RFQ"),
    ("jobs.example", "Pump sales jobs Dubai", "Industrial supplier RFQ"),
    ("list.example", "Top 10 pump suppliers UAE", "Industrial supplier RFQ"),
    ("lab.example", "Pump apparatus UAE supplier", "Educational test rig equipment"),
    ("other.example", "Food distributor UAE", "Coffee tea supplier RFQ"),
])
def test_irrelevant_results_never_enter_company_pool(domain, title, description):
    assert not assess_result(row(domain, title, description), brief()).company_like


@pytest.mark.parametrize("title,domain,reason", [
    ("Pump valve supplier", "sample.ae", "target_location_unverified"),
    ("Pump valve supplier India", "sample.example", "other_market_in_title"),
])
def test_country_domain_and_foreign_title_not_local_proof(title, domain, reason):
    assessment = assess_result(row(domain, title, "Pumps valves supplier RFQ"), brief())
    assert assessment.company_like and not assessment.eligible and assessment.reason == reason


@pytest.mark.parametrize("payload", [{"web": None}, {"data": {"news": 3}}, {"data": None}, "bad", None])
def test_malformed_search_buckets_are_safe(payload):
    assert search_rows(payload) == []


def test_malformed_url_is_excluded():
    assert not assess_result({"url": "https://[broken"}, brief()).company_like


@pytest.mark.parametrize("value,expected", [
    ("11-50", (11, 50)), ("10K-50K", (10000, 50000)),
    ("1.5K–2K", (1500, 2000)), ("1,001-5,000", (1001, 5000)),
    ("42", (42, 42)), ("10K+", (10000, 1000000)),
    ("1.5-2.5", (None, None)), ("0+", (None, None)),
    ("50-11", (None, None)), ("unknown", (None, None)),
])
def test_hunter_employee_parsing(value, expected):
    assert HunterCompanySource._parse_headcount(value) == expected


def test_employee_count_integer_is_used():
    company = HunterCompanySource._company_from_payload(profile(), {}, brief())
    assert company.employee_count == 42
    company = HunterCompanySource._company_from_payload(profile(metrics={"employeesCount": True}), {}, brief())
    assert company.employee_count is None


@pytest.mark.parametrize("overrides,reason,status", [
    ({"metrics": {}}, "employee_count_unverified", "needs_verification"),
    ({"geo": {}}, "company_location_unverified", "needs_verification"),
    ({"metrics": {"employeesCount": 5000}}, "employee_range_mismatch", "not_qualified"),
    ({"geo": {"country": "India"}}, "geography_mismatch", "not_qualified"),
    ({"domain": "different.example"}, "hunter_domain_mismatch", "needs_verification"),
    ({"category": {"industry": "Staffing"}}, "industry_mismatch", "not_qualified"),
])
def test_missing_facts_and_actual_mismatches_have_distinct_reasons(overrides, reason, status):
    source, attempts = source_with([row()], httpx.Response(200, json={"data": profile(**overrides)}))
    batch = asyncio.run(source.discover_batch(brief(), 20))
    assert len(attempts) == 1 and batch.companies == []
    item = batch.diagnostics.candidates[0]
    assert item.status == status and reason in item.reasons


@pytest.mark.parametrize("code", [401, 403, 429, 500])
def test_hunter_failure_stops_further_company_calls(code):
    source, attempts = source_with([row(f"test-{i}.example") for i in range(5)], httpx.Response(code, text="SECRET must not enter diagnostics"))
    batch = asyncio.run(source.discover_batch(brief(), 20))
    assert len(attempts) == 1
    assert batch.diagnostics.stopped_reason == f"hunter_http_{code}"
    assert "SECRET" not in batch.diagnostics.model_dump_json()
    assert all(item.reasons == ["provider_stopped_before_lookup"] for item in batch.diagnostics.candidates if not item.hunter_attempted)


@pytest.mark.parametrize("body", [[], {"data": []}, {"data": {}}, {"data": {"tech": 42}}])
def test_malformed_hunter_data_is_diagnostic_not_crash(body):
    source, _ = source_with([row()], httpx.Response(200, json=body))
    batch = asyncio.run(source.discover_batch(brief(), 20))
    assert not batch.companies
    assert batch.diagnostics.candidates[0].reasons == ["hunter_invalid_response"]


def test_firecrawl_error_stops_without_hunter_or_fallback():
    source, attempts = source_with([], httpx.Response(404))
    async def failing_search(body):
        raise ProviderError("SECRET provider error")
    source.web_discovery.search = failing_search
    batch = asyncio.run(source.discover_batch(brief(), 20))
    assert not attempts and len(batch.diagnostics.queries) == 1
    assert not batch.diagnostics.fallback_used
    assert batch.diagnostics.stopped_reason == "firecrawl_unavailable"
    assert "SECRET" not in batch.diagnostics.model_dump_json()


@pytest.mark.parametrize("code,payload,reason", [
    (401, {"error": "SECRET"}, "firecrawl_http_401"),
    (402, {"error": "SECRET"}, "firecrawl_http_402"),
    (429, {"error": "SECRET"}, "firecrawl_http_429"),
    (200, {"success": False}, "firecrawl_invalid_response"),
    (200, {}, "firecrawl_invalid_response"),
])
def test_firecrawl_exact_failure_code_reaches_diagnostics(code, payload, reason):
    calls = []
    def handler(request):
        calls.append(request.url.path)
        assert request.url.path.endswith('/search')
        return httpx.Response(code, json=payload)
    source = FirecrawlHunterCompanySource('offline', 'offline', transport=httpx.MockTransport(handler))
    source.web_discovery.max_attempts = 1
    batch = asyncio.run(source.discover_batch(brief(), 20))
    assert len(calls) == 1 and batch.diagnostics.stopped_reason == reason
    assert batch.diagnostics.queries[0].error == reason
    assert 'SECRET' not in batch.diagnostics.model_dump_json()


def test_diagnostics_are_request_local_and_import_has_no_stale_report():
    source, _ = source_with([], httpx.Response(404))
    async def search(body):
        await asyncio.sleep(0)
        name = "pumps" if "Pumps" in body["query"] else "valves"
        return {"web": [row(f"{name}.example")]}
    source.web_discovery.search = search
    wrapper = ImportAwareCompanySource(source)
    async def run():
        a, b = await asyncio.gather(wrapper.discover_batch(brief(products_or_services="Pumps"), 20), wrapper.discover_batch(brief(products_or_services="Valves"), 20))
        imported = await wrapper.discover_batch(brief(seed_companies=[CompanySeed(name="Import", domain="import.example", industry="Industrial equipment distributors", country="United Arab Emirates", employee_count=42)]), 20)
        return a, b, imported
    a, b, imported = asyncio.run(run())
    assert {item.domain for item in a.diagnostics.candidates} == {"pumps.example"}
    assert {item.domain for item in b.diagnostics.candidates} == {"valves.example"}
    assert a.diagnostics is not b.diagnostics and imported.diagnostics is None


def test_legacy_environment_and_constructor_cannot_widen_hunter_cap(monkeypatch):
    monkeypatch.setenv("HUNTER_CANDIDATE_ATTEMPTS_PER_RUN", "30")
    assert Settings().hunter_candidate_attempts_per_run == 3
    assert HunterCompanySource("offline", max_company_enrichments=30).max_company_enrichments == 3


def test_estimate_counts_results_fallback_retries_and_never_promises_free():
    settings = Settings(data_mode="live", company_provider="hunter", hunter_api_key="offline", firecrawl_api_key="offline")
    estimate = estimate_zero_cost_usage(settings, brief())
    assert search_credit_estimate(40) == 8
    assert estimate["firecrawl"]["focused_discovery_credits"] == 32
    assert estimate["firecrawl"]["credits_before_retries"] == 52
    assert estimate["firecrawl"]["estimated_max_credits"] == 104
    assert estimate["hunter"]["company_enrichment_calls"] == 3
    assert estimate["hunter"]["estimated_max_credits"] == 6
    assert estimate["estimated_cash_charge"] is None
    settings.data_mode = "mock"
    demo = estimate_zero_cost_usage(settings, brief())
    assert demo["hunter"]["estimated_max_credits"] == demo["firecrawl"]["estimated_max_credits"] == 0


@pytest.mark.parametrize("buyer_available,minimum,expected", [(True, 60, "qualified"), (False, 60, "needs_verification"), (True, 100, "not_qualified")])
def test_factory_end_to_end_qualification_with_synthetic_provider_data(buyer_available, minimum, expected):
    settings = Settings(data_mode="live", company_provider="hunter", hunter_api_key="offline", firecrawl_api_key="offline")
    pipeline = build_pipeline(settings)
    def handler(request):
        if request.url.path.endswith("/companies/find"):
            return httpx.Response(200, json={"data": profile()})
        if request.url.path.endswith("/domain-search"):
            emails = [{"first_name": "Test", "last_name": "Buyer", "position": "Managing Director", "decision_maker": True, "type": "personal", "value": "synthetic@alpha.example", "verification": {"status": "valid"}}] if buyer_available else []
            return httpx.Response(200, json={"data": {"emails": emails}})
        if request.url.path.endswith("/search"):
            return httpx.Response(200, json={"data": {"web": [row()]}})
        raise AssertionError(f"Unexpected request: {request.url.path}")
    transport = httpx.MockTransport(handler)
    source = pipeline.company_source.fallback
    source.transport = transport
    source.web_discovery.transport = transport
    pipeline.signal_source.fallback.transport = transport
    delivery = asyncio.run(pipeline.run(brief(minimum_score=minimum)))
    item = delivery.meta.discovery.candidates[0]
    assert item.status == expected
    assert bool(delivery.leads) == (expected == "qualified")
    if expected == "qualified":
        assert delivery.leads[0].company.employee_count == 42
        assert delivery.leads[0].contact.email_status.value == "verified"
        assert len(list(csv.DictReader(io.StringIO(delivery_to_csv(delivery))))) == 1
