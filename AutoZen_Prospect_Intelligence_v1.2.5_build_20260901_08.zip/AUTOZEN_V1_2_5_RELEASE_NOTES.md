# AutoZen Prospect Intelligence v1.2.5

Build: 20260901-08

## Changes

- Conservative company/product/target-location screening before Hunter lookup; excludes common directories, job boards, recruitment pages, listicles, and educational apparatus results unrelated to the brief.
- Four focused queries plus at most one no-eligible-results fallback. No silent Hunter Discover sweep in the Firecrawl/Hunter path.
- Hard maximum of three automatic company-enrichment attempts, even after failed records and even with an older, larger environment value.
- Recognizes Hunter `employeesCount` integers as well as employee bands such as `11-50`, `10K-50K`, and `1.5K–2K`.
- Request-local discovery reports survive the application factory/import wrapper, concurrent runs, JSON serialization, and job storage.
- Separates raw search findings, shortlist eligibility, company-lookup attempts, complete profiles, and qualified delivery. Unknown facts remain unknown.
- Missing Hunter records, malformed data, actual size/location mismatches, unavailable buyers, low scores, and provider failures have distinct diagnostic reasons. Authentication/credit/rate errors are surfaced without copying provider response bodies or secrets.
- The first non-404 Hunter HTTP failure stops further company attempts. Firecrawl temporary retries remain bounded to two attempts per search; authentication failures are not retried.
- Review findings are excluded from the qualified-lead CSV. The JSON includes diagnostics and public search snippets for troubleshooting.
- Corrected credit estimate includes returned-result limits, fallback, web/news research, and retry headroom. The dashboard requires confirmation, blocks double submission during preflight, and fails closed if the estimate is unavailable. This is not server-side authorization or a cash-budget enforcement mechanism.

## Offline evidence

62 Python regression cases passed. The fixture replay uses all four supplied exports (160 results, 129 unique domains) through the actual application factory and import wrapper. Synthetic missing-record responses still produce zero qualified leads, but now retain review findings and record exactly three attempted lookups with explicit 404 reasons. Synthetic full-profile/contact cases independently verify successful qualification and buyer/score rejection paths.

The recorded exports were replayed against the new screening logic. They are historical responses, not evidence that the revised query text was executed or that the next live search will return the same candidates. Live Hunter responses for the failed original run remain unknown.

Four Node dashboard-logic tests cover review separation, literal text rendering and unsafe-link rejection, cancellation, estimate failure, and duplicate-submit prevention. These use a minimal DOM double, not a rendered browser. JavaScript syntax was checked separately.

No live API calls, provider credit spend, email sends, or Render deployments were performed for validation. The local browser preview was blocked; a visual/iPad check remains outstanding. No Docker image build was run.

## Credit estimate basis

Default automatic Firecrawl/Hunter configuration:

- Focused discovery: 4 × 40 requested results, up to 32 Firecrawl credits before retries.
- Possible fallback: up to 8 more credits.
- Research for at most 3 complete profiles: 5 web plus 5 news results each; conservative per-source rounding reserves up to 12 credits.
- Conservative before-retry total: 52; with two attempts per search: 104. Actual use may be lower.
- Hunter planning estimate: 3 company lookups plus up to 3 buyer searches = up to 6 credits. Provider plan rules and balances still apply.

Pricing reference: [Firecrawl search cost implications](https://docs.firecrawl.dev/features/search#cost-implications). Employee field reference: [Hunter company enrichment](https://hunter.io/api/company-enrichment).

The estimate is per run. Repeated or concurrent runs, imports, other clients using the same keys, provider billing changes, and optional OpenAI usage are not covered by an account-wide spending cap. Do not interpret this release as a promise of free operation or guaranteed leads.
