# AutoZen Prospect Intelligence v1.2.5

Evidence-backed global B2B prospecting engine. It discovers companies, verifies ICP fit and geography, researches quotation/RFQ/project/technical-sales evidence, finds requested decision-makers, preserves email verification status, scores prospects deterministically, and exports ranked outreach-ready records.

## Score (100)
- ICP fit: 30
- Commercial/B2B value: 20
- Quotation/RFQ evidence: 20
- Decision-maker & reachability: 15
- Evidence quality: 15

The engine never sends outreach. Weak or unsupported prospects are rejected rather than invented to fill a quota.

## Current operating guardrails

- Firecrawl discovers and ranks company domains before paid contact enrichment.
- Automatic Hunter company enrichment is hard-capped at three attempts per run, including failures. Larger old environment values are clamped to three.
- A single controlled fallback search runs only when focused discovery yields no usable domains.
- Provider diagnostics explain whether results were absent, filtered, or rejected.
- Demo mode uses fictional UAE industrial distributors and never sends messages.

## What changed in this release

Job boards, directories, unrelated products, and unsupported target locations are screened before Hunter company lookup. Unknown size/location and missing provider records are shown as unverified review findings, not silently discarded or promoted to qualified leads. Request-local diagnostics survive the import wrapper and are saved with the job JSON; the qualified-lead CSV contains only delivered leads.

The cost estimate now counts search results, the possible fallback, both research sources, and bounded retries. The dashboard asks before a potentially billable run. This is a planning estimate, **not** an account balance check or an enforced cash budget.

See `AUTOZEN_V1_2_5_RELEASE_NOTES.md` for the offline validation and `DEPLOYMENT.md` for deployment steps. Render and live provider behavior have not been verified for this build.

## Important limitations

- This remains Agent 1. It does not send email or autonomously perform sales/client work.
- The shortlist is a heuristic based on search text. It is not proof of employee count, buying intent, RFQ volume, a local legal entity, or willingness to buy automation.
- Results can still be zero if Hunter coverage, buyer availability, or scoring does not meet the brief. Missing data is not invented. Accept-all email status is not a guarantee of deliverability.
- The configured size-range gate retains the existing overlap policy for provider headcount bands. Exact employee counts, when supplied, take precedence.
- The application has no authentication or server-side per-account budget. A confirmation dialog protects only normal dashboard clicks. Do not treat an unlisted public URL as access control or expose live keys through a publicly usable service without access protection.
- Job data stored under `/tmp` can disappear after a service restart/redeploy. Export important results beforehand.
