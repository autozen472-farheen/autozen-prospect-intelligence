# Deploy AutoZen Lead Researcher v1.2.5

## Files

- `AutoZen_Prospect_Intelligence_v1.2.5_build_20260901_08.zip`
- `Dockerfile_AutoZen_v1.2.5`

Keep the ZIP compressed and upload both files to the same folder at the root of your existing GitHub repository. Preserve the v1.2.4 files for rollback. Never upload API keys.

For a deliberate release switch, set the existing Render service's Dockerfile Path to `./Dockerfile_AutoZen_v1.2.5`, keep the Docker build context at the repository root, and deploy that commit. The external Dockerfile copies the exact versioned ZIP above. The `Dockerfile` inside the archive is for an extracted-source deployment, not this two-file method.

Before redeploying, export any important existing results. The configured `/tmp` database is not durable. If the service already has access protection, preserve it. This release does not add authentication.

## Render environment

Keep these values in the Render service environment:

```text
APP_ENVIRONMENT=demo
DATA_MODE=live
COMPANY_PROVIDER=hunter
NARRATIVE_MODE=template
DATABASE_PATH=/tmp/autozen-prospect-intelligence.db
HUNTER_CANDIDATE_ATTEMPTS_PER_RUN=3
FIRECRAWL_RESULTS_PER_COMPANY=5
```

Store `HUNTER_API_KEY` and `FIRECRAWL_API_KEY` privately in Render. Never add real keys to GitHub or the ZIP.

## First live test

First confirm the header or `/health` reports version `1.2.5`, build `20260901-08`. Merely loading the dashboard or requesting `/v1/cost-estimate` does not call providers.

Only start a live run after reviewing the estimate and your provider balance. Use industrial equipment distributors / Pumps, valves / United Arab Emirates / 5–500 employees / 1 lead / minimum score 60. The default live setup conservatively estimates up to 6 Hunter credits and 104 Firecrawl credits, including fallback and retry headroom; these are not predicted charges. The four focused 40-result searches alone account for up to 32 Firecrawl search credits before retries. Fewer results, caching, and skipped downstream steps can lower usage. OpenAI token costs, if enabled, are additional.

If no lead qualifies, inspect “Discovery and verification” and the expanded review cards. Download the job JSON for diagnosis. Do not repeatedly rerun or raise lookup limits blindly.

## Validation boundary

This build was tested offline against the four supplied search exports with synthetic Hunter responses. No provider credits were spent during validation, and no Render deployment was performed. The browser environment could not open the local preview, so visual/iPad rendering still needs checking after deployment. Docker image construction was not run in this workspace.

## Rollback

Restore the prior Dockerfile Path `./Dockerfile_AutoZen_v1.2.4` and deploy the retained prior ZIP/commit. Database contents under `/tmp` may not survive either deployment.
