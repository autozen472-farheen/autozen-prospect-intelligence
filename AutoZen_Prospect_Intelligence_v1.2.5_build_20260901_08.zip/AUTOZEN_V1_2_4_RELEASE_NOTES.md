# AutoZen Prospect Intelligence v1.2.4

Build: 20260901-07

## Workforce foundation hardening

- Replaces the obsolete US HVAC demo with fictional UAE industrial distributors.
- Aligns the packaged project version with the visible engine version.
- Supports Python 3.12 and newer; the application and focused suite pass on Python 3.12.
- Corrects the Render blueprint to cap Hunter company enrichment at three attempts per run.
- Keeps Firecrawl discovery pacing, caching, fallback diagnostics, and the ban on silent Hunter discovery fallback.
- Namespaces Firecrawl cache entries by configured credential and transport to prevent cross-tenant/test cache reuse.
- Adds current-release tests for the default demo, version identity, and deployment guardrails.
- Retires obsolete Villow/HVAC tests and handoff documents from this AutoZen release while preserving them in the earlier V1.2.3 archive.

## Scope

This remains Agent 1: company discovery, evidence research, qualification, decision-maker enrichment, ranking, and export. It does not send outreach.
