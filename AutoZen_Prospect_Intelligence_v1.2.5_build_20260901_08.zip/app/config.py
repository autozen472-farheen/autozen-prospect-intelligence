from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    data_mode: Literal["mock", "live"] = "mock"
    app_environment: Literal["development", "demo", "production"] = "development"
    company_provider: Literal["auto", "hunter", "apollo"] = "auto"
    narrative_mode: Literal["template", "openai"] = "template"
    database_path: Path = Path("data/lead_engine.db")
    max_concurrency: int = Field(default=4, ge=1, le=10)

    apollo_api_key: str | None = None
    firecrawl_api_key: str | None = None
    hunter_api_key: str | None = None
    # Hard cap on automatic company attempts, including failed lookups.
    # It is not a promise of three qualified leads or an account-wide limit.
    hunter_candidate_attempts_per_run: int = Field(default=3, ge=1, le=3)
    firecrawl_results_per_company: int = Field(default=5, ge=1, le=10)
    openai_api_key: str | None = None
    openai_model: str = "gpt-5.6"

    @field_validator("hunter_candidate_attempts_per_run", mode="before")
    @classmethod
    def enforce_hunter_cap(cls, value):
        # Old Render environment values cannot widen the release's hard cap.
        return min(3, int(value))


    @model_validator(mode="after")
    def validate_configuration(self) -> "Settings":
        if self.narrative_mode == "openai" and not self.openai_api_key:
            raise ValueError("OPENAI_API_KEY is required for NARRATIVE_MODE=openai")
        if self.data_mode == "live" and self.company_provider == "hunter" and not self.hunter_api_key:
            raise ValueError("HUNTER_API_KEY is required for COMPANY_PROVIDER=hunter")
        if self.data_mode == "live" and self.company_provider == "apollo" and not self.apollo_api_key:
            raise ValueError("APOLLO_API_KEY is required for COMPANY_PROVIDER=apollo")
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
