"""Single source of truth for AutoZen release and deployment identity."""

ENGINE_VERSION = "1.2.5"
BUILD_ID = "20260901-08"
BUILD_LABEL = f"v{ENGINE_VERSION} · build {BUILD_ID}"
