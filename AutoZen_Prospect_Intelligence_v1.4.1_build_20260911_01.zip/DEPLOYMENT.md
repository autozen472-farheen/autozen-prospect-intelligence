# AutoZen 1.4.1 free-persistence deployment and acceptance

Use these files together:

- `AutoZen_Prospect_Intelligence_v1.4.1_build_20260911_01.zip`
- `Dockerfile_AutoZen_v1.4.1`
- `supabase_schema.sql` (also included inside the ZIP)

Keep the ZIP compressed in the repository.

## A. Activate the build

1. Upload both files to the existing AutoZen GitHub repository. Do not change Villow.
2. In Render → `autozen-prospect-intelligence` → Settings, set Dockerfile Path to `./Dockerfile_AutoZen_v1.4.1`.
3. Deploy the latest commit once and wait for **Live**.
4. Open `/health`; confirm version `1.4.1`, build `20260911-01`, and storage backend `supabase`.
5. Sign in and confirm all three pages open: Prospecting Agent, Research & Qualification, Prospect Database.

Keep `ENABLE_LIVE_RUNS=false` during these checks.

## B. Configure the free Supabase database

The Render free filesystem is temporary. This release uses a private Supabase project for durable prospect and run-ledger storage.

1. Create a separate Supabase project in the same region as Render.
2. Open Supabase SQL Editor, paste the complete `supabase_schema.sql`, and run it once.
3. In Supabase Project Settings → API Keys, create/copy a private secret key (`sb_secret_...`). Never put it in client-side code or send it in chat/email. A legacy service-role key also remains compatible.
4. In Render Environment, set `STORAGE_BACKEND=supabase`, `SUPABASE_URL=<Project URL>`, `SUPABASE_SECRET_KEY=<private secret key>`, and `PERSISTENT_STORAGE_CONFIRMED=false`.
5. Deploy, add one harmless imported prospect, restart the service, and confirm it remains in `/prospects`.
6. Only then set `PERSISTENT_STORAGE_CONFIRMED=true` and redeploy.

Do not set that variable merely to remove the readiness warning.

## C. One controlled live acceptance

Before enabling live access, confirm private environment values exist: `DASHBOARD_USERNAME`, a password of at least 16 characters, `FIRECRAWL_API_KEY`, and `HUNTER_API_KEY`. Do not send secrets by ordinary email or chat.

1. Set `ENABLE_LIVE_RUNS=true`; keep `DAILY_LIVE_RUN_LIMIT=1`.
2. In Prospecting Agent, search one narrow niche in one market, request up to five results, and set website reads to `0` for the cheapest discovery acceptance.
3. Confirm candidates appear once in Prospect Database and duplicates update rather than multiply.
4. In Research & Qualification, enter the matching ICP, enable **Use saved companies**, request one lead, and review the displayed estimate before approving.
5. Confirm every decision has a grade or an incomplete status, reason, unknowns and source URLs. Export the database CSV.
6. Compare Firecrawl/Hunter logs to the estimate. Do not repeat a failed live run until its saved JSON and diagnostics are reviewed.
7. Set `ENABLE_LIVE_RUNS=false` after acceptance unless the owner approves ongoing use.

## D. Delivery gate

`/v1/readiness` should show:

- `live_data_ready: true`
- `login_configured: true`
- `persistent_storage_confirmed: true`
- `final_delivery_ready: true`

Then provide the client the HTTPS URL and a separate private login. Never share provider API keys or Render access.

If the bounded live test still cannot verify company size or a requested decision-maker, keep the company incomplete/rejected with the exact reason. Change the ICP requirement explicitly instead of spending on repeated runs.
