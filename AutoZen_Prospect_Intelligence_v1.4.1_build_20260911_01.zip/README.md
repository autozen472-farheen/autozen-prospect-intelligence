# AutoZen Prospect Intelligence 1.4.1

Build `20260911-01`. This patch adds private Supabase persistence for free Render deployments. The two-agent product boundary, scoring and provider limits from v1.4.0 are unchanged. Villow is unchanged.

## Product boundary

| Component | Responsibility | Must not claim |
|---|---|---|
| 1. Prospecting Agent (`/global`) | Finds public business websites in up to three markets, screens unsafe/non-company sources, keeps source text, deduplicates domains, and saves candidates. | Qualification, buying intent, permission to contact, verified size or verified buyer. |
| 2. Research & Qualification (`/`) | Verifies first-party company/location evidence, enriches bounded company and buyer data, researches revenue-workflow evidence, applies ICP gates, and assigns A+ / A / B / Reject with reasons. | Missing facts, intent, demand, or certainty that is not in a cited source. |
| Prospect Database (`/prospects`) | Keeps one company per canonical domain plus occurrences, sources, contacts, evidence and latest decision. | Durability unless the deployment has persistent storage. |

The full pipeline is:

1. Company discovery
2. Website verification
3. Business-pain / revenue-workflow research
4. Decision-maker selection (Owner → Founder → Managing Director → CEO/President → General Manager → Sales/BD leadership)
5. Contact enrichment and provider email status
6. Qualification
7. Deterministic scoring and grading
8. Deduplication and storage

## Audit record

An accepted company stores the grade, numerical score, qualification reason, company facts, buyer/contact status and every evidence URL. Rejected and incomplete assessments are also retained. Provider failures are marked incomplete rather than weak. Missing facts remain listed as unknown.

Grades are deterministic: A+ ≥ 90, A ≥ 80, B ≥ the request minimum, otherwise Reject. Hard ICP failures and unusable-buyer failures are explicit rejection reasons.

## Supported evidence

The industrial RFQ/tender/technical-sales evidence remains supported. The v1.4 series adds enquiry funnels, bookings/consultations, site visits/estimates, acquisition activity and published sales-team evidence for niches such as aesthetic or dental clinics, real estate, solar, renovation/fit-out, coaching and consulting.

Evidence signals improve scoring. They do not become unverified claims about demand, conversion performance or buying intent.

## Prospect Database

Database tables are normalized into companies, source occurrences, people and evidence. Domains are canonicalized and repeated discovery updates the same company record. The Research & Qualification dashboard can use saved, unqualified companies without downloading and re-uploading JSON.

For a free Render deployment, set `STORAGE_BACKEND=supabase` and configure `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` privately after running `supabase_schema.sql`. The service-role key stays server-side and the schema enables row-level security without public policies. SQLite remains available for offline/local use. Set `PERSISTENT_STORAGE_CONFIRMED=true` only after a saved prospect survives a Render restart/redeploy.

## Safety and spending controls

- Demo mode is fictional and never enters the real Prospect Database.
- Live runs require private owner authentication, `ENABLE_LIVE_RUNS=true`, and an idempotency key.
- The default daily live-run limit is one.
- Hunter company attempts remain capped at three per run.
- Firecrawl failures stop further searching; whole jobs are not automatically retried.
- The app sends no outreach.
- Provider balances and cash charges cannot be verified by the app; the UI shows bounded request estimates.
- Public-page restrictions, safe URL checks and robots rules remain enforced.

## Main API routes

- `POST /v1/global/discover` — Agent 1 discovery
- `POST /v1/leads/generate` — Agent 2 research and qualification
- `GET /v1/prospects` — deduplicated prospect list
- `GET /v1/prospects/{domain}` — company, sources, people and evidence
- `GET /v1/prospects/export.csv` — prospect database export
- `GET /v1/readiness` — configuration and final-delivery blockers

## Verification status

This build does not become production-finished until:

1. persistent storage is attached and survives a restart;
2. one bounded live discovery → database → qualification test passes;
3. output quality is manually accepted for at least the initial AutoZen niche;
4. provider credit usage is checked against the expected bounded calls.

The packaged regression suite contains 256 offline Python tests and 23 dashboard checks. No paid provider call is required to run it.
