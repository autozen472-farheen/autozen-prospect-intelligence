from __future__ import annotations

import csv
import io

from app.schemas import LeadDelivery


CSV_COLUMNS = [
    "rank",
    "score_total",
    "score_icp_fit",
    "score_timing",
    "score_reachability",
    "score_evidence_quality",
    "company_name",
    "domain",
    "website",
    "industry",
    "location",
    "employee_count",
    "employee_count_range",
    "technologies",
    "active_job_count",
    "contact_name",
    "contact_title",
    "contact_email",
    "email_status",
    "email_type",
    "contact_phone",
    "phone_type",
    "linkedin_url",
    "company_source_url",
    "contact_source_url",
    "why_now",
    "outreach_hook",
    "narrative_confidence",
    "signals",
    "evidence_titles",
    "evidence_urls",
    "evidence_dates",
    "warnings",
]


def delivery_to_csv(delivery: LeadDelivery) -> str:
    output = io.StringIO(newline="")
    writer = csv.DictWriter(output, fieldnames=CSV_COLUMNS)
    writer.writeheader()
    for lead in delivery.leads:
        writer.writerow(
            {
                "rank": lead.rank,
                "score_total": lead.score.total,
                "score_icp_fit": lead.score.icp_fit,
                "score_timing": lead.score.timing,
                "score_reachability": lead.score.reachability,
                "score_evidence_quality": lead.score.evidence_quality,
                "company_name": lead.company.name,
                "domain": lead.company.domain,
                "website": lead.company.website,
                "industry": lead.company.industry,
                "location": lead.company.location_text,
                "employee_count": lead.company.employee_count,
                "employee_count_range": lead.company.employee_count_text,
                "technologies": " | ".join(lead.company.technologies),
                "active_job_count": lead.company.active_job_count,
                "contact_name": lead.contact.name,
                "contact_title": lead.contact.title,
                "contact_email": lead.contact.email,
                "email_status": lead.contact.email_status.value,
                "email_type": lead.contact.email_type.value,
                "contact_phone": lead.contact.phone,
                "phone_type": lead.contact.phone_type.value,
                "linkedin_url": lead.contact.linkedin_url,
                "company_source_url": lead.company.source_url,
                "contact_source_url": lead.contact.source_url,
                "why_now": lead.narrative.why_now,
                "outreach_hook": lead.narrative.outreach_hook,
                "narrative_confidence": lead.narrative.confidence,
                "signals": " | ".join(
                    dict.fromkeys(item.signal_type.value for item in lead.evidence)
                ),
                "evidence_titles": " | ".join(
                    item.title for item in lead.evidence
                ),
                "evidence_urls": " | ".join(item.url for item in lead.evidence),
                "evidence_dates": " | ".join(
                    item.published_at.isoformat() if item.published_at else "undated"
                    for item in lead.evidence
                ),
                "warnings": " | ".join(lead.narrative.warnings),
            }
        )
    return output.getvalue()
