from datetime import date

from app.schemas import (
    CompanyCandidate,
    Contact,
    EmailStatus,
    Evidence,
    LeadRequest,
    ScoreBreakdown,
    SignalType,
)


def _normalise(value: str) -> str:
    return " ".join(value.lower().replace("&", "and").split())


def _token_overlap(left: str, right: str) -> bool:
    left_tokens = set(_normalise(left).split())
    right_tokens = set(_normalise(right).split())
    return bool(left_tokens & right_tokens)


def _industry_matches(requested: str, actual: str) -> bool:
    if _token_overlap(requested, actual):
        return True
    requested_normalised = _normalise(requested)
    actual_normalised = _normalise(actual)
    # Hunter often classifies local HVAC contractors under a broader NAICS-style
    # service category instead of literally returning "HVAC".  These are still
    # valid HVAC-company categories; unrelated recruiting/software/marketing
    # companies remain excluded.
    alias_groups = [
        {
            "hvac",
            "heating",
            "air conditioning",
            "mechanical services",
            "specialty trade contractors",
            "building equipment contractors",
            "repair and maintenance",
            "facilities services",
        },
    ]
    return any(
        any(alias in requested_normalised for alias in group)
        and any(alias in actual_normalised for alias in group)
        for group in alias_groups
    )


def _geography_matches(geographies: list[str], location: str) -> bool:
    location_normalised = _normalise(location)
    alias_groups = [
        {"united states", "usa", "u.s.", "us"},
        {"united kingdom", "uk", "u.k.", "great britain"},
    ]
    for geography in geographies:
        requested = _normalise(geography)
        if requested in location_normalised:
            return True
        for group in alias_groups:
            if requested in group and any(alias in location_normalised for alias in group):
                return True
    return False


def passes_hard_filters(request: LeadRequest, company: CompanyCandidate) -> bool:
    return not hard_filter_failures(request, company)


def hard_filter_failures(
    request: LeadRequest, company: CompanyCandidate
) -> list[str]:
    failures: list[str] = []
    if not _industry_matches(request.industry, company.industry):
        failures.append("industry")
    if not _employee_range_matches(request, company):
        failures.append("employee range")
    if not _geography_matches(request.geographies, company.location_text):
        failures.append("geography")
    return failures


def _employee_range_matches(
    request: LeadRequest, company: CompanyCandidate
) -> bool:
    if company.employee_count is not None:
        return request.employee_min <= company.employee_count <= request.employee_max
    if company.employee_count_min is None or company.employee_count_max is None:
        return False
    return (
        request.employee_min <= company.employee_count_min
        and company.employee_count_max <= request.employee_max
    )


def score_candidate(
    request: LeadRequest,
    company: CompanyCandidate,
    evidence: list[Evidence],
    contact: Contact,
) -> ScoreBreakdown:
    icp_fit = 0
    if _industry_matches(request.industry, company.industry):
        icp_fit += 15
    if _employee_range_matches(request, company):
        icp_fit += 15
    if _geography_matches(request.geographies, company.location_text):
        icp_fit += 10

    timing_weights = {
        SignalType.HIRING: 10,
        SignalType.EXPANSION: 12,
        SignalType.FUNDING: 8,
        SignalType.TECHNOLOGY_CHANGE: 6,
        SignalType.RECENT_NEWS: 4,
    }
    best_by_type: dict[SignalType, Evidence] = {}
    for item in evidence:
        existing = best_by_type.get(item.signal_type)
        if existing is None or item.confidence > existing.confidence:
            best_by_type[item.signal_type] = item
    timing = min(
        30,
        round(
            sum(
                timing_weights[item.signal_type]
                * item.confidence
                * (1 if item.signal_type in request.desired_signals else 0.5)
                for item in best_by_type.values()
            )
        ),
    )

    reachability = 0
    title = _normalise(contact.title or "")
    if title and any(_normalise(role) in title for role in request.target_roles):
        reachability += 5
    elif title and any(
        seniority in title
        for seniority in ("owner", "founder", "chief", "president", "director", "head")
    ):
        reachability += 4
    if contact.email_status == EmailStatus.VERIFIED:
        reachability += 10
    elif contact.email_status == EmailStatus.ACCEPT_ALL:
        reachability += 6
    elif contact.email_status == EmailStatus.RISKY:
        reachability += 3
    if contact.phone:
        reachability = min(15, reachability + 2)

    evidence_quality = 0
    unique_urls = {item.url for item in evidence if item.url.startswith("http")}
    evidence_quality += min(5, len(unique_urls) * 2)
    if evidence:
        evidence_quality += round(max(item.confidence for item in evidence) * 5)
    dated_items = [item for item in evidence if item.published_at]
    if dated_items:
        freshest_days = min((date.today() - item.published_at).days for item in dated_items)
        if freshest_days <= request.freshness_days:
            evidence_quality += 5
        elif freshest_days <= request.freshness_days * 2:
            evidence_quality += 2
    evidence_quality = min(15, evidence_quality)

    total = min(100, icp_fit + timing + reachability + evidence_quality)
    return ScoreBreakdown(
        icp_fit=icp_fit,
        timing=timing,
        reachability=reachability,
        evidence_quality=evidence_quality,
        total=total,
    )
