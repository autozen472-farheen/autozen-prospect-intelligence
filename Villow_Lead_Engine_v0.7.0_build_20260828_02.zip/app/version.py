"""Single source of truth for release and deployment identity."""

ENGINE_VERSION = "0.7.0"
BUILD_ID = "20260828-02"
BUILD_LABEL = f"v{ENGINE_VERSION} · build {BUILD_ID}"
