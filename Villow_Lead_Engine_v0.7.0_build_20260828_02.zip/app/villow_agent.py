from __future__ import annotations

import secrets
from typing import Any

from pydantic import ValidationError
from villow import Agent, Artifact, ProgressEvent, Question, task_template

from app.config import Settings, get_settings
from app.factory import build_pipeline
from app.pipeline import LeadPipeline
from app.schemas import LeadRequest, SignalType
from app.store import SQLiteStore
from app.version import BUILD_ID, ENGINE_VERSION


TASK_SLUG = "generate_ranked_leads"

DEFAULT_TARGET_ROLES = [
    "Owner",
    "Founder",
    "CEO",
    "President",
    "Head of Sales",
    "Marketing Director",
]

DEFAULT_SIGNALS = [SignalType.HIRING.value, SignalType.EXPANSION.value]
_DEMO_SIGNING_SECRET = secrets.token_urlsafe(48)


class VillowLeadAgent(Agent):
    """Villow contract layer for the evidence-backed lead engine."""

    def __init__(
        self,
        *,
        lead_pipeline: LeadPipeline | None = None,
        lead_store: SQLiteStore | None = None,
        settings: Settings | None = None,
        **agent_kwargs: Any,
    ) -> None:
        resolved_settings = settings or get_settings()
        self.lead_pipeline = lead_pipeline or build_pipeline(resolved_settings)
        self.lead_store = lead_store or SQLiteStore(resolved_settings.database_path)
        super().__init__(**agent_kwargs)

    @task_template(TASK_SLUG)
    def prepare_generate_ranked_leads(
        self, inputs: dict[str, Any], ctx: Any
    ) -> dict[str, Any]:
        combined = {**inputs, **ctx.answers}
        questions = _missing_input_questions(combined)
        if questions:
            return ctx.request_clarification(questions)

        normalized = _normalize_inputs(combined)
        try:
            request = LeadRequest.model_validate(normalized)
        except ValidationError as error:
            return ctx.request_clarification(
                [
                    Question.text(
                        id="corrected_brief",
                        label=(
                            "Please correct the lead brief. The current values are invalid: "
                            f"{_validation_summary(error)}"
                        ),
                        default=None,
                        max_length=1_000,
                        decide_for_me={
                            "label": "Use the recommended safe defaults",
                            "value": "use_safe_defaults",
                        },
                    )
                ]
            )

        return ctx.ready_to_authorize(
            normalized_inputs=request.model_dump(mode="json"),
            price_units={},
        )

    @task_template(TASK_SLUG)
    async def run_generate_ranked_leads(
        self, inputs: dict[str, Any], ctx: Any
    ) -> dict[str, Any]:
        request = LeadRequest.model_validate(inputs)

        await ctx.report_progress(
            ProgressEvent.milestone(
                id="company_discovery",
                state="running",
                label="Discovering and deduplicating companies",
            )
        )
        delivery = await self.lead_pipeline.run(request)
        self.lead_store.save_delivery(delivery)

        await ctx.report_progress(
            ProgressEvent.milestone(
                id="qualification_complete",
                state="completed",
                label=f"Qualified and ranked {len(delivery.leads)} leads",
            )
        )
        artifact = _delivery_table_artifact(delivery)
        await ctx.stage_artifact(artifact)

        ctx.set_agent_state(
            {
                "last_job_id": delivery.meta.job_id,
                "last_lead_count": len(delivery.leads),
                "last_mode": delivery.meta.mode,
                "engine_version": ENGINE_VERSION,
                "build_id": BUILD_ID,
            }
        )
        return {
            "accepted": True,
            "job_id": delivery.meta.job_id,
            "qualified_count": len(delivery.leads),
            "warnings": delivery.meta.warnings,
            "engine_version": ENGINE_VERSION,
            "build_id": BUILD_ID,
        }


def build_villow_agent(settings: Settings | None = None) -> VillowLeadAgent:
    resolved = settings or get_settings()
    if resolved.app_environment == "demo":
        publisher_id = resolved.villow_publisher_id or "publisher_demo"
        agent_id = resolved.villow_agent_id or "agent_demo"
        key_id = resolved.villow_signing_key_id or "key_demo"
        secret = resolved.villow_signing_secret or _DEMO_SIGNING_SECRET
    else:
        publisher_id = resolved.villow_publisher_id or "publisher_local"
        agent_id = resolved.villow_agent_id or "agent_local"
        key_id = resolved.villow_signing_key_id or "key_local"
        secret = resolved.villow_signing_secret or "local-secret"
    return VillowLeadAgent(
        settings=resolved,
        publisher_id=publisher_id,
        agent_id=agent_id,
        key_id=key_id,
        secret=secret,
    )


def _delivery_table_artifact(delivery: Any) -> dict[str, Any]:
    columns = [
        "Rank",
        "Company",
        "Location",
        "Employees",
        "Decision maker",
        "Role",
        "Email",
        "Email status",
        "Score",
        "Signals",
        "Why now",
        "Outreach hook",
        "Evidence",
        "Email type",
        "Company source",
        "Contact source",
        "Phone type",
    ]
    rows: list[list[Any]] = []
    for lead in delivery.leads:
        signals = ", ".join(
            dict.fromkeys(
                item.signal_type.value.replace("_", " ") for item in lead.evidence
            )
        )
        evidence = "\n".join(
            f"{item.title} ({item.published_at.isoformat() if item.published_at else 'undated'}): {item.url}"
            for item in lead.evidence
        )
        rows.append(
            [
                lead.rank,
                lead.company.name,
                lead.company.location_text,
                lead.company.employee_count_text,
                lead.contact.name or "Not available",
                lead.contact.title or "Not available",
                lead.contact.email or "Not available",
                lead.contact.email_status.value,
                lead.score.total,
                signals or "No verified timing signal",
                lead.narrative.why_now,
                lead.narrative.outreach_hook,
                evidence or "No evidence URL verified",
                lead.contact.email_type.value,
                lead.company.source_url or "Not available",
                lead.contact.source_url or "Not available",
                lead.contact.phone_type.value,
            ]
        )

    return Artifact.table_data(
        columns=columns,
        rows=rows,
        title=f"Ranked lead intelligence — {len(rows)} leads",
    )


def _missing_input_questions(values: dict[str, Any]) -> list[dict[str, Any]]:
    questions: list[dict[str, Any]] = []
    if not _clean_text(values.get("industry")):
        questions.append(
            Question.text(
                id="industry",
                label="Which industry or niche should the engine target?",
                default=None,
                max_length=100,
                decide_for_me={
                    "label": "Use the HVAC demonstration niche",
                    "value": "HVAC",
                },
            )
        )
    if not _as_list(values.get("geographies")):
        questions.append(
            Question.text(
                id="geographies",
                label="Which country, region, state, or city should the leads be located in?",
                default=None,
                max_length=300,
                decide_for_me={
                    "label": "Use the United States demonstration market",
                    "value": "United States",
                },
            )
        )
    return questions


def _normalize_inputs(values: dict[str, Any]) -> dict[str, Any]:
    if values.get("corrected_brief") == "use_safe_defaults":
        values = {
            **values,
            "employee_min": 10,
            "employee_max": 50,
            "desired_count": 10,
            "freshness_days": 90,
            "minimum_score": 40,
        }

    return {
        "industry": _clean_text(values.get("industry")),
        "geographies": _as_list(values.get("geographies")),
        "employee_min": _as_int(values.get("employee_min"), 10),
        "employee_max": _as_int(values.get("employee_max"), 50),
        "desired_count": _as_int(values.get("desired_count"), 10),
        "target_roles": _as_list(values.get("target_roles")) or DEFAULT_TARGET_ROLES,
        "desired_signals": _normalize_signals(values.get("desired_signals")),
        "freshness_days": _as_int(values.get("freshness_days"), 90),
        "minimum_score": _as_int(values.get("minimum_score"), 40),
        "require_timing_signal": _as_bool(values.get("require_timing_signal"), False),
    }


def _normalize_signals(value: Any) -> list[str]:
    allowed = {item.value for item in SignalType}
    normalized = [
        item.lower().replace(" ", "_").replace("-", "_")
        for item in _as_list(value)
    ]
    selected = [item for item in normalized if item in allowed]
    return selected or DEFAULT_SIGNALS


def _as_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [item.strip() for item in value.split(",") if item.strip()]
    if isinstance(value, (list, tuple, set)):
        return [str(item).strip() for item in value if str(item).strip()]
    return []


def _as_int(value: Any, default: int) -> int:
    if value is None or value == "":
        return default
    if isinstance(value, bool):
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _as_bool(value: Any, default: bool) -> bool:
    if value is None or value == "":
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes", "on"}:
            return True
        if normalized in {"false", "0", "no", "off"}:
            return False
    return default


def _clean_text(value: Any) -> str:
    return str(value or "").strip()


def _validation_summary(error: ValidationError) -> str:
    messages: list[str] = []
    for item in error.errors(include_url=False):
        location = ".".join(str(part) for part in item.get("loc", []))
        messages.append(f"{location}: {item.get('msg', 'invalid value')}")
    return "; ".join(messages)[:700]
