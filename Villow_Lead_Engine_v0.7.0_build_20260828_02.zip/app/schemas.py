from __future__ import annotations

from datetime import date, datetime, timezone
from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field, model_validator

from app.version import BUILD_ID, ENGINE_VERSION


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class SignalType(str, Enum):
    HIRING = "hiring"
    EXPANSION = "expansion"
    FUNDING = "funding"
    TECHNOLOGY_CHANGE = "technology_change"
    RECENT_NEWS = "recent_news"


class EmailStatus(str, Enum):
    VERIFIED = "verified"
    ACCEPT_ALL = "accept_all"
    RISKY = "risky"
    INVALID = "invalid"
    UNKNOWN = "unknown"
    UNAVAILABLE = "unavailable"


class EmailType(str, Enum):
    PERSON_WORK = "person_work"
    GENERIC_COMPANY = "generic_company"
    PERSONAL = "personal"
    UNKNOWN = "unknown"
    UNAVAILABLE = "unavailable"


class PhoneType(str, Enum):
    PERSON = "person"
    GENERIC_COMPANY = "generic_company"
    UNKNOWN = "unknown"
    UNAVAILABLE = "unavailable"


class SeedEvidence(BaseModel):
    signal_type: SignalType
    title: str = Field(min_length=2, max_length=300)
    url: str
    snippet: str = Field(default="", max_length=2_000)
    published_at: date | None = None
    confidence: float = Field(default=0.7, ge=0, le=1)


class CompanySeed(BaseModel):
    """Provider-neutral company input used for CSV/API imports."""

    name: str = Field(min_length=2, max_length=200)
    domain: str = Field(min_length=3, max_length=255)
    website: str | None = None
    industry: str = Field(min_length=2, max_length=150)
    city: str | None = None
    state: str | None = None
    country: str | None = None
    employee_count: int | None = Field(default=None, ge=1, le=1_000_000)
    technologies: list[str] = Field(default_factory=list)
    active_job_count: int | None = Field(default=None, ge=0, le=1_000_000)
    contact_name: str | None = None
    contact_title: str | None = None
    contact_email: str | None = None
    email_type: EmailType = EmailType.UNKNOWN
    contact_phone: str | None = None
    phone_type: PhoneType = PhoneType.UNKNOWN
    linkedin_url: str | None = None
    company_source_url: str | None = None
    contact_source_url: str | None = None
    evidence: list[SeedEvidence] = Field(default_factory=list, max_length=20)


class LeadRequest(BaseModel):
    industry: str = Field(default="HVAC", min_length=2, max_length=100)
    geographies: list[str] = Field(default_factory=lambda: ["United States"])
    employee_min: int = Field(default=10, ge=1, le=100_000)
    employee_max: int = Field(default=50, ge=1, le=100_000)
    desired_count: int = Field(default=10, ge=1, le=50)
    target_roles: list[str] = Field(
        default_factory=lambda: [
            "Owner",
            "Founder",
            "CEO",
            "President",
            "Head of Sales",
            "Marketing Director",
        ]
    )
    desired_signals: list[SignalType] = Field(
        default_factory=lambda: [SignalType.HIRING, SignalType.EXPANSION]
    )
    freshness_days: int = Field(default=90, ge=7, le=730)
    minimum_score: int = Field(default=40, ge=0, le=100)
    # Timing signals improve ranking, but are not a hidden eligibility gate by
    # default. The dashboard labels these as signals to *prioritize*, so an
    # otherwise valid ICP match must not disappear simply because no recent
    # hiring/expansion event was found.
    require_timing_signal: bool = False
    seed_companies: list[CompanySeed] = Field(
        default_factory=list,
        max_length=100,
        exclude=True,
        description=(
            "Optional provider-neutral companies imported from CSV or another data "
            "source. Omitted from the stored response payload."
        ),
    )

    @model_validator(mode="after")
    def validate_ranges(self) -> "LeadRequest":
        if self.employee_max < self.employee_min:
            raise ValueError("employee_max must be greater than or equal to employee_min")
        if not self.geographies:
            raise ValueError("At least one geography is required")
        if not self.target_roles:
            raise ValueError("At least one target role is required")
        return self


class CompanyCandidate(BaseModel):
    provider_id: str
    name: str
    domain: str
    website: str
    industry: str
    city: str | None = None
    state: str | None = None
    country: str | None = None
    employee_count: int | None = None
    employee_count_min: int | None = None
    employee_count_max: int | None = None
    technologies: list[str] = Field(default_factory=list)
    active_job_count: int | None = None
    public_phone: str | None = None
    source_provider: str
    source_url: str | None = None

    @property
    def location_text(self) -> str:
        return ", ".join(
            part for part in (self.city, self.state, self.country) if part
        )

    @property
    def employee_count_text(self) -> str:
        if self.employee_count is not None:
            return str(self.employee_count)
        if self.employee_count_min is not None and self.employee_count_max is not None:
            return f"{self.employee_count_min}-{self.employee_count_max}"
        return "Unknown"


class Evidence(BaseModel):
    signal_type: SignalType
    title: str
    url: str
    snippet: str
    source_provider: str
    published_at: date | None = None
    observed_at: datetime = Field(default_factory=utc_now)
    confidence: float = Field(ge=0, le=1)


class Contact(BaseModel):
    name: str | None = None
    title: str | None = None
    email: str | None = None
    email_status: EmailStatus = EmailStatus.UNAVAILABLE
    email_type: EmailType = EmailType.UNAVAILABLE
    phone: str | None = None
    phone_type: PhoneType = PhoneType.UNAVAILABLE
    linkedin_url: str | None = None
    source_provider: str
    source_url: str | None = None


class ScoreBreakdown(BaseModel):
    icp_fit: int = Field(ge=0, le=40)
    timing: int = Field(ge=0, le=30)
    reachability: int = Field(ge=0, le=15)
    evidence_quality: int = Field(ge=0, le=15)
    total: int = Field(ge=0, le=100)


class Narrative(BaseModel):
    why_now: str
    outreach_hook: str
    confidence: float = Field(ge=0, le=1)
    warnings: list[str] = Field(default_factory=list)


class LeadRecord(BaseModel):
    rank: int = Field(ge=1)
    company: CompanyCandidate
    contact: Contact
    evidence: list[Evidence]
    score: ScoreBreakdown
    narrative: Narrative


class DeliveryMeta(BaseModel):
    job_id: str
    mode: Literal["mock", "live", "import"]
    generated_at: datetime = Field(default_factory=utc_now)
    requested_count: int
    candidates_considered: int
    qualified_count: int
    duration_ms: int = Field(ge=0)
    warnings: list[str] = Field(default_factory=list)
    rejection_summary: dict[str, int] = Field(default_factory=dict)
    engine_version: str = ENGINE_VERSION
    build_id: str = BUILD_ID


class LeadDelivery(BaseModel):
    request: LeadRequest
    meta: DeliveryMeta
    leads: list[LeadRecord]


class OutcomeEvent(BaseModel):
    job_id: str
    company_domain: str
    outcome: Literal[
        "approved",
        "rejected",
        "contacted",
        "replied",
        "booked",
        "converted",
    ]
    note: str | None = Field(default=None, max_length=1_000)
    recorded_at: datetime = Field(default_factory=utc_now)
