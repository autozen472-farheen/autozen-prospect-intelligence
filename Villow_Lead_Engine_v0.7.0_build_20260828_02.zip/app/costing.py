from __future__ import annotations

from app.config import Settings
from app.schemas import LeadRequest


HUNTER_FREE_MONTHLY_CREDITS = 50
FIRECRAWL_FREE_MONTHLY_CREDITS = 1_000


def estimate_zero_cost_usage(
    settings: Settings, request: LeadRequest
) -> dict[str, object]:
    """Return a conservative per-run estimate without reading or exposing keys."""

    imported_count = len(request.seed_companies)
    automatic_hunter = (
        not imported_count
        and settings.data_mode == "live"
        and (
            settings.company_provider == "hunter"
            or (settings.company_provider == "auto" and bool(settings.hunter_api_key))
        )
    )
    candidate_cap = (
        min(imported_count, 100)
        if imported_count
        else settings.hunter_candidate_attempts_per_run
        if automatic_hunter
        else min(100, max(request.desired_count * 4, 20))
    )

    qualified_pool_cap = (
        min(candidate_cap, max(request.desired_count * 3, request.desired_count + 3))
        if automatic_hunter
        else candidate_cap
    )

    hunter_company_enrichments = candidate_cap if automatic_hunter else 0
    hunter_contact_lookups = qualified_pool_cap if settings.hunter_api_key else 0
    hunter_max_credits = hunter_company_enrichments + hunter_contact_lookups

    normalized_industry = " ".join(request.industry.lower().replace("&", "and").split())
    hybrid_hvac_discovery = (
        automatic_hunter
        and bool(settings.firecrawl_api_key)
        and normalized_industry
        in {
            "hvac",
            "heating",
            "air conditioning",
            "heating and air conditioning",
            "mechanical services",
        }
    )
    firecrawl_discovery_searches = 2 if hybrid_hvac_discovery else 0
    firecrawl_signal_searches = qualified_pool_cap if settings.firecrawl_api_key else 0
    firecrawl_searches = firecrawl_discovery_searches + firecrawl_signal_searches
    # Search across web + news is budgeted conservatively at up to two credits.
    firecrawl_max_credits = (
        firecrawl_discovery_searches + firecrawl_signal_searches * 2
    )

    warnings: list[str] = []
    if request.desired_count > settings.hunter_candidate_attempts_per_run:
        warnings.append(
            "The requested lead count is above the zero-cost Hunter enrichment cap; "
            "the run can return fewer leads than requested."
        )
    if settings.data_mode == "live" and not settings.hunter_api_key:
        warnings.append("Hunter is not configured; automatic free discovery is unavailable.")
    if settings.data_mode == "live" and not settings.firecrawl_api_key:
        warnings.append(
            "Firecrawl is not configured; automatic current-signal research is unavailable."
        )

    return {
        "currency": "AED",
        "estimated_cash_charge": 0,
        "assumption": (
            "Hunter and Firecrawl free plans are active and paid auto-upgrades are disabled. "
            "Providers can stop requests when free allowances are exhausted."
        ),
        "candidate_cap": candidate_cap,
        "qualified_pool_cap": qualified_pool_cap,
        "hunter": {
            "discover_calls": 0 if hybrid_hvac_discovery else 2 if automatic_hunter else 0,
            "company_enrichment_calls": hunter_company_enrichments,
            "contact_lookup_calls": hunter_contact_lookups,
            "estimated_max_credits": hunter_max_credits,
            "free_monthly_credits": HUNTER_FREE_MONTHLY_CREDITS,
        },
        "firecrawl": {
            "search_calls": firecrawl_searches,
            "company_discovery_searches": firecrawl_discovery_searches,
            "signal_research_searches": firecrawl_signal_searches,
            "estimated_max_credits": firecrawl_max_credits,
            "free_monthly_credits": FIRECRAWL_FREE_MONTHLY_CREDITS,
        },
        "warnings": warnings,
    }
