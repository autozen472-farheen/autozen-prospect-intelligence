from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    data_mode: Literal["mock", "live"] = "mock"
    app_environment: Literal["development", "demo", "production"] = "development"
    company_provider: Literal["auto", "hunter", "apollo"] = "auto"
    narrative_mode: Literal["template", "openai"] = "template"
    database_path: Path = Path("data/lead_engine.db")
    max_concurrency: int = Field(default=4, ge=1, le=10)

    apollo_api_key: str | None = None
    firecrawl_api_key: str | None = None
    hunter_api_key: str | None = None
    # The renamed variable replaces the early three-company test guardrail that
    # can remain in an already-created Render service.
    # Candidate attempts, not promised leads. Three requested verified buyers
    # generally require a wider company pool because firmographics and contact
    # availability are only known after provider lookups.
    hunter_candidate_attempts_per_run: int = Field(default=18, ge=3, le=30)
    firecrawl_results_per_company: int = Field(default=5, ge=1, le=10)
    openai_api_key: str | None = None
    openai_model: str = "gpt-5.6"

    villow_publisher_id: str | None = None
    villow_agent_id: str | None = None
    villow_signing_key_id: str | None = None
    villow_signing_secret: str | None = None

    @model_validator(mode="after")
    def validate_configuration(self) -> "Settings":
        if self.narrative_mode == "openai" and not self.openai_api_key:
            raise ValueError("OPENAI_API_KEY is required for NARRATIVE_MODE=openai")
        if self.data_mode == "live" and self.company_provider == "hunter" and not self.hunter_api_key:
            raise ValueError("HUNTER_API_KEY is required for COMPANY_PROVIDER=hunter")
        if self.data_mode == "live" and self.company_provider == "apollo" and not self.apollo_api_key:
            raise ValueError("APOLLO_API_KEY is required for COMPANY_PROVIDER=apollo")
        if self.app_environment == "production" and not all(
            (
                self.villow_publisher_id,
                self.villow_agent_id,
                self.villow_signing_key_id,
                self.villow_signing_secret,
            )
        ):
            raise ValueError(
                "All Villow identifiers and signing credentials are required in production"
            )
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
