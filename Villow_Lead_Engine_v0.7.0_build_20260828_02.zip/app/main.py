from functools import lru_cache
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

from app.adapters.live import ProviderError
from app.config import Settings, get_settings
from app.costing import estimate_zero_cost_usage
from app.exporter import delivery_to_csv
from app.factory import build_pipeline
from app.pipeline import LeadPipeline
from app.schemas import LeadDelivery, LeadRequest, OutcomeEvent
from app.store import SQLiteStore
from app.version import BUILD_ID, BUILD_LABEL, ENGINE_VERSION


app = FastAPI(
    title="Villow Lead Intelligence Engine",
    version=ENGINE_VERSION,
    description=(
        "Evidence-backed company discovery, signal research, contact enrichment, "
        "deterministic scoring, and ranked lead delivery."
    ),
)

STATIC_DIR = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@lru_cache
def store() -> SQLiteStore:
    return SQLiteStore(get_settings().database_path)


@lru_cache
def pipeline() -> LeadPipeline:
    return build_pipeline(get_settings())


@app.get("/health")
async def health() -> dict[str, str]:
    settings = get_settings()
    return {
        "status": "ok",
        "engine_version": ENGINE_VERSION,
        "build_id": BUILD_ID,
        "data_mode": settings.data_mode,
        "narrative_mode": settings.narrative_mode,
    }


@app.get("/v1/status")
async def engine_status() -> dict[str, object]:
    settings = get_settings()
    if settings.data_mode != "live":
        company_discovery = "fictional_demo"
    elif settings.company_provider == "hunter" or (
        settings.company_provider == "auto" and settings.hunter_api_key
    ):
        company_discovery = (
            "firecrawl_web+hunter_enrichment"
            if settings.firecrawl_api_key
            else "hunter_discover"
        )
    elif settings.apollo_api_key:
        company_discovery = "apollo"
    else:
        company_discovery = "csv_required"
    return {
        "status": "ready",
        "engine_version": ENGINE_VERSION,
        "build_id": BUILD_ID,
        "build_label": BUILD_LABEL,
        "data_mode": settings.data_mode,
        "narrative_mode": settings.narrative_mode,
        "providers": {
            "company_discovery": company_discovery,
            "signal_research": (
                "firecrawl"
                if settings.data_mode == "live" and settings.firecrawl_api_key
                else "not_configured"
                if settings.data_mode == "live"
                else "fictional_demo"
            ),
            "contact_verification": (
                "hunter"
                if settings.data_mode == "live" and settings.hunter_api_key
                else "not_configured"
                if settings.data_mode == "live"
                else "fictional_demo"
            ),
            "narrative": settings.narrative_mode,
            "csv_import": "available",
        },
        "limits": {"maximum_leads_per_run": 50, "maximum_import_rows": 100},
        "zero_cost_guardrails": {
            "hunter_company_enrichment_limit_per_run": settings.hunter_candidate_attempts_per_run,
            "hunter_estimated_max_credits_per_run": settings.hunter_candidate_attempts_per_run * 2,
            "firecrawl_results_per_company": settings.firecrawl_results_per_company,
            "openai_required": False,
        },
        "outreach_sending": False,
    }


@app.get("/v1/readiness")
async def readiness() -> dict[str, object]:
    settings = get_settings()
    live_blockers: list[str] = []
    if not settings.hunter_api_key:
        live_blockers.append("Add HUNTER_API_KEY privately in the deployment environment.")
    if not settings.firecrawl_api_key:
        live_blockers.append("Add FIRECRAWL_API_KEY privately in the deployment environment.")

    villow_values = (
        settings.villow_publisher_id,
        settings.villow_agent_id,
        settings.villow_signing_key_id,
        settings.villow_signing_secret,
    )
    villow_ready = all(villow_values)
    return {
        "application": "ready",
        "environment": settings.app_environment,
        "demo_ready": True,
        "live_data_ready": not live_blockers,
        "villow_connection_ready": villow_ready,
        "live_data_blockers": live_blockers,
        "villow_blockers": []
        if villow_ready
        else ["Villow credentials are pending until the agent passes their review."],
    }


@app.post("/v1/cost-estimate")
async def cost_estimate(request: LeadRequest) -> dict[str, object]:
    return estimate_zero_cost_usage(get_settings(), request)


@app.get("/", include_in_schema=False)
async def dashboard() -> FileResponse:
    return FileResponse(
        STATIC_DIR / "index.html",
        headers={"Cache-Control": "no-store, max-age=0"},
    )


@app.post("/v1/leads/generate", response_model=LeadDelivery)
async def generate_leads(request: LeadRequest) -> LeadDelivery:
    try:
        delivery = await pipeline().run(request)
    except ProviderError as error:
        raise HTTPException(status_code=503, detail=str(error)) from error
    store().save_delivery(delivery)
    return delivery


@app.get("/v1/jobs")
async def list_jobs(limit: int = 20) -> list[dict[str, object]]:
    return store().list_deliveries(limit=max(1, min(limit, 100)))


@app.get("/v1/jobs/{job_id}", response_model=LeadDelivery)
async def get_job(job_id: str) -> LeadDelivery:
    delivery = store().get_delivery(job_id)
    if delivery is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return delivery


@app.get("/v1/jobs/{job_id}/export.csv")
async def export_job_csv(job_id: str) -> PlainTextResponse:
    delivery = store().get_delivery(job_id)
    if delivery is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return PlainTextResponse(
        delivery_to_csv(delivery),
        media_type="text/csv; charset=utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{job_id}.csv"'
        },
    )


@app.get("/sample/company-import.csv", include_in_schema=False)
async def sample_import_csv() -> FileResponse:
    return FileResponse(
        Path(__file__).parents[1] / "sample" / "company-import.csv",
        media_type="text/csv",
        filename="villow-company-import-template.csv",
    )


@app.post("/v1/outcomes", status_code=201)
async def record_outcome(event: OutcomeEvent) -> dict[str, str]:
    if store().get_delivery(event.job_id) is None:
        raise HTTPException(status_code=404, detail="Job not found")
    store().save_outcome(event)
    return {"status": "recorded"}


@app.get("/v1/jobs/{job_id}/outcomes")
async def get_outcomes(job_id: str) -> list[dict[str, str | None]]:
    if store().get_delivery(job_id) is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return store().list_outcomes(job_id)
