from villow.testing import MockPlatformHarness

from app.villow_agent import TASK_SLUG, VillowLeadAgent


def test_discover_advertises_prepare_handler() -> None:
    harness = MockPlatformHarness(VillowLeadAgent())
    response = harness.post("/discover", {})
    assert response["task_templates"] == [
        {
            "slug": TASK_SLUG,
            "has_prepare": True,
            "has_execute": True,
            "has_preview": False,
        }
    ]


def test_prepare_requests_required_industry_and_geography() -> None:
    harness = MockPlatformHarness(VillowLeadAgent())
    response = harness.post(
        "/prepare",
        {"task_id": "task_missing", "task_template": TASK_SLUG, "initial_inputs": {}},
    )
    assert response["state"] == "clarification_required"
    assert {question["id"] for question in response["questions"]} == {
        "industry",
        "geographies",
    }
    assert all(question.get("decide_for_me") for question in response["questions"])


def test_prepare_normalizes_complete_customer_brief() -> None:
    harness = MockPlatformHarness(VillowLeadAgent())
    response = harness.post(
        "/prepare",
        {
            "task_id": "task_ready",
            "task_template": TASK_SLUG,
            "initial_inputs": {
                "industry": "HVAC",
                "geographies": "Texas, Florida",
                "employee_min": "10",
                "employee_max": "50",
                "desired_count": "12",
                "target_roles": "Owner, Marketing Director",
                "desired_signals": "Hiring, Expansion, unsupported signal",
            },
        },
    )
    assert response["state"] == "ready_to_authorize"
    normalized = response["normalized_inputs"]
    assert normalized["geographies"] == ["Texas", "Florida"]
    assert normalized["employee_min"] == 10
    assert normalized["desired_count"] == 12
    assert normalized["target_roles"] == ["Owner", "Marketing Director"]
    assert normalized["desired_signals"] == ["hiring", "expansion"]
    assert normalized["freshness_days"] == 90
    assert normalized["minimum_score"] == 40


def test_prepare_rejects_invalid_employee_range_with_clarification() -> None:
    harness = MockPlatformHarness(VillowLeadAgent())
    response = harness.post(
        "/prepare",
        {
            "task_id": "task_invalid",
            "task_template": TASK_SLUG,
            "initial_inputs": {
                "industry": "HVAC",
                "geographies": ["United States"],
                "employee_min": 100,
                "employee_max": 20,
            },
        },
    )
    assert response["state"] == "clarification_required"
    assert response["questions"][0]["id"] == "corrected_brief"
    assert response["questions"][0]["decide_for_me"]["value"] == "use_safe_defaults"
