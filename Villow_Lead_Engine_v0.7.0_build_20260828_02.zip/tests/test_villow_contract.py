import json
import time

from fastapi.testclient import TestClient
from villow.signing import sign_request

from app.config import Settings
from app.villow_agent import build_villow_agent


def _signed_headers(
    path: str,
    body: bytes,
    *,
    idempotency_key: str,
    timestamp: int | None = None,
) -> dict[str, str]:
    headers = sign_request(
        method="POST",
        path=path,
        body=body,
        key_id="key_local",
        secret="local-secret",
        publisher_id="publisher_local",
        agent_id="agent_local",
        timestamp=timestamp,
        nonce=f"nonce-{idempotency_key}-{timestamp or 'current'}",
        idempotency_key=idempotency_key,
    )
    headers["content-type"] = "application/json"
    return headers


def test_signed_discover_is_idempotent_and_conflicts_on_changed_body(tmp_path) -> None:
    settings = Settings(database_path=tmp_path / "contract.db")
    client = TestClient(build_villow_agent(settings).asgi_app())
    body = json.dumps({}, separators=(",", ":"), sort_keys=True).encode()
    headers = _signed_headers(
        "/discover", body, idempotency_key="same-discover-request"
    )

    first = client.post("/discover", content=body, headers=headers)
    second = client.post("/discover", content=body, headers=headers)
    assert first.status_code == 200
    assert second.status_code == 200
    assert second.headers["x-worklane-idempotent-replay"] == "true"

    changed_body = json.dumps({"changed": True}, separators=(",", ":"), sort_keys=True).encode()
    changed_headers = _signed_headers(
        "/discover", changed_body, idempotency_key="same-discover-request"
    )
    conflict = client.post("/discover", content=changed_body, headers=changed_headers)
    assert conflict.status_code == 409
    assert conflict.json()["detail"] == "idempotency_key_conflict"


def test_stale_signature_and_malformed_prepare_are_rejected(tmp_path) -> None:
    settings = Settings(database_path=tmp_path / "security.db")
    client = TestClient(build_villow_agent(settings).asgi_app())

    discover_body = b"{}"
    stale = client.post(
        "/discover",
        content=discover_body,
        headers=_signed_headers(
            "/discover",
            discover_body,
            idempotency_key="stale-request",
            timestamp=1,
        ),
    )
    assert stale.status_code == 401

    prepare_payload = {"task_template": "generate_ranked_leads"}
    prepare_body = json.dumps(
        prepare_payload, separators=(",", ":"), sort_keys=True
    ).encode()
    malformed = client.post(
        "/prepare",
        content=prepare_body,
        headers=_signed_headers(
            "/prepare", prepare_body, idempotency_key="malformed-prepare"
        ),
    )
    assert malformed.status_code == 400
    assert malformed.json()["detail"] == "task_id_required"


def test_status_result_and_cancel_lifecycle(tmp_path) -> None:
    settings = Settings(database_path=tmp_path / "lifecycle.db")
    agent = build_villow_agent(settings)
    from villow.testing import MockPlatformHarness

    harness = MockPlatformHarness(agent)
    result = harness.run_task(
        "generate_ranked_leads",
        {
            "industry": "HVAC",
            "geographies": ["United States"],
            "desired_count": 1,
        },
    )
    task_id = result["task_id"]
    assert result["state"] == "completed"
    assert result["artifacts"]

    status = harness.post("/status", {"task_id": task_id})
    assert status["state"] == "artifact_review"

    cancelled = harness.post("/cancel", {"task_id": task_id})
    assert cancelled == {"task_id": task_id, "cancelling": True}
    final_status = harness.post("/status", {"task_id": task_id})
    assert final_status["state"] == "cancelled"
