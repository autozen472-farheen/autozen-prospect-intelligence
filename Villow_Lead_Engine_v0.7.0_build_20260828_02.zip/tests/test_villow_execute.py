from app.config import Settings
from app.factory import build_pipeline
from app.store import SQLiteStore
from app.villow_agent import TASK_SLUG, VillowLeadAgent
from villow.testing import MockPlatformHarness


def test_villow_execute_returns_ranked_table_artifact(tmp_path) -> None:
    settings = Settings(
        data_mode="mock",
        narrative_mode="template",
        database_path=tmp_path / "villow.db",
    )
    lead_store = SQLiteStore(settings.database_path)
    agent = VillowLeadAgent(
        settings=settings,
        lead_pipeline=build_pipeline(settings),
        lead_store=lead_store,
    )
    result = MockPlatformHarness(agent).run_task(
        TASK_SLUG,
        {
            "industry": "HVAC",
            "geographies": ["United States"],
            "employee_min": 10,
            "employee_max": 50,
            "desired_count": 3,
            "target_roles": ["Owner", "President", "Marketing Director"],
            "desired_signals": ["hiring", "expansion"],
            "freshness_days": 90,
            "minimum_score": 55,
        },
    )

    assert result["state"] == "completed"
    assert len(result["artifacts"]) == 1
    artifact = result["artifacts"][0]
    assert artifact["artifact_type"] == "table_data"
    payload = artifact["type_payload"]
    assert payload["columns"][0:3] == ["Rank", "Company", "Location"]
    assert len(payload["rows"]) == 3
    assert [row[0] for row in payload["rows"]] == [1, 2, 3]
    assert [row[8] for row in payload["rows"]] == sorted(
        [row[8] for row in payload["rows"]], reverse=True
    )
    assert all("http" in row[12] for row in payload["rows"])

    job_id = result["agent_state"]["last_job_id"]
    saved = lead_store.get_delivery(job_id)
    assert saved is not None
    assert saved.meta.qualified_count == 3


def test_villow_execute_records_progress_and_artifact_events(tmp_path) -> None:
    settings = Settings(database_path=tmp_path / "events.db")
    agent = VillowLeadAgent(settings=settings)
    harness = MockPlatformHarness(agent)
    task_id = "task_events"
    prepared = harness.post(
        "/prepare",
        {
            "task_id": task_id,
            "task_template": TASK_SLUG,
            "initial_inputs": {
                "industry": "HVAC",
                "geographies": ["United States"],
                "desired_count": 1,
            },
        },
    )
    harness.post(
        "/execute",
        {
            "task_id": task_id,
            "task_template": TASK_SLUG,
            "inputs": prepared["normalized_inputs"],
            "callback_urls": {},
        },
    )
    status = harness.post("/status", {"task_id": task_id})
    kinds = [event["kind"] for event in status["events"]]
    assert kinds == ["status", "status", "artifact_staged"]
    assert status["state"] == "artifact_review"
