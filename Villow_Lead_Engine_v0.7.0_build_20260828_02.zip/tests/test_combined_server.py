from fastapi.testclient import TestClient

from scripts.run_villow_server import app


def test_combined_server_has_dashboard_api_and_villow_routes() -> None:
    client = TestClient(app)
    assert client.get("/health").status_code == 200
    assert client.get("/").status_code == 200
    assert client.get("/v1/status").status_code == 200
    assert client.get("/v1/readiness").status_code == 200
    assert client.post("/discover", json={}).status_code == 401


def test_combined_server_password_protects_dashboard_not_health(monkeypatch) -> None:
    monkeypatch.setenv("DASHBOARD_USERNAME", "reviewer")
    monkeypatch.setenv("DASHBOARD_PASSWORD", "private-demo-password")
    client = TestClient(app)
    assert client.get("/").status_code == 401
    assert client.get("/v1/status").status_code == 401
    assert client.get("/health").status_code == 200
    assert client.get(
        "/", auth=("reviewer", "private-demo-password")
    ).status_code == 200


def test_dashboard_status_exposes_unmistakable_build_identity(monkeypatch) -> None:
    monkeypatch.delenv("DASHBOARD_PASSWORD", raising=False)
    client = TestClient(app)

    dashboard = client.get("/")
    assert dashboard.status_code == 200
    assert dashboard.headers["cache-control"] == "no-store, max-age=0"
    assert "app.js?v=0.7.0-20260828-02" in dashboard.text

    status = client.get("/v1/status")
    assert status.status_code == 200
    assert status.json()["engine_version"] == "0.7.0"
    assert status.json()["build_id"] == "20260828-02"
