from __future__ import annotations

import base64
import os
import secrets

import uvicorn
from fastapi import Request
from fastapi.responses import Response

from app.main import app as dashboard_app
from app.villow_agent import build_villow_agent
from app.version import BUILD_ID, ENGINE_VERSION


agent = build_villow_agent()
app = agent.asgi_app()

# Serve the review dashboard and standalone API beside Villow's signed routes so
# the zero-cost deployment needs only one web service.
existing_paths = {getattr(route, "path", None) for route in app.router.routes}
for route in dashboard_app.router.routes:
    path = getattr(route, "path", None)
    if path in existing_paths or path == "/health":
        continue
    app.router.routes.append(route)
    existing_paths.add(path)


VILLOW_SIGNED_PATHS = {
    "/discover",
    "/prepare",
    "/preview",
    "/execute",
    "/clarification_response",
    "/status",
    "/cancel",
    "/result",
}


@app.middleware("http")
async def protect_dashboard(request: Request, call_next):
    password = os.getenv("DASHBOARD_PASSWORD", "")
    if (
        not password
        or request.url.path == "/health"
        or request.url.path in VILLOW_SIGNED_PATHS
    ):
        return await call_next(request)

    username = os.getenv("DASHBOARD_USERNAME", "evaluator")
    authorization = request.headers.get("authorization", "")
    supplied_username = ""
    supplied_password = ""
    if authorization.startswith("Basic "):
        try:
            decoded = base64.b64decode(authorization[6:]).decode("utf-8")
            supplied_username, supplied_password = decoded.split(":", 1)
        except (ValueError, UnicodeDecodeError):
            pass
    valid = secrets.compare_digest(supplied_username, username) and secrets.compare_digest(
        supplied_password, password
    )
    if not valid:
        return Response(
            status_code=401,
            headers={"WWW-Authenticate": 'Basic realm="Villow Lead Engine"'},
        )
    return await call_next(request)


@app.get("/health", include_in_schema=False)
async def health() -> dict[str, str]:
    return {
        "status": "ok",
        "engine_version": ENGINE_VERSION,
        "build_id": BUILD_ID,
        "publisher_id": agent.publisher_id,
        "agent_id": agent.agent_id,
    }


def main() -> None:
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", "8080")))


if __name__ == "__main__":
    main()
