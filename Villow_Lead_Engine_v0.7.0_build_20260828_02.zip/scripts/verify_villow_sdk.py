from __future__ import annotations

from pathlib import Path

from villow import Agent, Artifact, Stream
from villow.manifest import validate_manifest


def main() -> None:
    manifest_path = Path(__file__).parents[1] / "agent.yaml"
    result = validate_manifest(manifest_path)
    if not result.valid:
        details = "\n".join(f"- {item}" for item in result.errors)
        raise SystemExit(f"Villow manifest failed validation:\n{details}")

    print("Villow SDK 0.1.2 imported successfully.")
    print(
        "Public classes verified:",
        Agent.__name__,
        Artifact.__name__,
        Stream.__name__,
    )
    print(f"Manifest valid: {manifest_path}")
    if result.warnings:
        print("Warnings:")
        for warning in result.warnings:
            print(f"- {warning}")


if __name__ == "__main__":
    main()
