# Villow Lead Intelligence Engine

A lead-generation and qualification engine that turns an ideal customer profile
into a ranked, evidence-backed lead delivery. It includes a standalone review
dashboard and a Villow Python SDK adapter for signed marketplace jobs.

## What the engine does

1. Accepts industry, geography, employee range, target roles and desired signals.
2. Discovers companies through Hunter Discover, Apollo, or a provider-neutral CSV.
3. Deduplicates companies and enforces the ICP filters.
4. Researches hiring, expansion, funding, technology and recent-news signals.
5. Finds a decision-maker and preserves the real email verification status.
6. Applies a deterministic 100-point score before any AI-written narrative.
7. Explains why each lead matters now and proposes an evidence-grounded hook.
8. Saves every job and exports the full delivery as CSV or JSON.
9. Records approval, contact, reply, booking and conversion outcomes.

No outreach is sent by this application.

## Three safe operating paths

| Path | Purpose | External cost |
|---|---|---:|
| Fictional demo | Interface, workflow and scoring demonstration | None |
| Provider CSV import | Use rows exported from any permitted provider | Provider-dependent |
| Zero-cost live APIs | Hunter discovery/contact + Firecrawl signals | AED 0 within free allowances |
| Paid/alternate APIs | Apollo and optional OpenAI narrative | Usage-dependent |

The application starts in fictional demo mode, so running it cannot accidentally
spend API credits or contact a prospect.

## Start the web application

You need Python 3.13 or newer and `uv`.

```bash
uv sync
cp .env.example .env
uv run uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000` for the visual interface or
`http://127.0.0.1:8000/docs` for the API documentation.

Run the combined dashboard + Villow SDK server on port 8080:

```bash
uv run python -m scripts.run_villow_server
```

The dashboard remains at `/`. Signed Villow routes are unprefixed: `/discover`, `/prepare`, `/execute`,
`/clarification_response`, `/status`, `/cancel`, and `/result`.

Until Villow supplies the production identifiers and signing secret, the SDK
server uses local-only placeholders. Add the real values to `.env` at onboarding:

```dotenv
VILLOW_PUBLISHER_ID=
VILLOW_AGENT_ID=
VILLOW_SIGNING_KEY_ID=
VILLOW_SIGNING_SECRET=
```

To run in Docker:

```bash
docker build -t villow-lead-engine .
docker run --rm -p 8080:8080 --env-file .env villow-lead-engine
```

## Run the demonstration and tests

```bash
uv run python -m scripts.demo
uv run pytest
```

The automated suite covers scoring, hard filters, ranking, imported data,
provider fallback behavior, storage, outcomes, CSV export and Villow's signed
prepare/execute/status/result lifecycle.

## Repeat the Step 5 calibration

The included public-source calibration set contains three real US HVAC companies.
It is deliberately small so every company, decision-maker and timing signal can be
manually inspected before provider credits are used.

```bash
uv run python -m scripts.run_calibration
```

The command writes `delivery.json`, `delivery.csv` and `QUALITY_REPORT.md` under
`calibration/latest`. It sends no outreach and consumes no paid API credits.

## Use a CSV from any provider

Download the template from the interface or use `sample/company-import.csv`.
Required columns are:

- `company_name`
- `domain`
- `industry`
- `country`
- `employee_count`

The optional fields include website, city, state, technologies, active job count,
contact name/title/email/phone/LinkedIn, and source-backed signal fields. Repeat a
company row to attach multiple signals; the browser groups the rows by domain.

Imported data is never silently called verified. The output separately preserves
company and contact provenance, distinguishes generic company inboxes from
person-level work email, and warns the user to check rights and evidence before
outreach.

## Configure the AED 0 live route

Do not put secret keys in source code, documents, screenshots or chat. Copy
`.env.example` to `.env` and add only the providers being used:

```dotenv
DATA_MODE=live
COMPANY_PROVIDER=hunter
FIRECRAWL_API_KEY=
HUNTER_API_KEY=
HUNTER_CANDIDATE_ATTEMPTS_PER_RUN=18
NARRATIVE_MODE=template
```

- For HVAC, Firecrawl discovers first-party contractor websites and rejects
  directories, recruiters, software vendors and marketing companies before Hunter
  enriches employee/geography data and finds a decision-maker. Hunter Discover
  remains the fallback and the discovery path for other industries.
- Firecrawl searches recent web/news evidence for the requested buying signals.
- Dashboard-selected signals improve ranking; an ICP-qualified company without a
  verified current signal remains eligible and is labelled honestly. API callers
  can still set `require_timing_signal=true` for a strict evidence-only brief.
- Template narrative mode requires no paid LLM call and never changes the score.
- The default three-lead run can attempt up to 18 company enrichments and build
  a pool of up to nine ICP-matched companies. Contact lookup happens only for
  that prequalified pool, for a conservative maximum of 27 Hunter credits.
- `POST /v1/cost-estimate` shows the conservative credit budget before a run.
- If the free allowance is exhausted, stop and wait for renewal; do not enable a
  paid upgrade unless a client approves it.

OpenAI is optional and not used in the zero-cost configuration. Apollo remains an
alternate provider, not a requirement.

Start with 3 leads. Inspect every source and contact before increasing the count.
The header and every delivery identify `v0.7.0 · build 20260828-02`; if that label
is absent, an older deployment is still being served and its results are invalid.

## Scoring contract

| Category | Maximum |
|---|---:|
| ICP fit | 40 |
| Timing signals | 30 |
| Decision-maker reachability | 15 |
| Evidence quality and freshness | 15 |
| Total | 100 |

The LLM does not set or change this score. It receives only supplied evidence and
is instructed not to invent facts, need, intent, dates or contact information.

## API contract

- `GET /health` — liveness and current mode.
- `GET /v1/status` — provider readiness without exposing secrets.
- `GET /v1/readiness` — live-data and Villow connection blockers.
- `POST /v1/cost-estimate` — conservative free-credit usage before generation.
- `POST /v1/leads/generate` — generate and save a ranked delivery.
- `GET /v1/jobs` — recent job summaries.
- `GET /v1/jobs/{job_id}` — retrieve the complete JSON delivery.
- `GET /v1/jobs/{job_id}/export.csv` — download a flat CSV delivery.
- `POST /v1/outcomes` — record approval or commercial outcomes.
- `GET /v1/jobs/{job_id}/outcomes` — retrieve the learning events.

## Current scope boundary

Included: standalone web interface, API, Villow SDK adapter, evidence provenance,
scoring, persistence, provider import, exports, tests and Docker packaging.

Not included: production Villow credentials, CRM integration, outbound
email/WhatsApp, guaranteed personal mobile numbers, multi-tenant billing or unlimited-scale hosting.
Those require Villow onboarding or a separately approved production scope.

## Villow adapter

`app/villow_agent.py` converts Villow jobs into `LeadRequest`, runs the stable
`LeadPipeline`, saves the delivery and stages a ranked table artifact. The local
adapter passed the official `villow.publisher.v1` contract test using development
credentials. Production credentials remain environment variables and are never
stored in the archive.

See `ZERO_COST_SETUP.md` for beginner deployment instructions, `HANDOFF.md` for
the acceptance checklist and `SEPTEMBER_7_PLAN.md` for the remaining live-data
calibration schedule.
