from __future__ import annotations

import asyncio
import time
import uuid
from dataclasses import dataclass
from datetime import date

from app.adapters.base import (
    CompanySource,
    ContactVerifier,
    NarrativeSource,
    SignalSource,
)
from app.schemas import (
    CompanyCandidate,
    Contact,
    DeliveryMeta,
    Evidence,
    LeadDelivery,
    LeadRecord,
    LeadRequest,
    EmailStatus,
)
from app.scoring import hard_filter_failures, score_candidate
from app.roles import title_matches_requested_roles


@dataclass(frozen=True)
class QualificationRejection:
    reason: str


class LeadPipeline:
    def __init__(
        self,
        company_source: CompanySource,
        signal_source: SignalSource,
        contact_verifier: ContactVerifier,
        narrative_source: NarrativeSource,
        mode: str,
        max_concurrency: int = 4,
    ) -> None:
        self.company_source = company_source
        self.signal_source = signal_source
        self.contact_verifier = contact_verifier
        self.narrative_source = narrative_source
        self.mode = mode
        self.semaphore = asyncio.Semaphore(max_concurrency)

    async def run(self, request: LeadRequest) -> LeadDelivery:
        started = time.perf_counter()
        job_id = f"leadjob_{uuid.uuid4().hex[:16]}"
        warnings: list[str] = []
        candidate_limit = min(100, max(request.desired_count * 4, 20))
        candidates = await self.company_source.discover(request, candidate_limit)
        candidates = self._deduplicate(candidates)
        filtered: list[CompanyCandidate] = []
        hard_rejections = {
            "industry": 0,
            "employee range": 0,
            "geography": 0,
        }
        for candidate in candidates:
            failures = hard_filter_failures(request, candidate)
            if not failures:
                filtered.append(candidate)
                continue
            for failure in failures:
                hard_rejections[failure] += 1
        tasks = [self._qualify(request, company) for company in filtered]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        qualified: list[LeadRecord] = []
        evidence_gate_rejections = 0
        contact_rejections = 0
        score_rejections = 0
        qualification_errors = 0
        for company, result in zip(filtered, results, strict=False):
            if isinstance(result, Exception):
                qualification_errors += 1
                warnings.append(
                    f"{company.domain}: qualification failed ({type(result).__name__})."
                )
                continue
            if isinstance(result, QualificationRejection):
                if result.reason == "missing_required_sales_signal":
                    evidence_gate_rejections += 1
                elif result.reason == "unusable_contact":
                    contact_rejections += 1
            elif result.score.total >= request.minimum_score:
                qualified.append(result)
            else:
                score_rejections += 1

        rejection_parts = [
            f"{count} {label} mismatch{'es' if count != 1 else ''}"
            for label, count in hard_rejections.items()
            if count
        ]
        if rejection_parts:
            warnings.append(
                "ICP filters rejected discovered companies: "
                + ", ".join(rejection_parts)
                + "."
            )
        if evidence_gate_rejections:
            warnings.append(
                f"{evidence_gate_rejections} compan{'ies' if evidence_gate_rejections != 1 else 'y'} "
                "had no verified quotation/RFQ, project/tender, or technical-sales evidence selected in this brief."
            )
        if contact_rejections:
            warnings.append(
                f"{contact_rejections} compan{'ies' if contact_rejections != 1 else 'y'} "
                "had no requested decision-maker role with a valid or accept-all personal work email."
            )
        if score_rejections:
            warnings.append(
                f"{score_rejections} compan{'ies' if score_rejections != 1 else 'y'} "
                f"scored below the minimum score of {request.minimum_score}."
            )
        if qualification_errors:
            warnings.append(
                f"{qualification_errors} compan{'ies' if qualification_errors != 1 else 'y'} "
                "could not be fully researched because a provider request failed."
            )

        rejection_summary = {
            "industry": hard_rejections["industry"],
            "employee_range": hard_rejections["employee range"],
            "geography": hard_rejections["geography"],
            "missing_required_sales_signal": evidence_gate_rejections,
            "unusable_contact": contact_rejections,
            "below_minimum_score": score_rejections,
            "provider_failure": qualification_errors,
        }

        qualified.sort(
            key=lambda lead: (
                lead.score.total,
                lead.score.quotation_rfq,
                lead.score.evidence_quality,
            ),
            reverse=True,
        )
        selected = qualified[: request.desired_count]
        for index, lead in enumerate(selected, start=1):
            lead.rank = index

        if len(selected) < request.desired_count:
            warnings.append(
                f"Returned {len(selected)} of {request.desired_count} requested leads; "
                "the remaining candidates did not pass the evidence and score gates."
            )

        delivery_mode = "import" if request.seed_companies else self.mode
        if delivery_mode == "mock":
            warnings.insert(
                0,
                "Demonstration mode uses fictional companies and contacts; do not send outreach.",
            )
        elif delivery_mode == "import":
            warnings.insert(
                0,
                "Imported fields are scored as supplied; verify provider rights, source URLs, and contact status before outreach.",
            )
        duration_ms = round((time.perf_counter() - started) * 1000)
        meta = DeliveryMeta(
            job_id=job_id,
            mode=delivery_mode,
            requested_count=request.desired_count,
            candidates_considered=len(candidates),
            qualified_count=len(selected),
            duration_ms=duration_ms,
            warnings=warnings,
            rejection_summary=rejection_summary,
        )
        return LeadDelivery(request=request, meta=meta, leads=selected)

    async def _qualify(
        self, request: LeadRequest, company: CompanyCandidate
    ) -> LeadRecord | QualificationRejection:
        async with self.semaphore:
            # A usable buyer is mandatory. Find that person before researching
            # signals so Firecrawl credits are not spent on companies that could
            # never be delivered.
            contact = await self.company_source.find_contact(company, request)
            contact = await self.contact_verifier.verify_or_find(company, contact)
            if (
                self.mode == "live"
                and not request.seed_companies
                and not self._has_usable_buyer_contact(request, contact)
            ):
                return QualificationRejection("unusable_contact")
            evidence = await self.signal_source.research(company, request)
            if request.require_timing_signal and not self._has_current_desired_signal(
                request, evidence
            ):
                return QualificationRejection("missing_required_sales_signal")
            score = score_candidate(request, company, evidence, contact)
            narrative = await self.narrative_source.create(
                request, company, contact, evidence
            )
            return LeadRecord(
                rank=1,
                company=company,
                contact=contact,
                evidence=evidence,
                score=score,
                narrative=narrative,
            )

    @staticmethod
    def _has_usable_buyer_contact(
        request: LeadRequest, contact: Contact
    ) -> bool:
        return bool(
            contact.name
            and contact.email
            and contact.email_status in {EmailStatus.VERIFIED, EmailStatus.ACCEPT_ALL}
            and title_matches_requested_roles(contact.title, request.target_roles)
        )

    @staticmethod
    def _has_current_desired_signal(
        request: LeadRequest, evidence: list[Evidence]
    ) -> bool:
        for item in evidence:
            if item.signal_type not in request.desired_signals:
                continue
            if item.published_at is None:
                return True
            if (date.today() - item.published_at).days <= request.freshness_days:
                return True
        return False

    @staticmethod
    def _deduplicate(companies: list[CompanyCandidate]) -> list[CompanyCandidate]:
        output: list[CompanyCandidate] = []
        seen: set[str] = set()
        for company in companies:
            key = company.domain.lower().removeprefix("www.")
            if key in seen:
                continue
            seen.add(key)
            output.append(company)
        return output
