# Deploy AutoZen Lead Researcher v1.2.4

## Files

- `AutoZen_Prospect_Intelligence_v1.2.4_build_20260901_07.zip`
- `Dockerfile_AutoZen_v1.2.4`

## Render environment

Keep these values in the Render service environment:

```text
APP_ENVIRONMENT=demo
DATA_MODE=live
COMPANY_PROVIDER=hunter
NARRATIVE_MODE=template
DATABASE_PATH=/tmp/autozen-prospect-intelligence.db
HUNTER_CANDIDATE_ATTEMPTS_PER_RUN=3
FIRECRAWL_RESULTS_PER_COMPANY=5
```

Store `HUNTER_API_KEY` and `FIRECRAWL_API_KEY` privately in Render. Never add real keys to GitHub or the ZIP.

## First live test

Request one lead with a minimum score of 60. Confirm that the dashboard reports the V1.2.4 build identity and shows discovery diagnostics. Do not repeat a failed test until the diagnostics have been reviewed.
