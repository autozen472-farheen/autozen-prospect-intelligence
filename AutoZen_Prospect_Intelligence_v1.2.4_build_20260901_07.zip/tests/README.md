# Current release tests

This suite covers the AutoZen industrial-distributor schema, Firecrawl discovery breadth, request pacing and caching, controlled fallback discovery, visible diagnostics, Hunter enrichment limits, release identity, and the safe UAE demo.

The obsolete Villow/HVAC-era suite remains preserved in the V1.2.3 archive and is intentionally not part of this release.
