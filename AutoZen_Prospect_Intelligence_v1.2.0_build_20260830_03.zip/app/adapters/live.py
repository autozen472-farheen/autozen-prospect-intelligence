from __future__ import annotations

import asyncio
import json
import re
from datetime import date, timedelta
from urllib.error import HTTPError
from urllib.parse import urlparse
from urllib.request import Request, urlopen

import httpx

from app.schemas import (
    CompanyCandidate,
    Contact,
    EmailStatus,
    EmailType,
    Evidence,
    LeadRequest,
    PhoneType,
    SignalType,
)
from app.roles import title_matches_requested_roles
from app.scoring import hard_filter_failures


class ProviderError(RuntimeError):
    pass


def _domain_from_url(value: str | None) -> str:
    if not value:
        return ""
    candidate = value if "://" in value else f"https://{value}"
    return urlparse(candidate).netloc.lower().removeprefix("www.")


class ApolloCompanySource:
    base_url = "https://api.apollo.io/api/v1"

    def __init__(self, api_key: str, timeout_seconds: float = 30) -> None:
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds

    @property
    def headers(self) -> dict[str, str]:
        return {"accept": "application/json", "x-api-key": self.api_key}

    async def discover(
        self, request: LeadRequest, candidate_limit: int
    ) -> list[CompanyCandidate]:
        params: list[tuple[str, str | int]] = [
            ("q_organization_keyword_tags[]", request.industry),
            ("organization_num_employees_ranges[]", f"{request.employee_min},{request.employee_max}"),
            ("page", 1),
            ("per_page", min(candidate_limit, 100)),
        ]
        params.extend(("organization_locations[]", geo) for geo in request.geographies)
        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            response = await client.post(
                f"{self.base_url}/mixed_companies/search",
                headers=self.headers,
                params=params,
            )
        if response.status_code >= 400:
            raise ProviderError(
                f"Apollo company search failed ({response.status_code}): {response.text[:300]}"
            )
        payload = response.json()
        rows = payload.get("organizations") or payload.get("accounts") or []
        companies: list[CompanyCandidate] = []
        for row in rows:
            website = row.get("website_url") or row.get("website") or ""
            domain = row.get("primary_domain") or _domain_from_url(website)
            if not domain:
                continue
            companies.append(
                CompanyCandidate(
                    provider_id=str(row.get("id") or row.get("organization_id") or domain),
                    name=row.get("name") or domain,
                    domain=domain,
                    website=website or f"https://{domain}",
                    industry=row.get("industry") or request.industry,
                    city=row.get("city"),
                    state=row.get("state"),
                    country=row.get("country"),
                    employee_count=row.get("estimated_num_employees")
                    or row.get("num_employees"),
                    technologies=row.get("technologies") or [],
                    active_job_count=row.get("num_current_jobs"),
                    source_provider="apollo",
                )
            )
        return companies

    async def find_contact(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> Contact:
        params: list[tuple[str, str | int | bool]] = [
            ("q_organization_domains_list[]", company.domain),
            ("include_similar_titles", True),
            ("page", 1),
            ("per_page", 5),
        ]
        params.extend(("person_titles[]", role) for role in request.target_roles)
        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            response = await client.post(
                f"{self.base_url}/mixed_people/api_search",
                headers=self.headers,
                params=params,
            )
            if response.status_code >= 400:
                raise ProviderError(
                    f"Apollo people search failed ({response.status_code}): {response.text[:300]}"
                )
            people = response.json().get("people") or []
            if not people:
                return Contact(source_provider="apollo")
            person = people[0]
            person_id = person.get("id") or person.get("person_id")
            match_response = await client.post(
                f"{self.base_url}/people/match",
                headers=self.headers,
                params={"id": person_id, "domain": company.domain},
            )
        matched = (
            match_response.json().get("person", {})
            if match_response.status_code < 400
            else person
        )
        email = matched.get("email")
        linkedin_url = matched.get("linkedin_url") or person.get("linkedin_url")
        return Contact(
            name=matched.get("name") or person.get("name"),
            title=matched.get("title") or person.get("title"),
            email=email,
            email_status=(
                EmailStatus.UNKNOWN if email else EmailStatus.UNAVAILABLE
            ),
            email_type=(
                EmailType.PERSON_WORK if email else EmailType.UNAVAILABLE
            ),
            phone=None,
            linkedin_url=linkedin_url,
            source_provider="apollo",
            source_url=linkedin_url,
        )


class HunterCompanySource:
    """Free Discover plus tightly budgeted enrichment and contact lookup."""

    base_url = "https://api.hunter.io/v2"

    def __init__(
        self,
        api_key: str,
        max_company_enrichments: int = 6,
        timeout_seconds: float = 30,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.api_key = api_key.strip()
        self.max_company_enrichments = max_company_enrichments
        self.timeout_seconds = timeout_seconds
        self.transport = transport

    @property
    def headers(self) -> dict[str, str]:
        return {"accept": "application/json", "X-API-KEY": self.api_key}

    async def discover(
        self, request: LeadRequest, candidate_limit: int
    ) -> list[CompanyCandidate]:
        enrichment_limit = min(candidate_limit, self.max_company_enrichments)
        discover_rows: list[dict[str, object]] = []
        seen_domains: set[str] = set()
        async with httpx.AsyncClient(
            timeout=self.timeout_seconds, transport=self.transport
        ) as client:
            # Start narrowly. If Hunter returns too few companies, retry with the
            # same location, size, and HVAC keywords but without its broad
            # industry taxonomy. Discover calls are free; enrichment remains
            # capped, so the fallback improves recall without increasing the
            # configured credit ceiling.
            for body in self._discover_bodies(request):
                response = await client.post(
                    f"{self.base_url}/discover", headers=self.headers, json=body
                )
                if response.status_code >= 400:
                    raise ProviderError(
                        f"Hunter Discover failed ({response.status_code}): {response.text[:300]}"
                    )
                rows = response.json().get("data") or []
                for row in rows:
                    domain = _domain_from_url(row.get("domain"))
                    if not domain or domain in seen_domains:
                        continue
                    seen_domains.add(domain)
                    discover_rows.append(row)
                if len(discover_rows) >= enrichment_limit:
                    break

            companies: list[CompanyCandidate] = []
            for row in discover_rows:
                domain = _domain_from_url(row.get("domain"))
                if not domain:
                    continue
                enriched = await client.get(
                    f"{self.base_url}/companies/find",
                    headers=self.headers,
                    params={"domain": domain},
                )
                if enriched.status_code == 404:
                    continue
                if enriched.status_code >= 400:
                    raise ProviderError(
                        "Hunter company enrichment failed "
                        f"({enriched.status_code}): {enriched.text[:300]}"
                    )
                company = self._company_from_payload(
                    enriched.json().get("data") or {}, row, request
                )
                if company is not None:
                    companies.append(company)
                if len(companies) >= enrichment_limit:
                    break
            return companies

    async def find_contact(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> Contact:
        params = {
            "domain": company.domain,
            "type": "personal",
            "decision_maker": "true",
            "job_titles": ",".join(request.target_roles),
            "verification_status": "valid,accept_all",
            "required_field": "full_name,position",
            # Free accounts allow up to ten rows per Domain Search. Returning
            # several already-filtered buyers lets us rank the best requested
            # role without revealing unrelated HR/technical contacts.
            "limit": "10",
        }
        async with httpx.AsyncClient(
            timeout=self.timeout_seconds, transport=self.transport
        ) as client:
            response = await client.get(
                f"{self.base_url}/domain-search",
                headers=self.headers,
                params=params,
            )
        if response.status_code >= 400:
            raise ProviderError(
                f"Hunter decision-maker search failed ({response.status_code}): "
                f"{response.text[:300]}"
            )
        emails = [
            row
            for row in (response.json().get("data") or {}).get("emails") or []
            if self._is_usable_buyer_row(row, request)
        ]
        if not emails:
            return Contact(
                phone=company.public_phone,
                phone_type=(
                    PhoneType.GENERIC_COMPANY
                    if company.public_phone
                    else PhoneType.UNAVAILABLE
                ),
                source_provider="hunter",
                source_url=company.source_url,
            )
        best = max(emails, key=lambda row: self._contact_rank(row, request))
        linkedin_url = self._linkedin_url(best.get("linkedin"))
        source_url = linkedin_url or self._best_email_source(best)
        direct_phone = best.get("phone_number")
        return Contact(
            name=" ".join(
                part
                for part in (best.get("first_name"), best.get("last_name"))
                if part
            )
            or None,
            title=best.get("position") or best.get("position_raw"),
            email=best.get("value"),
            email_status=HunterContactVerifier._status(
                (best.get("verification") or {}).get("status")
            ),
            email_type=(
                EmailType.PERSON_WORK
                if best.get("type") == "personal"
                else EmailType.GENERIC_COMPANY
                if best.get("type") == "generic"
                else EmailType.UNKNOWN
            ),
            phone=direct_phone or company.public_phone,
            phone_type=(
                PhoneType.PERSON
                if direct_phone
                else PhoneType.GENERIC_COMPANY
                if company.public_phone
                else PhoneType.UNAVAILABLE
            ),
            linkedin_url=linkedin_url,
            source_provider="hunter",
            source_url=source_url,
        )

    @staticmethod
    def _is_usable_buyer_row(
        row: dict[str, object], request: LeadRequest
    ) -> bool:
        requested_role = title_matches_requested_roles(
            str(row.get("position") or row.get("position_raw") or ""),
            request.target_roles,
        )
        verification = row.get("verification")
        status = (
            str(verification.get("status") or "")
            if isinstance(verification, dict)
            else ""
        )
        return bool(
            requested_role
            and row.get("decision_maker") is True
            and row.get("type") == "personal"
            and row.get("value")
            and status in {"valid", "accept_all"}
        )

    @staticmethod
    def _discover_body(request: LeadRequest) -> dict[str, object]:
        return HunterCompanySource._discover_bodies(request)[0]

    @staticmethod
    def _discover_bodies(request: LeadRequest) -> list[dict[str, object]]:
        country_codes = {
            "united states": "US",
            "usa": "US",
            "us": "US",
            "united arab emirates": "AE",
            "uae": "AE",
            "united kingdom": "GB",
            "uk": "GB",
            "canada": "CA",
            "australia": "AU",
            "new zealand": "NZ",
        }
        locations = []
        for geography in request.geographies:
            code = country_codes.get(geography.strip().lower())
            if code:
                locations.append({"country": code})
        headcount = HunterCompanySource._headcount_bands(
            request.employee_min, request.employee_max
        )
        if len(locations) == len(request.geographies) and headcount:
            base: dict[str, object] = {
                "headquarters_location": {"include": locations},
                "headcount": headcount,
            }
            body: dict[str, object] = {
                **base,
                "keywords": {
                    "include": HunterCompanySource._industry_keywords(
                        request.industry
                    ),
                    "match": "any",
                },
            }
            relevant_industries = HunterCompanySource._industry_filters(
                request.industry
            )
            if relevant_industries:
                body["industry"] = {"include": relevant_industries}
                # Hunter applies filter families together. A second keyword-only
                # pass prevents a sparse taxonomy match from limiting discovery
                # to just a few companies.
                return [
                    body,
                    {
                        **base,
                        "keywords": body["keywords"],
                    },
                ]
            return [body]
        return [{
            "query": (
                f"{request.industry} companies headquartered in "
                f"{', '.join(request.geographies)} with approximately "
                f"{request.employee_min}-{request.employee_max} employees"
            )
        }]

    @staticmethod
    def _industry_keywords(industry: str) -> list[str]:
        """Expand narrow ICP labels for discovery, never for qualification."""
        normalised = " ".join(industry.lower().replace("&", "and").split())
        if normalised in {
            "hvac",
            "heating",
            "air conditioning",
            "heating and air conditioning",
            "mechanical services",
        }:
            return [
                "HVAC",
                "heating",
                "air conditioning",
                "mechanical services",
            ]
        return [industry]

    @staticmethod
    def _industry_filters(industry: str) -> list[str]:
        """Use Hunter's service categories to avoid HVAC recruiters/vendors."""
        normalised = " ".join(industry.lower().replace("&", "and").split())
        if normalised in {
            "hvac",
            "heating",
            "air conditioning",
            "heating and air conditioning",
            "mechanical services",
        }:
            return [
                "Specialty Trade Contractors",
                "Building Equipment Contractors",
                "Repair and Maintenance",
                "Facilities Services",
            ]
        return []

    @staticmethod
    def _headcount_bands(minimum: int, maximum: int) -> list[str]:
        bands = [
            (1, 10, "1-10"),
            (11, 50, "11-50"),
            (51, 200, "51-200"),
            (201, 500, "201-500"),
            (501, 1_000, "501-1000"),
            (1_001, 5_000, "1001-5000"),
            (5_001, 10_000, "5001-10000"),
        ]
        return [label for low, high, label in bands if minimum <= low and high <= maximum]

    @staticmethod
    def _company_from_payload(
        data: dict[str, object], discover_row: dict[str, object], request: LeadRequest
    ) -> CompanyCandidate | None:
        domain = _domain_from_url(str(data.get("domain") or discover_row.get("domain") or ""))
        if not domain:
            return None
        metrics = data.get("metrics") if isinstance(data.get("metrics"), dict) else {}
        employee_min, employee_max = HunterCompanySource._parse_headcount(
            str(metrics.get("employees") or "")
        )
        geo = data.get("geo") if isinstance(data.get("geo"), dict) else {}
        category = data.get("category") if isinstance(data.get("category"), dict) else {}
        # Treat Hunter's category fields as the company's own industry.  Do not
        # promote the requested industry merely because it appears in a broad
        # description or tag: a recruiter that *serves HVAC clients*, for
        # example, is not itself an HVAC contractor.
        category_industry = str(category.get("industry") or "").strip()
        category_subindustry = str(category.get("subIndustry") or "").strip()
        category_text = " ".join(
            part for part in (category_industry, category_subindustry) if part
        )
        industry = category_text or "Unknown"
        linkedin = data.get("linkedin") if isinstance(data.get("linkedin"), dict) else {}
        linkedin_url = HunterCompanySource._linkedin_url(linkedin.get("handle"))
        site = data.get("site") if isinstance(data.get("site"), dict) else {}
        phones = site.get("phoneNumbers") if isinstance(site.get("phoneNumbers"), list) else []
        return CompanyCandidate(
            provider_id=str(data.get("id") or domain),
            name=str(data.get("name") or discover_row.get("organization") or domain),
            domain=domain,
            website=f"https://{domain}",
            industry=industry,
            city=str(geo.get("city") or "") or None,
            state=str(geo.get("state") or "") or None,
            country=str(geo.get("country") or "") or None,
            employee_count_min=employee_min,
            employee_count_max=employee_max,
            technologies=[str(item) for item in (data.get("tech") or [])][:30],
            public_phone=(str(phones[0]) if phones else str(data.get("phone") or "") or None),
            source_provider="hunter",
            source_url=linkedin_url or f"https://{domain}",
        )

    @staticmethod
    def _parse_headcount(value: str) -> tuple[int | None, int | None]:
        match = re.match(r"^(\d+)-(\d+)$", value.replace(",", ""))
        if match:
            return int(match.group(1)), int(match.group(2))
        plus = re.match(r"^(\d+)\+$", value.replace(",", ""))
        if plus:
            return int(plus.group(1)), 1_000_000
        return None, None

    @staticmethod
    def _linkedin_url(value: object) -> str | None:
        candidate = str(value or "").strip()
        if not candidate:
            return None
        if candidate.startswith("http://") or candidate.startswith("https://"):
            return candidate
        return f"https://www.linkedin.com/{candidate.lstrip('/')}"

    @staticmethod
    def _best_email_source(row: dict[str, object]) -> str | None:
        sources = row.get("sources") if isinstance(row.get("sources"), list) else []
        for source in sources:
            if isinstance(source, dict) and source.get("still_on_page") and source.get("uri"):
                return str(source["uri"])
        for source in sources:
            if isinstance(source, dict) and source.get("uri"):
                return str(source["uri"])
        return None

    @staticmethod
    def _contact_rank(row: dict[str, object], request: LeadRequest) -> tuple[int, int, int, int]:
        title = str(row.get("position") or row.get("position_raw") or "").lower()
        target_match = any(role.lower() in title for role in request.target_roles)
        status = (row.get("verification") or {}).get("status") if isinstance(row.get("verification"), dict) else None
        status_rank = {"valid": 3, "accept_all": 2, "unknown": 1}.get(str(status), 0)
        return (
            1 if target_match else 0,
            1 if row.get("decision_maker") is True else 0,
            status_rank,
            int(row.get("confidence") or 0),
        )


class FirecrawlSignalSource:
    base_url = "https://api.firecrawl.dev/v2"

    def __init__(
        self,
        api_key: str,
        results_per_company: int = 5,
        timeout_seconds: float = 45,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.api_key = api_key.strip()
        self.results_per_company = results_per_company
        self.timeout_seconds = timeout_seconds
        self.transport = transport

    async def research(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> list[Evidence]:
        signal_terms = {
            SignalType.QUOTATION_RFQ: '"request a quote" quotation RFQ enquiry pricing',
            SignalType.PROJECT_TENDER: 'projects tenders bids procurement EPC contract',
            SignalType.TECHNICAL_SALES: 'technical sales distributor solutions products catalogue',
            SignalType.EXPANSION: 'expansion "new branch" "new office" launch acquisition',
            SignalType.RECENT_NEWS: 'news announcement',
        }
        desired_terms = " ".join(signal_terms[item] for item in request.desired_signals)
        query = f'"{company.name}" {desired_terms}'
        body = {
            "query": query,
            "limit": self.results_per_company,
            "sources": ["web", "news"],
            "tbs": self._time_filter(request.freshness_days),
        }
        payload = await self.search(body)
        data = payload.get("data") or {}
        rows = list(data.get("web") or []) + list(data.get("news") or [])
        output: list[Evidence] = []
        for row in rows:
            url = row.get("url") or ""
            title = row.get("title") or "Untitled result"
            snippet = row.get("snippet") or row.get("description") or ""
            combined = f"{title} {snippet}".lower()
            signal_type = self._classify(combined)
            exact_domain = _domain_from_url(url) == company.domain
            name_match = company.name.lower() in combined
            confidence = 0.9 if exact_domain else 0.78 if name_match else 0.55
            if not url or confidence < 0.6:
                continue
            output.append(
                Evidence(
                    signal_type=signal_type,
                    title=title,
                    url=url,
                    snippet=snippet[:800],
                    source_provider="firecrawl",
                    published_at=self._parse_relative_date(row.get("date")),
                    confidence=confidence,
                )
            )
        return output

    async def search(self, body: dict[str, object]) -> dict[str, object]:
        """Run one Firecrawl search with the Render-compatible fallback."""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        status_code: int
        response_text: str
        payload: dict[str, object]
        try:
            async with httpx.AsyncClient(
                timeout=self.timeout_seconds, transport=self.transport
            ) as client:
                response = await client.post(
                    f"{self.base_url}/search", headers=headers, json=body
                )
            status_code = response.status_code
            response_text = response.text
            payload = response.json() if response.content else {}
        except httpx.LocalProtocolError:
            # Some hosting/CDN combinations occasionally reject the h11 request
            # produced by httpx. Retry once with Python's standard HTTP client.
            # Mock transports stay on the httpx path, so provider contract tests
            # remain deterministic.
            if self.transport is not None:
                raise
            status_code, response_text, payload = await asyncio.to_thread(
                self._search_with_urllib, body, headers
            )
        if status_code >= 400:
            raise ProviderError(
                f"Firecrawl search failed ({status_code}): {response_text[:300]}"
            )
        return payload

    def _search_with_urllib(
        self, body: dict[str, object], headers: dict[str, str]
    ) -> tuple[int, str, dict[str, object]]:
        request = Request(
            f"{self.base_url}/search",
            data=json.dumps(body).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        try:
            with urlopen(request, timeout=self.timeout_seconds) as response:
                response_text = response.read().decode("utf-8", errors="replace")
                payload = json.loads(response_text) if response_text else {}
                return response.status, response_text, payload
        except HTTPError as error:
            response_text = error.read().decode("utf-8", errors="replace")
            try:
                payload = json.loads(response_text) if response_text else {}
            except json.JSONDecodeError:
                payload = {}
            return error.code, response_text, payload

    @staticmethod
    def _time_filter(freshness_days: int) -> str:
        if freshness_days <= 1:
            return "qdr:d"
        if freshness_days <= 7:
            return "qdr:w"
        if freshness_days <= 31:
            return "qdr:m"
        return "qdr:y"

    @staticmethod
    def _classify(text: str) -> SignalType:
        if re.search(r"\b(rfq|request for quotation|request a quote|quotation|quote request|send enquiry|price enquiry)\b", text):
            return SignalType.QUOTATION_RFQ
        if re.search(r"\b(tender|bid|project|epc|procurement|contract award|vendor registration)\b", text):
            return SignalType.PROJECT_TENDER
        if re.search(r"\b(technical sales|distributor|distribution|product catalogue|product catalog|solutions provider|authorized dealer|authorised dealer)\b", text):
            return SignalType.TECHNICAL_SALES
        if re.search(r"\b(expand\w*|new location|new office|new branch|acquir\w*|launch\w*)\b", text):
            return SignalType.EXPANSION
        return SignalType.RECENT_NEWS

    @staticmethod
    def _parse_relative_date(value: str | None) -> date | None:
        if not value:
            return None
        iso_match = re.match(r"^(\d{4})-(\d{2})-(\d{2})", value)
        if iso_match:
            try:
                return date.fromisoformat(iso_match.group(0))
            except ValueError:
                return None
        relative = re.match(r"^(\d+)\s+(day|week|month|year)s?\s+ago$", value.lower())
        if not relative:
            return None
        amount = int(relative.group(1))
        unit = relative.group(2)
        days = amount * {"day": 1, "week": 7, "month": 30, "year": 365}[unit]
        return date.today() - timedelta(days=days)


class FirecrawlHunterCompanySource(HunterCompanySource):
    """Wide web discovery first; Hunter enrichment only for the best web candidates."""

    excluded_domains = {
        "linkedin.com", "facebook.com", "instagram.com", "x.com", "twitter.com",
        "youtube.com", "yelp.com", "yellowpages.com", "indeed.com", "glassdoor.com",
        "ziprecruiter.com", "reddit.com", "wikipedia.org", "crunchbase.com",
        "zoominfo.com", "signalhire.com", "rocketreach.co", "apollo.io",
    }

    def __init__(self, hunter_api_key: str, firecrawl_api_key: str,
                 max_company_enrichments: int = 6, timeout_seconds: float = 45,
                 transport: httpx.AsyncBaseTransport | None = None) -> None:
        super().__init__(hunter_api_key, max_company_enrichments=max_company_enrichments,
                         timeout_seconds=timeout_seconds, transport=transport)
        self.web_discovery = FirecrawlSignalSource(
            firecrawl_api_key, results_per_company=10,
            timeout_seconds=timeout_seconds, transport=transport,
        )

    async def discover(self, request: LeadRequest, candidate_limit: int) -> list[CompanyCandidate]:
        enrichment_limit = min(candidate_limit, self.max_company_enrichments)
        delivery_pool_target = min(candidate_limit, max(request.desired_count * 4, 6))

        # V1.2 deliberately gathers a much wider FREE/cheap web pool before any
        # Hunter company enrichment. We merge and rank results from several query
        # angles instead of enriching whichever domains happen to appear first.
        by_domain: dict[str, dict[str, object]] = {}
        for body in self._web_discovery_bodies(request, enrichment_limit):
            payload = await self.web_discovery.search(body)
            data = payload.get("data") or {}
            for row in list(data.get("web") or []) + list(data.get("news") or []):
                domain = _domain_from_url(str(row.get("url") or ""))
                if not domain or self._is_excluded_domain(domain):
                    continue
                score = self._web_candidate_score(row, request)
                if score <= 0:
                    continue
                previous = by_domain.get(domain)
                if previous is None or int(previous["_az_score"]) < score:
                    enriched_row = dict(row)
                    enriched_row["_az_score"] = score
                    by_domain[domain] = enriched_row

        ranked_rows = sorted(
            by_domain.values(), key=lambda row: int(row.get("_az_score") or 0), reverse=True
        )

        companies: list[CompanyCandidate] = []
        enrichment_attempts = 0
        async with httpx.AsyncClient(timeout=self.timeout_seconds, transport=self.transport) as client:
            for row in ranked_rows:
                if enrichment_attempts >= enrichment_limit or len(companies) >= delivery_pool_target:
                    break
                domain = _domain_from_url(str(row.get("url") or ""))
                enrichment_attempts += 1
                response = await client.get(
                    f"{self.base_url}/companies/find", headers=self.headers,
                    params={"domain": domain},
                )
                if response.status_code == 404:
                    continue
                if response.status_code >= 400:
                    raise ProviderError(
                        f"Hunter company enrichment failed ({response.status_code}): {response.text[:300]}"
                    )
                data = response.json().get("data") or {}
                if self._negative_company_category(data):
                    continue
                company = self._company_from_payload(
                    data, {"domain": domain, "organization": row.get("title") or domain}, request
                )
                if company is None:
                    continue
                company.industry = request.industry
                company.source_provider = "firecrawl+hunter"
                company.source_url = str(row.get("url") or company.website)
                if hard_filter_failures(request, company):
                    continue
                companies.append(company)

        if companies:
            return companies
        return await super().discover(request, candidate_limit)

    @staticmethod
    def _web_discovery_bodies(request: LeadRequest, enrichment_limit: int) -> list[dict[str, object]]:
        country_codes = {
            "united states": "US", "usa": "US", "us": "US",
            "united arab emirates": "AE", "uae": "AE",
            "united kingdom": "GB", "uk": "GB", "canada": "CA",
            "australia": "AU", "new zealand": "NZ",
        }
        geography = ", ".join(request.geographies)
        country = country_codes.get(request.geographies[0].strip().lower(), "US")
        products = [x.strip() for x in request.products_or_services.split(",") if x.strip()]
        product_terms = " ".join(products[:6]) or request.industry
        common: dict[str, object] = {
            # Wide discovery pool; this does NOT raise the Hunter enrichment cap.
            "limit": min(100, max(40, enrichment_limit * 5)),
            "sources": ["web"], "country": country, "location": geography,
            "safe": True, "ignoreInvalidURLs": True, "highlights": False,
        }
        queries = [
            f'{request.industry} {product_terms} {geography} supplier distributor company -jobs -directory',
            f'{product_terms} {geography} distributor supplier "request a quote"',
            f'{product_terms} {geography} RFQ quotation enquiry supplier',
            f'{product_terms} {geography} projects tenders EPC procurement distributor',
            f'{product_terms} {geography} "technical sales" distributor dealer',
        ]
        # Product-specific searches add diversity when the brief contains several
        # categories (e.g. pumps, valves, compressors, instrumentation).
        queries.extend(
            f'{product} {geography} distributor supplier industrial "request a quote"'
            for product in products[:4]
        )
        return [{**common, "query": query} for query in queries]

    @classmethod
    def _is_excluded_domain(cls, domain: str) -> bool:
        return any(domain == excluded or domain.endswith(f".{excluded}") for excluded in cls.excluded_domains)

    @staticmethod
    def _web_candidate_score(row: dict[str, object], request: LeadRequest) -> int:
        text = " ".join(str(row.get(field) or "") for field in ("title", "description", "snippet")).lower()
        if any(term in text for term in (
            "recruiting", "recruitment", "staffing", "job board", "marketing agency",
            "business directory", "yellow pages", "software platform",
        )):
            return 0
        score = 0
        # Product/industry relevance is the strongest cheap pre-enrichment signal.
        product_tokens = [
            token.lower() for item in request.products_or_services.split(",")
            for token in re.findall(r"[a-z0-9]+", item) if len(token) > 3
        ]
        industry_tokens = [
            t for t in re.findall(r"[a-z0-9]+", request.industry.lower())
            if len(t) > 3 and t not in {"industrial", "equipment", "distributor", "distributors", "supplier", "suppliers"}
        ]
        score += min(8, sum(2 for token in set(product_tokens) if token in text))
        score += min(4, sum(2 for token in set(industry_tokens) if token in text))
        if re.search(r"\b(distributor|supplier|dealer|stockist|trading|solutions)\b", text): score += 4
        if re.search(r"\b(rfq|quotation|request a quote|request for quote|enquiry|inquiry)\b", text): score += 6
        if re.search(r"\b(project|tender|epc|procurement|technical sales)\b", text): score += 4
        # Require at least commercial/industry relevance; don't enrich generic pages.
        return score if score >= 4 else 0

    @staticmethod
    def _verified_industry_result(row: dict[str, object], industry: str) -> bool:
        # Compatibility helper retained for provider tests and older callers.
        text = " ".join(str(row.get(field) or "") for field in ("title", "description", "snippet")).lower()
        if any(term in text for term in ("recruiting", "recruitment", "staffing", "job board", "directory", "wikipedia")):
            return False
        tokens = [t for t in re.findall(r"[a-z0-9]+", industry.lower()) if len(t) > 3 and t not in {"company", "companies", "industrial", "equipment", "distributor", "distributors", "supplier", "suppliers"}]
        return not tokens or any(token in text for token in tokens) or any(x in text for x in ("distributor", "supplier", "trading"))

    @staticmethod
    def _negative_company_category(data: dict[str, object]) -> bool:
        category = data.get("category") if isinstance(data.get("category"), dict) else {}
        text = " ".join(str(category.get(field) or "") for field in ("industry", "subIndustry")).lower()
        return any(term in text for term in (
            "human resources", "staffing", "recruiting", "software development",
            "advertising services", "marketing services",
        ))


class HunterContactVerifier:
    base_url = "https://api.hunter.io/v2"

    def __init__(self, api_key: str, timeout_seconds: float = 30) -> None:
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds

    async def verify_or_find(
        self, company: CompanyCandidate, contact: Contact
    ) -> Contact:
        if (
            contact.email
            and contact.source_provider == "hunter"
            and contact.email_status
            in {
                EmailStatus.VERIFIED,
                EmailStatus.ACCEPT_ALL,
                EmailStatus.INVALID,
                EmailStatus.RISKY,
            }
        ):
            return contact
        async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
            if not contact.email and contact.name:
                response = await client.get(
                    f"{self.base_url}/email-finder",
                    params={
                        "domain": company.domain,
                        "full_name": contact.name,
                        "api_key": self.api_key,
                    },
                )
                if response.status_code == 200:
                    data = response.json().get("data") or {}
                    contact.email = data.get("email")
                    if contact.email:
                        contact.email_type = EmailType.PERSON_WORK
                    verification = data.get("verification") or {}
                    contact.email_status = self._status(verification.get("status"))
                    contact.source_provider = "apollo+hunter"
                    return contact
            if contact.email:
                response = await client.get(
                    f"{self.base_url}/email-verifier",
                    params={"email": contact.email, "api_key": self.api_key},
                )
                if response.status_code == 200:
                    data = response.json().get("data") or {}
                    contact.email_status = self._status(data.get("status"))
                    contact.source_provider = "apollo+hunter"
        return contact

    @staticmethod
    def _status(value: str | None) -> EmailStatus:
        mapping = {
            "valid": EmailStatus.VERIFIED,
            "accept_all": EmailStatus.ACCEPT_ALL,
            "invalid": EmailStatus.INVALID,
            "disposable": EmailStatus.INVALID,
            "webmail": EmailStatus.RISKY,
            "unknown": EmailStatus.UNKNOWN,
        }
        return mapping.get(value or "", EmailStatus.UNKNOWN)
