# AutoZen 1.3.2 — source-screening update

AutoZen only. Leave villow-lead-engine unchanged. This update separates business candidates, source references and excluded results; it does not turn them into qualified leads.

## Step 1 — save results and upload the two files

Download any AutoZen job JSON/CSV you want to keep before an upload or deployment. Keep the successful `global_322e892a5eb34446.json` for the offline check below. The current /tmp database is ephemeral, so redeployment can clear results and usage counters.

Upload these to the existing AutoZen GitHub repository, not Villow:

- AutoZen_Prospect_Intelligence_v1.3.2_build_20260903_01.zip
- Dockerfile_AutoZen_v1.3.2

Keep the ZIP compressed and its name unchanged. Keep the previous version's files. Do not overwrite the active Dockerfile. Uploading alone does not select the new Dockerfile; if GitHub uploads trigger auto-deploy, the old Dockerfile may redeploy.

## Step 2 — activate safely, without a live run

After the upload is confirmed, in Render → autozen-prospect-intelligence:

1. Environment → Edit: set ENABLE_LIVE_RUNS=false. Keep DAILY_LIVE_RUN_LIMIT=1. Save and deploy so the setting takes effect. Do not change provider keys, passwords, DATA_MODE or other limits.
2. Settings → Dockerfile Path: set `./Dockerfile_AutoZen_v1.3.2` and save. If needed, use Manual Deploy → Deploy latest commit once. Do not cancel and repeatedly restart a deployment.
3. Once Render says Live, open AutoZen, sign in and confirm v1.3.2, build 20260903-01. Global discovery should show Live off.

No new service, new provider key or paid hosting upgrade is required for this filtering update. Docker defaults also keep live off, but an existing Render environment value overrides those defaults—verify it rather than assuming it.

## Step 3 — check the deployment without spending

No additional demo or live search is necessary for this acceptance check. On Global discovery:

1. Set niche to **Industrial distributor**, location to **Australia only**, country code **AU**.
2. Set **Websites to read in total** to **0**. Keep search results at 5 (import mode will not search).
3. Choose **Reuse saved JSON — no search credits** and upload `global_322e892a5eb34446.json`.
4. Press **Review saved research** once.
5. Expect **3 research candidates**, a separate **1 reference page** section for NCPS on Atlas Copco's site, and **1 excluded result** for aer.gov.au. All candidates must still say needs verification. Search/public-page/Hunter/OpenAI requests must all be 0.
6. Save the resulting JSON and Research CSV. CSV should have three data rows and no Atlas Copco or regulator row. References and reasons remain in JSON.

If the count or mode differs, stop and share the saved JSON/error. Do not enable live mode, import a demo as real data, or start Supplier qualification to troubleshoot this check.

## Any later live test needs a separate decision

Two approved Australia attempts were made on September 3: the first failed, the second returned five search results. This update does not authorize another paid run. Restore DAILY_LIVE_RUN_LIMIT=1 and keep ENABLE_LIVE_RUNS=false. Do not reset the database, change the date, increase the cap or redeploy to bypass the already-used allowance. If a redeployment clears its record, that is not a fresh budget approval. A zero-page offline import does not use the live allowance.

For a separately approved test, use one market and at most five search results, and agree the number of website reads. Do not repeatedly search or change API keys on a guess. Export the result JSON, inspect the automatically expanded Search diagnostics, then disable live access again. A failed search may still have been processed or billed; estimate fields cannot settle that.

## Risk, rollback and remaining limits

- Preserve exports before deployments; the current database is not durable. Storage and production uptime remain separate decisions.
- This update screens source types, not niche fit or company facts. Rules may conservatively hold legitimate company pages or miss unfamiliar references. Keep the audit and review uncertain sources.
- Website/contact verification, persistence, operating costs and production uptime remain unproven. No revenue or client-ready status is implied. This is not a mailbox-verification or outreach system.
- If this release fails to deploy, keep live off and provide redacted error text. If rollback is necessary, select the preserved `./Dockerfile_AutoZen_v1.3.1`, not the older unprotected v1.2.6.
- No passwords, API keys or revealed-secret screenshots should be uploaded to GitHub or chat.
- Villow's separate five-step delivery checkpoint remains paused.

References: [Render Docker settings](https://render.com/docs/docker), [environment updates](https://render.com/docs/configure-environment-variables), [free-hosting limitations](https://render.com/docs/free).
