"""Cheap, conservative search-result screening; no network or inferred firmographics."""
from __future__ import annotations

import re
from dataclasses import dataclass
from urllib.parse import urlparse

from app.schemas import LeadRequest
from app.result_screening import screen_source

HUNTER_COMPANY_CAP = 3
DISCOVERY_RESULT_LIMIT = 40
DISCOVERY_QUERY_COUNT = 4
FIRECRAWL_MAX_ATTEMPTS = 2
WEBSITE_COMPANY_CAP = 6
WEBSITE_HTTP_CAP = 24

EXCLUDED_DOMAINS = {
    "linkedin.com", "facebook.com", "instagram.com", "x.com", "twitter.com",
    "youtube.com", "reddit.com", "wikipedia.org", "crunchbase.com", "zoominfo.com",
    "signalhire.com", "rocketreach.co", "apollo.io", "yelp.com", "yellowpages.com",
    "atninfo.com", "reachuae.com", "dcciinfo.com", "yellowpages-uae.com",
    "dubaiyellowpagesonline.com", "omanyellowpagesonline.com", "southafricayellowpages.com",
    "fyind.com", "rfqmatch.com", "airport-suppliers.com", "indexbox.io",
    "indeed.com", "glassdoor.com", "glassdoor.co.uk", "ziprecruiter.com",
    "jooble.org", "naukri.com", "naukrigulf.com", "talentpool.ae", "jobsora.com",
    "bayt.com", "careersingulf.com", "kitjob.in", "trabajo.org", "tanqeeb.com",
    "whatjobs.com", "founditgulf.com", "placementindia.com", "rigzone.com",
    "scribd.com", "yumpu.com",
    "exportersindia.com", "indiamart.com", "tradeindia.com", "alibaba.com",
}


def domain_from_url(value: str) -> str:
    try:
        parsed = urlparse(value)
        if parsed.scheme not in {"http", "https"} or parsed.username or parsed.password:
            return ""
        return (parsed.hostname or "").lower().removeprefix("www.")
    except ValueError:
        return ""


def search_rows(payload: object) -> list[dict]:
    """HTTP envelope, SDK/export buckets, and older list response variants."""
    data = payload.get("data", payload) if isinstance(payload, dict) else payload
    if isinstance(data, list):
        return [row for row in data if isinstance(row, dict)]
    if isinstance(data, dict):
        rows = []
        for key in ("web", "news"):
            bucket = data.get(key)
            if isinstance(bucket, list):
                rows.extend(row for row in bucket if isinstance(row, dict))
        return rows
    return []


def excluded_domain(domain: str) -> bool:
    return any(domain == item or domain.endswith("." + item) for item in EXCLUDED_DOMAINS)


def _tokens(text: str) -> set[str]:
    return {token.removesuffix("s") for token in re.findall(r"[a-z0-9]+", text.lower()) if len(token) > 2}


def _contains(text: str, phrase: str) -> bool:
    return bool(re.search(r"(?<!\w)" + re.escape(phrase) + r"(?!\w)", text, re.I))


@dataclass(frozen=True)
class Assessment:
    score: int
    eligible: bool
    reason: str | None = None
    company_like: bool = True


def assess_result(row: dict, request: LeadRequest) -> Assessment:
    domain = domain_from_url(str(row.get("url") or ""))
    title = str(row.get("title") or "").lower()
    text = " ".join(str(row.get(k) or "") for k in ("title", "description", "snippet")).lower()
    if not domain or excluded_domain(domain):
        return Assessment(0, False, "excluded_source", False)
    # Re-screen even old saved JSON: a manufacturer reference or government
    # page must not become a supplier seed merely through a workflow handoff.
    screening = screen_source(domain, str(row.get('url') or ''),
                              str(row.get('title') or ''), text)
    if screening.disposition != 'candidate':
        return Assessment(0, False, screening.reason, False)
    path = urlparse(str(row.get("url") or "")).path.lower()
    if re.search(r"\b(jobs?|careers?|hiring|recruitment|recruiting|staffing|salary|cv|resume)\b", title) or re.search(r"/(jobs?|careers?|job-listings)(/|[-_])", path):
        return Assessment(0, False, "job_listing", False)
    if re.search(r"\b(directory|marketplace|market report|market analysis|seo|confirmed attendees)\b", text) or re.search(r"\btop\s+\d+\b", title):
        return Assessment(0, False, "non_company_page", False)
    if re.search(r"\b(best .{0,40}suppliers|top brands|brands (?:and|&) profiles|buying guide|suppliers comparison)\b", title):
        return Assessment(0, False, "supplier_comparison_page", False)
    if re.search(r"/brands?/", path) and "manufacturer" in text and "manufacturer" not in request.industry.lower():
        return Assessment(0, False, "brand_page_not_local_company", False)
    if re.search(r"\b(laboratory|test rig|apparatus|educational|institution)\b", text) and not re.search(r"laboratory|education|test rig|apparatus", request.industry, re.I):
        return Assessment(0, False, "niche_mismatch", False)
    stop = {"industrial", "equipment", "distributor", "supplier", "company", "service"}
    targets = _tokens(request.products_or_services) or (_tokens(request.industry) - stop)
    hits = len(targets & _tokens(text))
    if targets and not hits:
        return Assessment(0, False, "product_mismatch", False)
    commercial = bool(re.search(r"\b(suppliers?|distributors?|dealers?|stockists?|trading|manufacturers?|supply|supplies|supplying)\b", text))
    if not commercial:
        return Assessment(0, False, "supplier_unconfirmed", False)

    aliases = {
        "united arab emirates": ["united arab emirates", "uae", "u.a.e", "dubai", "abu dhabi", "sharjah", "ajman", "ras al khaimah", "fujairah", "umm al quwain"],
        "united states": ["united states", "usa", "u.s.a"],
        "united kingdom": ["united kingdom", "uk", "britain"],
        "australia": ["australia"], "canada": ["canada"], "new zealand": ["new zealand"],
    }
    canonical = {"uae": "united arab emirates", "us": "united states", "usa": "united states", "uk": "united kingdom"}
    requested = [canonical.get(x.strip().lower(), x.strip().lower()) for x in request.geographies]
    local = any(_contains(text, term) for geo in requested for term in aliases.get(geo, [geo]))
    local_title = any(_contains(title, term) for geo in requested for term in aliases.get(geo, [geo]))
    # A country code domain alone is not evidence of a local operating presence.
    foreign_markets = ["saudi arabia", "qatar", "oman", "egypt", "india", "pakistan", "china", "philippines", "south africa"]
    conflict = any(_contains(title, market) for market in foreign_markets if market not in requested) and not local_title
    score = min(hits, 3) * 3 + 4 + (8 if local else 0) + (4 if local_title else 0)
    score += 2 if re.search(r"\b(rfq|quotation|request a quote)\b", text) else 0
    score += 3 if re.search(r"\b(distributor|supplier|trading)\b", title) else 0
    score += 2 if path in {"", "/"} else 0
    if conflict:
        return Assessment(score, False, "other_market_in_title")
    if not local:
        return Assessment(score, False, "target_location_unverified")
    return Assessment(score, True)


def selection_key(item):
    """Deterministic ties: actual score, then stable domain; never arrival order."""
    return (-item.shortlist_score, item.domain)


def discovery_bodies(request: LeadRequest) -> list[dict]:
    geography = ", ".join(request.geographies)
    country_codes = {"united arab emirates": "AE", "uae": "AE", "united states": "US", "usa": "US", "us": "US", "united kingdom": "GB", "uk": "GB", "australia": "AU", "canada": "CA", "new zealand": "NZ"}
    products = " ".join(x.strip() for x in request.products_or_services.split(",")[:6]) or request.industry
    queries = [
        f"{request.industry} {products} {geography} supplier distributor company -jobs -directory",
        f'{products} {geography} supplier distributor RFQ "request a quote" -jobs -careers -directory',
        f'{products} {geography} industrial supplier products contact -jobs -careers -directory',
        f"{products} {geography} authorized dealer distributor industrial supplier -jobs -directory",
    ]
    common = {"limit": DISCOVERY_RESULT_LIMIT, "sources": ["web"], "location": geography, "safe": True, "ignoreInvalidURLs": True, "highlights": False}
    country = country_codes.get(request.geographies[0].strip().lower())
    if country:
        common["country"] = country
    return [{**common, "query": query[:500]} for query in queries]
