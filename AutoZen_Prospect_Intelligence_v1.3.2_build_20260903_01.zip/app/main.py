from functools import lru_cache
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

from app.adapters.live import ProviderError
from app.config import Settings, get_settings
from app.costing import estimate_zero_cost_usage
from app.exporter import delivery_to_csv, delivery_to_review_csv
from app.factory import build_pipeline
from app.pipeline import LeadPipeline
from app.schemas import LeadDelivery, LeadRequest, OutcomeEvent
from app.store import SQLiteStore
from app.version import BUILD_ID, BUILD_LABEL, ENGINE_VERSION
from app.access import OwnerAccess
from app.global_discovery import GlobalRequest, discover_global, global_estimate, research_csv
from app.public_web import WebReadError
from app.run_control import RunLedger


app = FastAPI(
    title="AutoZen Prospect Intelligence",
    version=ENGINE_VERSION,
    description=(
        "Evidence-backed global company discovery, quotation/RFQ research, decision-maker enrichment, deterministic scoring, and ranked prospect delivery."
    ),
)
app.add_middleware(OwnerAccess)

STATIC_DIR = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@lru_cache
def store() -> SQLiteStore:
    return SQLiteStore(get_settings().database_path)


@lru_cache
def pipeline() -> LeadPipeline:
    return build_pipeline(get_settings())


def ledger() -> RunLedger:
    return RunLedger(get_settings().database_path)


async def controlled(request: Request, live: bool, callback):
    settings = get_settings()
    if live and (not settings.enable_live_runs or settings.data_mode != 'live'):
        raise HTTPException(403, 'Live runs are off. Keep them off until you approve a bounded test in Render.')
    if live and (not settings.dashboard_username or len(settings.dashboard_password or '') < 16):
        raise HTTPException(403, 'Configure a private owner login before live requests.')
    operations = ledger()
    key = request.headers.get('Idempotency-Key', '')
    old = operations.reserve(key, request.url.path, await request.json(), live, settings.daily_live_run_limit)
    if old is not None:
        return old
    try:
        result = await callback()
        operations.finish(key, result)
        return result
    except BaseException:
        operations.fail(key)
        raise


@app.get("/health")
async def health() -> dict[str, str]:
    settings = get_settings()
    return {
        "status": "ok",
        "engine_version": ENGINE_VERSION,
        "build_id": BUILD_ID,
        "data_mode": settings.data_mode,
        "narrative_mode": settings.narrative_mode,
    }


@app.get("/v1/status")
async def engine_status() -> dict[str, object]:
    settings = get_settings()
    if settings.data_mode != "live":
        company_discovery = "fictional_demo"
    elif settings.company_provider == "hunter" or (
        settings.company_provider == "auto" and settings.hunter_api_key
    ):
        company_discovery = (
            "firecrawl_web+hunter_enrichment"
            if settings.firecrawl_api_key
            else "hunter_discover"
        )
    elif settings.apollo_api_key:
        company_discovery = "apollo"
    else:
        company_discovery = "csv_required"
    return {
        "status": "ready",
        "engine_version": ENGINE_VERSION,
        "build_id": BUILD_ID,
        "build_label": BUILD_LABEL,
        "data_mode": settings.data_mode,
        "narrative_mode": settings.narrative_mode,
        "providers": {
            "company_discovery": company_discovery,
            "signal_research": (
                "firecrawl"
                if settings.data_mode == "live" and settings.firecrawl_api_key
                else "not_configured"
                if settings.data_mode == "live"
                else "fictional_demo"
            ),
            "contact_verification": (
                "hunter"
                if settings.data_mode == "live" and settings.hunter_api_key
                else "not_configured"
                if settings.data_mode == "live"
                else "fictional_demo"
            ),
            "narrative": settings.narrative_mode,
            "csv_import": "available",
        },
        "limits": {"maximum_leads_per_run": 50, "maximum_import_rows": 100},
        "zero_cost_guardrails": {
            "note": "Legacy field name: these are per-run call limits, not a free-use guarantee or account-wide budget.",
            "hunter_company_enrichment_limit_per_run": settings.hunter_candidate_attempts_per_run,
            "hunter_estimated_max_credits_per_run": settings.hunter_candidate_attempts_per_run * 2,
            "firecrawl_results_per_company": settings.firecrawl_results_per_company,
            "openai_required": False,
        },
        "outreach_sending": False,
        "live_runs_enabled": settings.enable_live_runs,
        "daily_live_run_limit": settings.daily_live_run_limit,
        "live_runs_used_today": ledger().used_today(),
        "global_discovery": {"available": True, "maximum_locations": 3, "maximum_search_results_per_location": 10,
                             "maximum_website_checks": 5, "hunter_required": False},
    }


@app.get("/v1/readiness")
async def readiness() -> dict[str, object]:
    settings = get_settings()
    live_blockers: list[str] = []
    if not settings.hunter_api_key:
        live_blockers.append("Add HUNTER_API_KEY privately in the deployment environment.")
    if not settings.firecrawl_api_key:
        live_blockers.append("Add FIRECRAWL_API_KEY privately in the deployment environment.")

    return {
        "application": "ready",
        "environment": settings.app_environment,
        "demo_ready": True,
        "live_data_ready": not live_blockers,
        "live_data_blockers": live_blockers,
        "global_search_configured": bool(settings.firecrawl_api_key),
        "login_configured": bool(settings.dashboard_username and len(settings.dashboard_password or '') >= 16),
        "live_runs_enabled": settings.enable_live_runs,
        "note": "Configuration checks only. Global live behavior and this deployment require a controlled test; /tmp storage is not durable.",
    }


@app.post("/v1/cost-estimate")
async def cost_estimate(request: LeadRequest) -> dict[str, object]:
    return estimate_zero_cost_usage(get_settings(), request)


@app.get("/", include_in_schema=False)
async def dashboard() -> FileResponse:
    return FileResponse(
        STATIC_DIR / "index.html",
        headers={"Cache-Control": "no-store, max-age=0"},
    )


@app.post("/v1/leads/generate", response_model=LeadDelivery)
async def generate_leads(request: LeadRequest, http_request: Request) -> LeadDelivery:
    async def run():
        try:
            delivery = await pipeline().run(request)
        except ProviderError as error:
            raise HTTPException(status_code=503, detail='A provider request failed. No automatic whole-job retry was made.') from error
        store().save_delivery(delivery)
        return delivery.model_dump(mode='json')
    return await controlled(http_request, get_settings().data_mode == 'live', run)


@app.get('/global', include_in_schema=False)
async def global_dashboard():
    return FileResponse(STATIC_DIR / 'global.html', headers={'Cache-Control': 'no-store'})


@app.post('/v1/global/estimate')
async def estimate_global(request: GlobalRequest):
    return global_estimate(request)


@app.post('/v1/global/discover')
async def generate_global(request: GlobalRequest, http_request: Request):
    if request.mode == 'live' and not get_settings().firecrawl_api_key:
        raise HTTPException(503, 'Configure FIRECRAWL_API_KEY privately before live discovery. No run was reserved.')
    async def run():
        try:
            return await discover_global(request, get_settings().firecrawl_api_key)
        except WebReadError as error:
            raise HTTPException(503, str(error)) from error
    network_run = request.mode == 'live' or (request.mode == 'import' and request.website_checks > 0)
    return await controlled(http_request, network_run, run)


@app.get('/v1/global/jobs/{job_id}')
async def get_global_job(job_id: str):
    result = ledger().get_result(job_id) if job_id.startswith('global_') else None
    if result is None:
        raise HTTPException(404, 'Saved global research not found. Export results before redeploying ephemeral storage.')
    return result


@app.get('/v1/global/jobs/{job_id}/research.csv')
async def export_global_research(job_id: str):
    result = await get_global_job(job_id)
    return PlainTextResponse(research_csv(result), media_type='text/csv; charset=utf-8',
                             headers={'Content-Disposition': f'attachment; filename="{job_id}_unqualified_research.csv"'})


@app.get("/v1/jobs")
async def list_jobs(limit: int = 20) -> list[dict[str, object]]:
    return store().list_deliveries(limit=max(1, min(limit, 100)))


@app.get("/v1/jobs/{job_id}", response_model=LeadDelivery)
async def get_job(job_id: str) -> LeadDelivery:
    delivery = store().get_delivery(job_id)
    if delivery is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return delivery


@app.get("/v1/jobs/{job_id}/export.csv")
async def export_job_csv(job_id: str) -> PlainTextResponse:
    delivery = store().get_delivery(job_id)
    if delivery is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return PlainTextResponse(
        delivery_to_csv(delivery),
        media_type="text/csv; charset=utf-8",
        headers={
            "Content-Disposition": f'attachment; filename="{job_id}.csv"'
        },
    )


@app.get("/sample/company-import.csv", include_in_schema=False)
async def sample_import_csv() -> FileResponse:
    return FileResponse(
        Path(__file__).parents[1] / "sample" / "company-import.csv",
        media_type="text/csv",
        filename="autozen-company-import-template.csv",
    )


@app.get('/v1/jobs/{job_id}/review.csv')
async def export_review_csv(job_id: str) -> PlainTextResponse:
    delivery = store().get_delivery(job_id)
    if delivery is None:
        raise HTTPException(status_code=404, detail='Job not found')
    return PlainTextResponse(delivery_to_review_csv(delivery), media_type='text/csv; charset=utf-8',
        headers={'Content-Disposition': f'attachment; filename="{job_id}_unqualified_research.csv"'})


@app.post("/v1/outcomes", status_code=201)
async def record_outcome(event: OutcomeEvent) -> dict[str, str]:
    if store().get_delivery(event.job_id) is None:
        raise HTTPException(status_code=404, detail="Job not found")
    store().save_outcome(event)
    return {"status": "recorded"}


@app.get("/v1/jobs/{job_id}/outcomes")
async def get_outcomes(job_id: str) -> list[dict[str, str | None]]:
    if store().get_delivery(job_id) is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return store().list_outcomes(job_id)
