# AutoZen Prospect Intelligence 1.3.2

Build 20260903-01. A focused source-screening update to 1.3.1 in the existing AutoZen service. Villow is unchanged. No new provider calls were made while building or testing this update.

## What changed in 1.3.2

- Recognized government domains are excluded from business candidates, with source text and a reason retained in `meta.discovery.excluded_entries`.
- Possible manufacturer/distributor profiles and locator pages are retained separately in `meta.discovery.references`, not turned into the source host's business candidate. Each reference keeps `source_domain` and `source_url`; `prospect_domain` stays null. A mentioned company name is literal, unverified title text, not a verified identity.
- Different distributor profiles on one manufacturer host remain separate references. A manufacturer's own ordinary company page can still be a separate, unverified business candidate.
- Reference/excluded pages are not selected for Global website reads. No domain is guessed or visited from a snippet's email address.
- Global JSON replay retains all three groups as source text and recomputes classifications. Imported qualification, identity and contact claims are not trusted. Use **Reuse saved JSON**, with **website reads 0**, for a fully offline check.
- Research CSV contains **business candidates only**. Reference/exclusion evidence stays in JSON and separate dashboard sections. Supplier handoff uses candidates only; its server-side screening also rejects these source types in older saved JSON before website/Hunter processing.
- Authentication, provider keys, dependencies, search query/payload, request budgets, retry behaviour, spending controls and deployment settings are unchanged. No new endpoints or providers were added.

### Saved Australia regression result

The supplied `global_322e892a5eb34446.json` recorded a successful v1.3.1 search: five results, no recorded error, 1,006 ms. Its estimated two search credits are not a billing receipt. The original file is preserved as a regression fixture; the following is an **offline replay**, not another live test.

| Saved source | v1.3.2 treatment |
| --- | --- |
| wileyxaustralia.com.au | Unverified business candidate |
| atlascopco.com page describing NCPS Industrial | Separate reference; NCPS name is an unverified title hint, its own website remains unknown |
| aer.gov.au | Excluded from business candidates as a government source |
| banlaw.com | Unverified business candidate |
| bonfiglioli.com | Unverified business candidate; distributor fit is not established |

Expected totals: **3 candidates, 1 reference, 1 excluded result, 0 qualified leads**. Offline import records zero search, website, Hunter and OpenAI requests. These deterministic heuristics do not establish niche fit, operating location, employee count, ownership, buying intent or deliverability. They can miss unfamiliar reference patterns or conservatively hold a legitimate company page for review; they are not a complete worldwide government registry or entity-resolution service.

## Retained diagnostics from 1.3.1

- Failed Global searches now identify the HTTP client's known error category: connect/read/write/pool timeout, connection, protocol, decoding or HTTP response failure.
- JSON exports include each query's UTC start time, elapsed milliseconds and a sanitized `diagnostic` object. Failed search details expand automatically in the dashboard.
- When an underlying DNS, TLS or connection exception is actually attached, its allowlisted category is recorded; otherwise it stays `unknown`. Error messages are never used to guess a cause.
- Failures emit a `global_search_failure` log containing only fixed categories and timing. No API keys, headers, provider response bodies, exception messages, query contents or stack traces are emitted by this diagnostic logger.
- Known request encoding failures are reported safely instead of exposing the raw exception. The key is not trimmed, replaced, corrected or sent anywhere new.
- Existing 25-second HTTP client timeouts, 20,000-ms provider request timeout, search payload, no-retry policy, authentication, run limits and dependencies are unchanged. HTTPX timeouts apply to individual network operations, not an overall wall-clock deadline.

The earlier `global_bf7d092c338c4940` export contains only `search_network_error`. The later v1.3.1 failure reported `search_local_protocol_error`. A subsequent owner-run test succeeded after the key was recopied; the exact cause of the original failure is not proven. This release does not alter HTTP/key handling or recover unrecorded diagnostics.

### Reading a new failure

| Field | Meaning |
| --- | --- |
| `error` / `diagnostic.code` | Fixed error category, not the provider's raw message |
| `diagnostic.error_type` | Known HTTP client exception class, or internal response validation error |
| `diagnostic.stage` | Last application step; not a packet trace |
| `diagnostic.http_status` | Status actually received, or null when unavailable |
| `diagnostic.response_received` | Whether response headers were observed; null if unknown |
| `diagnostic.underlying_cause` | Known attached exception category, otherwise unknown |
| `started_at` / `elapsed_ms` | UTC start and measured time for this search operation |
| `diagnostic.retry_attempted` | False; the application does not retry the failed search |

No observed HTTP status does not prove that Firecrawl did not receive, process or bill the request. An HTTP 200 followed by a body timeout is still a failed client-side search. `search_requests` counts attempted search operations, including local failures; `search_credits_estimated` is not a receipt. Old saved JSON remains readable but retains its original limited diagnostic detail.

| Workflow | Route | Output |
| --- | --- | --- |
| Supplier qualification | / | Existing v1.2.6 industrial supplier research, contact checks and scoring, now behind login and run controls. |
| Global discovery | /global | Public business website candidates for a niche across up to three named markets. All results remain unqualified research. |

## Global discovery

- Fictional demo: no network calls; clearly marked .example records.
- Live: one Firecrawl web-only search per location, at most three locations and ten results per location. No automatic retries, no Hunter and no OpenAI. A provider failure stops remaining searches.
- Reuse JSON: accepts AutoZen discovery JSON or a Firecrawl web search export. Only URLs, titles and snippets become seeds. Set website reads to zero for fully offline review.
- Website reads: up to five businesses, two pages each, sharing a cap of 24 requests including robots and redirects. Private networks, blocked pages, cross-origin redirects and unsupported content are skipped. No login, CAPTCHA or robots restrictions are bypassed.
- Country codes are explicit or resolved from a small common-country map. Supply a two-letter code for other markets. Local-language niche text is accepted; automatic translation and global coverage are not validated.
- Published role-based same-domain business emails and tel: phone links are labelled published_unverified, never mailbox-verified or consented. No personal profiles are scraped.
- Requested location is not a verified company address. Size, buyer role, buying intent and deliverability remain unknown unless separately checked.
- This is bounded research automation, not an unattended workforce or unlimited scraper. No LLM is required for the global workflow.

## Handoff between workflows

Save Global discovery JSON, open Supplier qualification, enter a matching industrial supplier brief, and upload under Reuse previous research. Only business candidates become seeds; references and exclusions do not. This skips repeated discovery searches, but website checks, Hunter enrichment and RFQ research may still consume resources and require approval. Other niches remain research-only; the supplier criteria are not a general-purpose scorer for dentists, roofers or all businesses.

## Safety and storage

Hosted or live-configured deployments require owner HTTP Basic authentication over the host's HTTPS connection. Missing/short passwords fail closed except for the minimal /health endpoint. Store passwords and provider keys only in Render environment settings.

ENABLE_LIVE_RUNS defaults to false. DATA_MODE=live alone does not authorize execution. Live calls require an owner password of at least 16 characters. Both workflows share DAILY_LIVE_RUN_LIMIT=1 by default (configurable from 1 to 5). Imported research with public website reads also counts as a live run; zero-page offline imports do not.

Every run requires an Idempotency-Key. Same key and inputs return the saved result; changed inputs conflict. The dashboard retains the same key for retries while its page stays open. Failed and interrupted live runs count toward the UTC daily limit. Uncertain interrupted operations deliberately block new live work until reviewed; they do not retry automatically.

SQLite saves jobs, request keys and counters. These survive only if the database file survives. /tmp on an ephemeral host is not durable: restarts/redeployments can erase results and counters. This is not a provider-account budget or a zero-cost guarantee. Storage, backups, uptime and spending controls still need production validation.

## Validation and limits

239 offline Python tests and 23 Node dashboard-logic checks passed locally on Python 3.12.13. The previous 202 Python and 19 Node cases are retained, with release assertions updated. New tests cover the saved five-result replay, hostname boundaries, reference patterns, own-company negative cases, multi-market deduplication, discarded imported claims, reference-only outputs, CSV separation, no reads/enrichment for references and authenticated offline persistence without consuming the live allowance. Provider network calls are blocked in tests. No provider credits were spent on this update.

Node tests use a DOM double, not a browser. The new Docker image, Render deployment and visual layout on iPad are not verified here. The earlier owner-run search establishes only that one search worked on v1.3.1, not live website/contact verification or general coverage. Docker runs Python tests at build time. This is a tested build candidate, not an already deployed or fully deliverable agent.

Use DEPLOYMENT.md for activation and the no-credit saved-JSON check. Earlier release notes in the working tree are historical; these two documents govern 1.3.2.

Local checks:

    python -m pip install -r requirements.lock
    python -m pytest
    node --test tests/dashboard_logic.cjs tests/global_dashboard.cjs
    python -m scripts.run_autozen_server

The dependency lock records the existing validation environment, not a security audit.

References: [HTTPX exception categories](https://www.python-httpx.org/exceptions/), [HTTPX timeout meanings](https://www.python-httpx.org/advanced/timeouts/), [Firecrawl search contract](https://docs.firecrawl.dev/api-reference/endpoint/search), [search credits](https://docs.firecrawl.dev/features/search), [Render Docker](https://render.com/docs/docker), [environment settings](https://render.com/docs/configure-environment-variables), [free-service limits](https://render.com/docs/free).
