from __future__ import annotations

import re


def _normalise(value: str) -> str:
    return " ".join(
        re.sub(r"[^a-z0-9]+", " ", value.lower().replace("&", " and ")).split()
    )


ROLE_ALIASES: dict[str, tuple[str, ...]] = {
    "owner": ("owner", "co owner", "principal", "managing member"),
    "founder": ("founder", "co founder"),
    "ceo": ("ceo", "chief executive officer"),
    "president": ("president",),
    "head of sales": (
        "head of sales",
        "sales director",
        "director of sales",
        "vp sales",
        "vp of sales",
        "vice president sales",
        "vice president of sales",
        "chief revenue officer",
        "commercial director",
    ),
    "marketing director": (
        "marketing director",
        "director of marketing",
        "head of marketing",
        "vp marketing",
        "vp of marketing",
        "vice president marketing",
        "vice president of marketing",
        "chief marketing officer",
    ),
}


def title_matches_requested_roles(title: str | None, roles: list[str]) -> bool:
    """Match requested buyer roles without accepting unrelated directors."""

    normalised_title = _normalise(title or "")
    if not normalised_title:
        return False
    padded_title = f" {normalised_title} "
    for role in roles:
        normalised_role = _normalise(role)
        aliases = ROLE_ALIASES.get(normalised_role, (normalised_role,))
        if any(f" {_normalise(alias)} " in padded_title for alias in aliases):
            return True
    return False
