"""Single source of truth for AutoZen release and deployment identity."""

ENGINE_VERSION = "1.2.2"
BUILD_ID = "20260830-05"
BUILD_LABEL = f"v{ENGINE_VERSION} · build {BUILD_ID}"
