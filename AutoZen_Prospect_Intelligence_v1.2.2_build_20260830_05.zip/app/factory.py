from app.adapters.live import (
    ApolloCompanySource,
    FirecrawlHunterCompanySource,
    FirecrawlSignalSource,
    HunterCompanySource,
    HunterContactVerifier,
)
from app.adapters.imported import ImportAwareCompanySource, ImportAwareSignalSource
from app.adapters.mock import (
    MockCompanySource,
    MockContactVerifier,
    MockSignalSource,
)
from app.adapters.optional import (
    OptionalSignalSource,
    PassthroughContactVerifier,
    UnavailableCompanySource,
)
from app.config import Settings
from app.narrative import OpenAINarrativeSource, TemplateNarrativeSource
from app.pipeline import LeadPipeline


def build_pipeline(settings: Settings) -> LeadPipeline:
    if settings.data_mode == "mock":
        company_source = MockCompanySource()
        signal_source = MockSignalSource()
        contact_verifier = MockContactVerifier()
    else:
        if settings.company_provider == "hunter" or (
            settings.company_provider == "auto" and settings.hunter_api_key
        ):
            company_source = (
                FirecrawlHunterCompanySource(
                    settings.hunter_api_key or "",
                    settings.firecrawl_api_key,
                    max_company_enrichments=settings.hunter_candidate_attempts_per_run,
                )
                if settings.firecrawl_api_key
                else HunterCompanySource(
                    settings.hunter_api_key or "",
                    max_company_enrichments=settings.hunter_candidate_attempts_per_run,
                )
            )
        elif settings.company_provider == "apollo" or settings.apollo_api_key:
            company_source = ApolloCompanySource(settings.apollo_api_key or "")
        else:
            company_source = UnavailableCompanySource()
        signal_source = (
            FirecrawlSignalSource(
                settings.firecrawl_api_key,
                results_per_company=settings.firecrawl_results_per_company,
            )
            if settings.firecrawl_api_key
            else OptionalSignalSource()
        )
        contact_verifier = (
            HunterContactVerifier(settings.hunter_api_key)
            if settings.hunter_api_key
            else PassthroughContactVerifier()
        )

    company_source = ImportAwareCompanySource(company_source)
    signal_source = ImportAwareSignalSource(signal_source)

    if settings.narrative_mode == "openai":
        narrative_source = OpenAINarrativeSource(
            settings.openai_api_key or "", settings.openai_model
        )
    else:
        narrative_source = TemplateNarrativeSource()

    return LeadPipeline(
        company_source=company_source,
        signal_source=signal_source,
        contact_verifier=contact_verifier,
        narrative_source=narrative_source,
        mode=settings.data_mode,
        max_concurrency=settings.max_concurrency,
    )
