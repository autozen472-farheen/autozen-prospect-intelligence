from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from app.schemas import LeadDelivery, OutcomeEvent


class SQLiteStore:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize(self) -> None:
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS deliveries (
                    job_id TEXT PRIMARY KEY,
                    generated_at TEXT NOT NULL,
                    payload_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS outcomes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_id TEXT NOT NULL,
                    company_domain TEXT NOT NULL,
                    outcome TEXT NOT NULL,
                    note TEXT,
                    recorded_at TEXT NOT NULL
                );
                """
            )

    def save_delivery(self, delivery: LeadDelivery) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                INSERT OR REPLACE INTO deliveries(job_id, generated_at, payload_json)
                VALUES (?, ?, ?)
                """,
                (
                    delivery.meta.job_id,
                    delivery.meta.generated_at.isoformat(),
                    delivery.model_dump_json(),
                ),
            )

    def get_delivery(self, job_id: str) -> LeadDelivery | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT payload_json FROM deliveries WHERE job_id = ?", (job_id,)
            ).fetchone()
        if row is None:
            return None
        return LeadDelivery.model_validate_json(row["payload_json"])

    def list_deliveries(self, limit: int = 20) -> list[dict[str, object]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT payload_json FROM deliveries
                ORDER BY generated_at DESC LIMIT ?
                """,
                (limit,),
            ).fetchall()
        items: list[dict[str, object]] = []
        for row in rows:
            delivery = LeadDelivery.model_validate_json(row["payload_json"])
            items.append(
                {
                    "job_id": delivery.meta.job_id,
                    "generated_at": delivery.meta.generated_at.isoformat(),
                    "mode": delivery.meta.mode,
                    "industry": delivery.request.industry,
                    "geographies": delivery.request.geographies,
                    "qualified_count": delivery.meta.qualified_count,
                    "requested_count": delivery.meta.requested_count,
                }
            )
        return items

    def save_outcome(self, event: OutcomeEvent) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO outcomes(job_id, company_domain, outcome, note, recorded_at)
                VALUES (?, ?, ?, ?, ?)
                """,
                (
                    event.job_id,
                    event.company_domain,
                    event.outcome,
                    event.note,
                    event.recorded_at.isoformat(),
                ),
            )

    def list_outcomes(self, job_id: str) -> list[dict[str, str | None]]:
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT company_domain, outcome, note, recorded_at
                FROM outcomes WHERE job_id = ? ORDER BY id ASC
                """,
                (job_id,),
            ).fetchall()
        return [dict(row) for row in rows]
