const form = document.querySelector("#lead-form");
const runButton = document.querySelector("#run-button");
const errorBox = document.querySelector("#form-error");
const emptyState = document.querySelector("#empty-state");
const loadingState = document.querySelector("#loading-state");
const deliverySection = document.querySelector("#delivery");
const fileInput = document.querySelector("#csv-file");
const fileLabel = document.querySelector("#file-label");

let lastDelivery = null;
let loadingTimer = null;

const loadingSteps = [
  ["Discovering companies", "Applying the industry, geography and company-size filters."],
  ["Researching sales evidence", "Checking quotation/RFQ, projects, tenders and technical-sales evidence."],
  ["Qualifying contacts", "Matching decision-makers and preserving the provider's email status."],
  ["Scoring and ranking", "Calculating ICP fit, commercial value, quotation/RFQ evidence, reachability and evidence quality."],
];

function splitList(value) {
  return value.split(",").map((item) => item.trim()).filter(Boolean);
}

function numberValue(selector) {
  return Number(document.querySelector(selector).value);
}

function selectedSignals() {
  return [...document.querySelectorAll('input[name="signals"]:checked')].map((item) => item.value);
}

function showError(message) {
  errorBox.textContent = message;
  errorBox.hidden = false;
}

function clearError() {
  errorBox.textContent = "";
  errorBox.hidden = true;
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = "";
  let quoted = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];
    if (char === '"' && quoted && next === '"') {
      cell += '"';
      index += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === "," && !quoted) {
      row.push(cell.trim());
      cell = "";
    } else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && next === "\n") index += 1;
      row.push(cell.trim());
      if (row.some(Boolean)) rows.push(row);
      row = [];
      cell = "";
    } else {
      cell += char;
    }
  }
  row.push(cell.trim());
  if (row.some(Boolean)) rows.push(row);
  if (rows.length < 2) throw new Error("The CSV has no company rows.");

  const headers = rows[0].map((header) => header.trim().toLowerCase());
  const required = ["company_name", "domain", "industry", "country", "employee_count"];
  const missing = required.filter((header) => !headers.includes(header));
  if (missing.length) throw new Error(`CSV is missing required columns: ${missing.join(", ")}.`);

  const records = rows.slice(1).map((values) => Object.fromEntries(headers.map((header, i) => [header, values[i] || ""])));
  const grouped = new Map();
  for (const record of records) {
    const key = record.domain.toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/$/, "");
    if (!key) continue;
    if (!grouped.has(key)) {
      grouped.set(key, {
        name: record.company_name,
        domain: key,
        website: record.website || `https://${key}`,
        industry: record.industry,
        city: record.city || null,
        state: record.state || null,
        country: record.country || null,
        employee_count: record.employee_count ? Number(record.employee_count) : null,
        technologies: record.technologies ? record.technologies.split("|").map((item) => item.trim()).filter(Boolean) : [],
        active_job_count: record.active_job_count ? Number(record.active_job_count) : null,
        contact_name: record.contact_name || null,
        contact_title: record.contact_title || null,
        contact_email: record.contact_email || null,
        email_type: record.email_type || "unknown",
        contact_phone: record.contact_phone || null,
        phone_type: record.phone_type || "unknown",
        linkedin_url: record.linkedin_url || null,
        company_source_url: record.company_source_url || null,
        contact_source_url: record.contact_source_url || null,
        evidence: [],
      });
    }
    if (record.signal_type && record.signal_title && record.signal_url) {
      grouped.get(key).evidence.push({
        signal_type: record.signal_type,
        title: record.signal_title,
        url: record.signal_url,
        snippet: record.signal_snippet || "",
        published_at: record.signal_date || null,
        confidence: record.signal_confidence ? Number(record.signal_confidence) : 0.7,
      });
    }
  }
  return [...grouped.values()];
}

async function buildRequest() {
  const minEmployees = numberValue("#employee-min");
  const maxEmployees = numberValue("#employee-max");
  const signals = selectedSignals();
  if (maxEmployees < minEmployees) throw new Error("Maximum employees must be greater than or equal to minimum employees.");
  if (!signals.length) throw new Error("Select at least one evidence type to prioritize.");

  const request = {
    industry: document.querySelector("#industry").value.trim(),
    products_or_services: document.querySelector("#products-or-services").value.trim(),
    geographies: splitList(document.querySelector("#geographies").value),
    employee_min: minEmployees,
    employee_max: maxEmployees,
    desired_count: numberValue("#desired-count"),
    target_roles: splitList(document.querySelector("#target-roles").value),
    desired_signals: signals,
    freshness_days: 90,
    minimum_score: numberValue("#minimum-score"),
    // The selected signals are ranking preferences, not mandatory filters.
    // Leads without a verified current trigger remain eligible and are clearly
    // labelled as having no current timing evidence.
    require_timing_signal: false,
  };
  if (fileInput.files.length) {
    request.seed_companies = parseCsv(await fileInput.files[0].text());
    if (request.seed_companies.length > 100) throw new Error("Import at most 100 unique companies per run.");
  }
  return request;
}

function startLoading() {
  emptyState.hidden = true;
  deliverySection.hidden = true;
  loadingState.hidden = false;
  runButton.disabled = true;
  let index = 0;
  const update = () => {
    const [title, copy] = loadingSteps[index % loadingSteps.length];
    document.querySelector("#loading-title").textContent = title;
    document.querySelector("#loading-copy").textContent = copy;
    index += 1;
  };
  update();
  loadingTimer = window.setInterval(update, 2600);
}

function stopLoading() {
  window.clearInterval(loadingTimer);
  loadingState.hidden = true;
  runButton.disabled = false;
}

function appendText(parent, tag, text, className) {
  const element = document.createElement(tag);
  if (className) element.className = className;
  element.textContent = text;
  parent.appendChild(element);
  return element;
}

function safeHttpUrl(value) {
  try {
    const url = new URL(value);
    return ["http:", "https:"].includes(url.protocol) ? url.href : null;
  } catch {
    return null;
  }
}

function renderLead(lead) {
  const card = document.createElement("article");
  card.className = "lead-card";
  const top = document.createElement("div");
  top.className = "lead-top";
  appendText(top, "div", `#${lead.rank}`, "rank-badge");
  const identity = document.createElement("div");
  appendText(identity, "h3", lead.company.name, "company-title");
  const location = [lead.company.city, lead.company.state, lead.company.country].filter(Boolean).join(", ");
  const employeeText = lead.company.employee_count ?? (
    lead.company.employee_count_min && lead.company.employee_count_max
      ? `${lead.company.employee_count_min}-${lead.company.employee_count_max}`
      : "?"
  );
  appendText(identity, "p", `${lead.company.industry} · ${location || "Location unavailable"} · ${employeeText} employees`, "company-meta");
  top.appendChild(identity);
  const score = document.createElement("div");
  score.className = "score-badge";
  appendText(score, "strong", String(lead.score.total));
  appendText(score, "span", "SCORE / 100");
  top.appendChild(score);
  card.appendChild(top);

  const body = document.createElement("div");
  body.className = "lead-body";
  appendText(body, "p", lead.narrative.why_now, "reason");
  appendText(body, "p", `Outreach angle: ${lead.narrative.outreach_hook}`, "hook");

  const contacts = document.createElement("div");
  contacts.className = "contact-row";
  const contactLabel = [lead.contact.name, lead.contact.title].filter(Boolean).join(" · ") || "Decision-maker unavailable";
  appendText(contacts, "span", contactLabel, "contact-chip");
  if (lead.contact.email) appendText(contacts, "span", `${lead.contact.email} · ${lead.contact.email_type} · ${lead.contact.email_status}`, "contact-chip");
  if (lead.contact.phone) appendText(contacts, "span", `${lead.contact.phone} · ${lead.contact.phone_type}`, "contact-chip");
  const companySource = safeHttpUrl(lead.company.source_url);
  if (companySource) {
    const link = appendText(contacts, "a", "Company source", "contact-chip");
    link.href = companySource;
    link.target = "_blank";
    link.rel = "noreferrer";
  }
  const contactSource = safeHttpUrl(lead.contact.source_url);
  if (contactSource) {
    const link = appendText(contacts, "a", "Contact source", "contact-chip");
    link.href = contactSource;
    link.target = "_blank";
    link.rel = "noreferrer";
  }
  for (const evidence of lead.evidence) appendText(contacts, "span", evidence.signal_type.replaceAll("_", " "), "signal-chip");
  body.appendChild(contacts);

  const evidenceList = document.createElement("div");
  evidenceList.className = "evidence-list";
  for (const evidence of lead.evidence) {
    const item = document.createElement("div");
    item.className = "evidence-item";
    appendText(item, "span", "↗", "signal-chip");
    const detail = document.createElement("div");
    const link = document.createElement("a");
    link.textContent = evidence.title;
    const href = safeHttpUrl(evidence.url);
    if (href) {
      link.href = href;
      link.target = "_blank";
      link.rel = "noreferrer";
    }
    detail.appendChild(link);
    appendText(detail, "p", `${evidence.published_at || "Undated"} · ${Math.round(evidence.confidence * 100)}% evidence confidence`);
    item.appendChild(detail);
    evidenceList.appendChild(item);
  }
  if (lead.evidence.length) body.appendChild(evidenceList);
  card.appendChild(body);
  return card;
}

function renderDelivery(delivery) {
  lastDelivery = delivery;
  const count = delivery.leads.length;
  document.querySelector("#delivery-title").textContent = `${count} ranked lead${count === 1 ? "" : "s"}`;
  document.querySelector("#delivery-meta").textContent =
    `${delivery.meta.job_id} · ${delivery.meta.mode.toUpperCase()} · ` +
    `v${delivery.meta.engine_version} · build ${delivery.meta.build_id} · ${delivery.meta.duration_ms} ms`;

  const warning = document.querySelector("#delivery-warning");
  warning.hidden = !delivery.meta.warnings.length;
  warning.textContent = delivery.meta.warnings.join(" ");

  const scores = delivery.leads.map((lead) => lead.score.total);
  const average = scores.length ? Math.round(scores.reduce((sum, value) => sum + value, 0) / scores.length) : 0;
  const summary = document.querySelector("#score-summary");
  summary.replaceChildren();
  const summaryRows = [
    ["Candidates considered", delivery.meta.candidates_considered],
    ["Qualified delivery", count],
    ["Average score", average],
  ];
  for (const [label, value] of summaryRows) {
    const box = document.createElement("div");
    box.className = "summary-card";
    appendText(box, "span", label);
    appendText(box, "strong", String(value));
    summary.appendChild(box);
  }

  const list = document.querySelector("#lead-list");
  list.replaceChildren();
  if (!delivery.leads.length) {
    const reasons = delivery.meta.rejection_summary || {};
    const details = [
      ["industry mismatch", reasons.industry],
      ["employee-range mismatch", reasons.employee_range],
      ["geography mismatch", reasons.geography],
      ["missing required sales-process evidence", reasons.missing_required_sales_signal],
      ["unusable buyer contact", reasons.unusable_contact],
      ["below minimum score", reasons.below_minimum_score],
      ["provider failure", reasons.provider_failure],
    ].filter(([, count]) => Number(count) > 0)
      .map(([label, count]) => `${count} ${label}`)
      .join("; ");
    appendText(
      list,
      "p",
      details ? `No leads passed. Exact reasons: ${details}.` : "No companies were discovered for this brief.",
      "alert warning",
    );
  } else {
    for (const lead of delivery.leads) list.appendChild(renderLead(lead));
  }

  document.querySelector("#csv-export").href = `/v1/jobs/${encodeURIComponent(delivery.meta.job_id)}/export.csv`;
  const jsonBlob = new Blob([JSON.stringify(delivery, null, 2)], { type: "application/json" });
  document.querySelector("#json-export").href = URL.createObjectURL(jsonBlob);
  document.querySelector("#json-export").download = `${delivery.meta.job_id}.json`;
  deliverySection.hidden = false;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  clearError();
  try {
    const request = await buildRequest();
    const estimateResponse = await fetch("/v1/cost-estimate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request),
    });
    if (estimateResponse.ok) {
      const estimate = await estimateResponse.json();
      document.querySelector("#cost-note").textContent =
        `Estimated cash charge: AED ${estimate.estimated_cash_charge}. ` +
        `Maximum Hunter credits: ${estimate.hunter.estimated_max_credits}; ` +
        `Firecrawl credits: ${estimate.firecrawl.estimated_max_credits}.`;
    }
    startLoading();
    const response = await fetch("/v1/leads/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(request),
    });
    const payload = await response.json();
    if (!response.ok) {
      const detail = typeof payload.detail === "string" ? payload.detail : JSON.stringify(payload.detail);
      throw new Error(detail || `Engine failed with status ${response.status}.`);
    }
    stopLoading();
    renderDelivery(payload);
  } catch (error) {
    stopLoading();
    emptyState.hidden = false;
    showError(error.message || "The engine could not complete this run.");
  }
});

fileInput.addEventListener("change", () => {
  fileLabel.textContent = fileInput.files[0]?.name || "Choose CSV";
});

document.querySelector("#reset-button").addEventListener("click", () => {
  form.reset();
  fileInput.value = "";
  fileLabel.textContent = "Choose CSV";
  clearError();
});

fetch("/v1/status")
  .then((response) => response.json())
  .then((status) => {
    document.querySelector("#engine-mode").textContent =
      `${status.data_mode.toUpperCase()} MODE · v${status.engine_version} · BUILD ${status.build_id}`;
    document.querySelector(".status-dot").classList.add("ready");
  })
  .catch(() => {
    document.querySelector("#engine-mode").textContent = "ENGINE UNAVAILABLE";
  });
