from __future__ import annotations

from urllib.parse import urlparse

from app.adapters.base import CompanySource, SignalSource
from app.schemas import (
    CompanyCandidate,
    CompanySeed,
    Contact,
    EmailStatus,
    EmailType,
    Evidence,
    LeadRequest,
    PhoneType,
)


def _normalise_domain(value: str) -> str:
    candidate = value.strip()
    if "://" not in candidate:
        candidate = f"https://{candidate}"
    return urlparse(candidate).netloc.lower().removeprefix("www.")


def _matching_seed(request: LeadRequest, domain: str) -> CompanySeed | None:
    normalised = _normalise_domain(domain)
    for seed in request.seed_companies:
        if _normalise_domain(seed.domain) == normalised:
            return seed
    return None


class ImportAwareCompanySource:
    """Use supplied company rows when present, otherwise call the live/mock source."""

    def __init__(self, fallback: CompanySource) -> None:
        self.fallback = fallback

    async def discover(
        self, request: LeadRequest, candidate_limit: int
    ) -> list[CompanyCandidate]:
        if not request.seed_companies:
            return await self.fallback.discover(request, candidate_limit)

        companies: list[CompanyCandidate] = []
        for index, seed in enumerate(request.seed_companies[:candidate_limit], start=1):
            domain = _normalise_domain(seed.domain)
            if not domain:
                continue
            companies.append(
                CompanyCandidate(
                    provider_id=f"import-{index:03d}-{domain}",
                    name=seed.name,
                    domain=domain,
                    website=seed.website or f"https://{domain}",
                    industry=seed.industry,
                    city=seed.city,
                    state=seed.state,
                    country=seed.country,
                    employee_count=seed.employee_count,
                    technologies=seed.technologies,
                    active_job_count=seed.active_job_count,
                    source_provider="import",
                    source_url=seed.company_source_url,
                    public_phone=seed.contact_phone,
                )
            )
        return companies

    async def find_contact(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> Contact:
        seed = _matching_seed(request, company.domain)
        if seed is None:
            return await self.fallback.find_contact(company, request)
        return Contact(
            name=seed.contact_name,
            title=seed.contact_title,
            email=seed.contact_email,
            email_status=(
                EmailStatus.UNKNOWN
                if seed.contact_email
                else EmailStatus.UNAVAILABLE
            ),
            email_type=(
                seed.email_type
                if seed.contact_email
                else EmailType.UNAVAILABLE
            ),
            phone=seed.contact_phone,
            phone_type=(
                seed.phone_type
                if seed.contact_phone
                else PhoneType.UNAVAILABLE
            ),
            linkedin_url=seed.linkedin_url,
            source_provider="import",
            source_url=seed.contact_source_url or seed.linkedin_url,
        )


class ImportAwareSignalSource:
    """Use supplied evidence when present and research via the fallback otherwise."""

    def __init__(self, fallback: SignalSource) -> None:
        self.fallback = fallback

    async def research(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> list[Evidence]:
        seed = _matching_seed(request, company.domain)
        if seed is None or not seed.evidence:
            return await self.fallback.research(company, request)
        return [
            Evidence(
                signal_type=item.signal_type,
                title=item.title,
                url=item.url,
                snippet=item.snippet,
                source_provider="import",
                published_at=item.published_at,
                confidence=item.confidence,
            )
            for item in seed.evidence
        ]
