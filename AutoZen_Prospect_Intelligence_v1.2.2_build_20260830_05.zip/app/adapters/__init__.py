"""Data provider adapters."""

