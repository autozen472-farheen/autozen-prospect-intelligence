from datetime import date, timedelta

from app.schemas import (
    CompanyCandidate,
    Contact,
    EmailStatus,
    EmailType,
    Evidence,
    LeadRequest,
    PhoneType,
    SignalType,
)


class MockCompanySource:
    async def discover(
        self, request: LeadRequest, candidate_limit: int
    ) -> list[CompanyCandidate]:
        companies = [
            CompanyCandidate(
                provider_id="demo-001",
                name="BluePeak Heating & Air",
                domain="bluepeak-hvac.example",
                website="https://bluepeak-hvac.example",
                industry="HVAC services",
                city="Denver",
                state="Colorado",
                country="United States",
                employee_count=34,
                technologies=["WordPress", "HubSpot"],
                active_job_count=8,
                source_provider="mock",
            ),
            CompanyCandidate(
                provider_id="demo-002",
                name="Summit Comfort Systems",
                domain="summit-comfort.example",
                website="https://summit-comfort.example",
                industry="HVAC",
                city="Phoenix",
                state="Arizona",
                country="United States",
                employee_count=22,
                technologies=["Google Analytics"],
                active_job_count=4,
                source_provider="mock",
            ),
            CompanyCandidate(
                provider_id="demo-003",
                name="Coastal Breeze HVAC",
                domain="coastal-breeze.example",
                website="https://coastal-breeze.example",
                industry="HVAC services",
                city="Tampa",
                state="Florida",
                country="United States",
                employee_count=48,
                technologies=["ServiceTitan"],
                active_job_count=1,
                source_provider="mock",
            ),
            CompanyCandidate(
                provider_id="demo-004",
                name="Hearthline Mechanical",
                domain="hearthline.example",
                website="https://hearthline.example",
                industry="HVAC",
                city="Columbus",
                state="Ohio",
                country="United States",
                employee_count=16,
                technologies=[],
                active_job_count=0,
                source_provider="mock",
            ),
            CompanyCandidate(
                provider_id="demo-005",
                name="NorthStar Climate Co",
                domain="northstar-climate.example",
                website="https://northstar-climate.example",
                industry="HVAC",
                city="Minneapolis",
                state="Minnesota",
                country="United States",
                employee_count=62,
                technologies=["Salesforce"],
                active_job_count=12,
                source_provider="mock",
            ),
        ]
        return companies[:candidate_limit]

    async def find_contact(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> Contact:
        contacts = {
            "bluepeak-hvac.example": Contact(
                name="Jordan Lee",
                title="Owner",
                email="jordan@bluepeak-hvac.example",
                email_status=EmailStatus.VERIFIED,
                email_type=EmailType.PERSON_WORK,
                phone="+1 555 010 1001",
                phone_type=PhoneType.PERSON,
                source_provider="mock",
            ),
            "summit-comfort.example": Contact(
                name="Morgan Rivera",
                title="President",
                email="morgan@summit-comfort.example",
                email_status=EmailStatus.VERIFIED,
                email_type=EmailType.PERSON_WORK,
                source_provider="mock",
            ),
            "coastal-breeze.example": Contact(
                name="Taylor Chen",
                title="Marketing Director",
                email="taylor@coastal-breeze.example",
                email_status=EmailStatus.ACCEPT_ALL,
                email_type=EmailType.PERSON_WORK,
                source_provider="mock",
            ),
            "hearthline.example": Contact(
                name="Casey Patel",
                title="General Manager",
                email=None,
                email_status=EmailStatus.UNAVAILABLE,
                email_type=EmailType.UNAVAILABLE,
                source_provider="mock",
            ),
        }
        return contacts.get(
            company.domain,
            Contact(source_provider="mock", email_status=EmailStatus.UNAVAILABLE),
        )


class MockSignalSource:
    async def research(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> list[Evidence]:
        today = date.today()
        evidence = {
            "bluepeak-hvac.example": [
                Evidence(
                    signal_type=SignalType.QUOTATION_RFQ,
                    title="BluePeak lists eight current service and sales openings",
                    url="https://bluepeak-hvac.example/careers",
                    snippet="The careers page lists current technician, dispatcher, and comfort-advisor openings.",
                    source_provider="mock",
                    published_at=today - timedelta(days=8),
                    confidence=0.95,
                ),
                Evidence(
                    signal_type=SignalType.PROJECT_TENDER,
                    title="BluePeak announces a second Denver-area service hub",
                    url="https://local-business-news.example/bluepeak-expansion",
                    snippet="The company announced a new service hub to support growth across the Denver metro area.",
                    source_provider="mock",
                    published_at=today - timedelta(days=21),
                    confidence=0.9,
                ),
            ],
            "summit-comfort.example": [
                Evidence(
                    signal_type=SignalType.QUOTATION_RFQ,
                    title="Summit Comfort is hiring installation and customer-care staff",
                    url="https://summit-comfort.example/jobs",
                    snippet="Four active roles indicate additional delivery and customer-care capacity.",
                    source_provider="mock",
                    published_at=today - timedelta(days=14),
                    confidence=0.91,
                ),
                Evidence(
                    signal_type=SignalType.TECHNICAL_SALES,
                    title="Summit Comfort adds weekend service availability",
                    url="https://phoenix-trade-news.example/summit-weekend-service",
                    snippet="The expanded service schedule may increase enquiry and booking volume.",
                    source_provider="mock",
                    published_at=today - timedelta(days=35),
                    confidence=0.78,
                ),
            ],
            "coastal-breeze.example": [
                Evidence(
                    signal_type=SignalType.PROJECT_TENDER,
                    title="Coastal Breeze opens service coverage in two additional counties",
                    url="https://coastal-breeze.example/news/new-service-area",
                    snippet="The company expanded its stated service territory into two neighbouring counties.",
                    source_provider="mock",
                    published_at=today - timedelta(days=30),
                    confidence=0.93,
                )
            ],
            "hearthline.example": [],
        }
        return evidence.get(company.domain, [])


class MockContactVerifier:
    async def verify_or_find(
        self, company: CompanyCandidate, contact: Contact
    ) -> Contact:
        return contact
