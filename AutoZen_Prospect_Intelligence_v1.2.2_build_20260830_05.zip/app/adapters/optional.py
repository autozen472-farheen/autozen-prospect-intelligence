from __future__ import annotations

from app.adapters.live import ProviderError
from app.schemas import CompanyCandidate, Contact, Evidence, LeadRequest


class UnavailableCompanySource:
    async def discover(
        self, request: LeadRequest, candidate_limit: int
    ) -> list[CompanyCandidate]:
        raise ProviderError(
            "Automatic company discovery is not configured. Add a free "
            "HUNTER_API_KEY, configure APOLLO_API_KEY, or upload the "
            "provider-neutral CSV template."
        )

    async def find_contact(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> Contact:
        return Contact(source_provider="unavailable")


class OptionalSignalSource:
    async def research(
        self, company: CompanyCandidate, request: LeadRequest
    ) -> list[Evidence]:
        return []


class PassthroughContactVerifier:
    async def verify_or_find(
        self, company: CompanyCandidate, contact: Contact
    ) -> Contact:
        return contact
