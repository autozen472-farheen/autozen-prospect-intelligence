# AutoZen Prospect Intelligence v1.2.1

Reliability patch for live Firecrawl evidence research.

- Adds bounded Firecrawl concurrency (2 simultaneous requests per signal source).
- Retries transient 408/409/425/429/5xx Firecrawl failures up to 3 attempts with short exponential backoff and jitter.
- Does not retry permanent 4xx configuration/client errors.
- Classifies repeated provider outages as `provider_unavailable` instead of treating the company as a weak prospect.
- Keeps the v1.2 wide discovery and pre-Hunter qualification gate unchanged.
- Uses Python 3.13 in the deployment wrapper.

Focused reliability tests: retry-on-429, fail-fast-on-400, and v1.2 discovery-cap tests pass.
