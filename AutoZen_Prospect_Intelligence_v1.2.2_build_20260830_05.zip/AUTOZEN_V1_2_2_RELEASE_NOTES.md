# AutoZen Prospect Intelligence v1.2.2

Build: 20260830-05

## Goal
Reduce Firecrawl rate-limit failures and protect scarce Hunter credits without lowering lead quality.

## Changes
- Firecrawl requests now share one global pacing gate across discovery and evidence research.
- Default Firecrawl pacing is ~3.25 seconds between outbound search requests (about 18 requests/minute maximum).
- Identical Firecrawl searches are cached in-process for 15 minutes.
- Firecrawl retries are reduced to 2 by default; a 429 receives a longer cooldown before the final retry.
- Wide discovery is condensed from up to 9 searches to 4 high-signal searches per run.
- Hunter candidate enrichment defaults to a hard cap of 3 attempts per run.
- Cost estimation now reflects the 4-search discovery path.

## Recommended first live test
- Leads requested: 1
- Minimum score: 60
- HUNTER_CANDIDATE_ATTEMPTS_PER_RUN: 3
- Run once, then audit provider warnings and delivered evidence before increasing volume.
