# AutoZen Prospect Intelligence v1.0

Evidence-backed global B2B prospecting engine. It discovers companies, verifies ICP fit and geography, researches quotation/RFQ/project/technical-sales evidence, finds requested decision-makers, preserves email verification status, scores prospects deterministically, and exports ranked outreach-ready records.

## Score (100)
- ICP fit: 30
- Commercial/B2B value: 20
- Quotation/RFQ evidence: 20
- Decision-maker & reachability: 15
- Evidence quality: 15

The engine never sends outreach. Weak or unsupported prospects are rejected rather than invented to fill a quota.
