# Seven-day delivery plan

This schedule assumes two to four focused hours per day and a narrow HVAC test.
It is a certification MVP, not a universal lead-generation platform.

## Day 1 — requirements and baseline

- Obtain Villow's SDK/repository, publisher agreement, input/output schema,
  certification briefs, deadline, timeout, hosting rule, and API-cost responsibility.
- Run mock mode and tests.
- Send Villow the mock output schema for early confirmation.
- Freeze the first brief: US HVAC, 10–50 employees, 3–10 leads, hiring/expansion.

Exit condition: Villow confirms the contract or lists required changes.

## Day 2 — company discovery

- Obtain Apollo access through an account using a work-domain email.
- Put the key in `.env`; never commit or message it.
- Run live company discovery for only three candidates.
- Check industry, employee count, location, website, and duplicates manually.

Exit condition: at least 80% of sampled companies pass manual ICP review.

## Day 3 — signal research

- Add the Firecrawl key.
- Inspect every source URL, date, title, and snippet.
- Reject irrelevant same-name companies and unsupported signals.
- Tune keywords only from observed errors.

Exit condition: every accepted timing claim has a source URL and credible evidence.

## Day 4 — decision-makers and emails

- Add the Hunter key.
- Validate roles and email statuses.
- Never label `accept_all`, `unknown`, or missing emails as verified.
- Measure contact coverage on the small sample.

Exit condition: no fabricated contacts and every status is accurately labelled.

## Day 5 — narrative and Villow adapter

- Enable the optional OpenAI narrative only after the data pipeline is correct.
- Review all "why now" and outreach hooks against the evidence.
- Implement the Villow SDK adapter using their exact contract.
- Add a fixture representing one Villow certification request and response.

Exit condition: the application accepts and returns Villow's exact schema.

## Day 6 — certification rehearsal

- Run all automated tests.
- Run 10 test briefs or the maximum Villow provided.
- Record relevance, evidence accuracy, contact coverage, duplicates, time, and cost.
- Fix systemic errors; do not manually hide bad results.

Exit condition: repeatable output and a written scorecard for every test.

## Day 7 — package and demonstrate

- Remove secrets, test files containing personal information, and unused output.
- Confirm `.env` is ignored.
- Run tests from a clean installation.
- Prepare one live, manually checked delivery and one two-minute demo.
- Deliver source, README, environment-variable list, sample request/response,
  test results, known limitations, and maintenance instructions.

Exit condition: Villow can run the project without relying on undocumented steps.

## Stop conditions

Do not claim production readiness if any of these remain unresolved:

- Villow has not provided an integration contract.
- Provider keys or data rights are missing.
- Live source URLs and contact statuses have not been manually checked.
- Unit economics are unknown.
- Secrets are embedded in files.
- The system works only because results were manually edited.

