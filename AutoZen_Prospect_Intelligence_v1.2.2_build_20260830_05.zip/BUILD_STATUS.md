# Build status — August 28, 2026 · v0.7.0 · build 20260828-02

## Completed

- Standalone review dashboard and REST API.
- Firecrawl-first company-web discovery for HVAC, with recruiter/directory/vendor
  rejection, followed by Hunter firmographic enrichment and decision-maker lookup.
- Two-pass Hunter Discover remains the fallback and the non-HVAC discovery path.
- Firecrawl web/news timing-signal research adapter.
- Provider-neutral CSV import path.
- Strict ICP filters, timing-signal ranking and deterministic 100-point score. A
  timing signal can be required by an explicit API brief, but dashboard signals
  are ranking preferences rather than a hidden eligibility gate.
- Evidence URLs, dates, company/contact provenance and honest email/phone types.
- Template narratives with no paid LLM call.
- Ranked JSON/CSV exports and outcome tracking.
- Villow Python SDK prepare/execute/status/result lifecycle and table artifact.
- One combined server and Docker/Render free deployment configuration.
- Dashboard password protection and signed Villow routes.
- Conservative `/v1/cost-estimate` and `/v1/readiness` checks.
- Visible API/dashboard build identity and cache-busted dashboard assets.
- Exact rejection diagnostics for industry, employee range, geography, timing,
  score and provider failures.
- 32 automated tests passing, including the hybrid live-provider simulation.
- Three real public-source HVAC calibration leads passing.
- Official local `villow.publisher.v1` contract checks passing.

## Pending only because they require the owner's accounts or Villow

- Your private Hunter API key.
- Your private Firecrawl API key.
- Your GitHub/Render deployment login and resulting public URL.
- Villow's publisher ID, agent ID, signing key ID, signing secret and category slug.
- Villow's final frozen certification brief and acceptance rubric.

No code rewrite is needed for these values; they are environment configuration.

The Docker/Render definition is included and the combined server was exercised
directly. This workspace does not provide a Docker executable, so the local
container-image build itself could not be run here; Render performs that build
from the supplied Dockerfile.

## Honest delivery label

The current artifact is a **certification-ready, zero-cost MVP**. It is not an
unlimited production SaaS. Production claims should wait until live provider runs
are manually inspected and Villow supplies its production credentials.
