# AutoZen Prospect Intelligence v1.1.0

Build: 20260830-02

## Changes
- Evidence-first qualification: Firecrawl research runs before Hunter decision-maker lookup.
- Hunter contact lookup is skipped when a company cannot mathematically reach the requested minimum score even with perfect reachability.
- Required RFQ/project/technical-sales evidence gates are evaluated before contact lookup.
- Corrected Render variable name to `HUNTER_CANDIDATE_ATTEMPTS_PER_RUN`.
- Default example candidate-attempt cap reduced to 3 for conservative live testing.
- Removed stale Villow runtime/config artifacts from the AutoZen package.
- AutoZen release identity updated to v1.1.0 / build 20260830-02.

## First live test
Keep `APP_ENVIRONMENT=demo`, `NARRATIVE_MODE=template`, and use `HUNTER_CANDIDATE_ATTEMPTS_PER_RUN=3`. Start with 1 requested lead.
