# Handoff and acceptance checklist

## Delivery definition

The September 7 delivery is a **certification-ready MVP with a Villow SDK
adapter**. A user can open a web interface, define an ICP, run the pipeline with
demo/live/imported data, inspect ranked leads, follow evidence links and export
CSV/JSON. Villow can also call the signed SDK lifecycle endpoints.

It is not being represented as a fully scaled multi-tenant SaaS. Production
Villow identifiers and signing credentials are inserted only after onboarding.

## Five-minute evaluator demo

1. Open the dashboard and point out the 100-point scoring methodology.
2. Keep the default HVAC brief and generate three fictional leads.
3. Open the top result and show:
   - deterministic score;
   - decision-maker and email status;
   - at least two source-backed signals;
   - why-now rationale;
   - outreach hypothesis.
4. Export CSV and show that evidence URLs and dates are included.
5. Explain that a provider CSV can replace Apollo discovery.
6. Switch to a manually checked live sample only after provider configuration.

## Technical acceptance

- [x] Clean installation metadata resolves from the README and lockfile.
- [x] The preserved project runtime passes 34 tests with no failures (August 28).
- [x] Official `villow.publisher.v1` local contract test passes all six checks.
- [x] `/health`, `/v1/status` and `/v1/readiness` return successfully.
- [x] Mock generation produces sorted, deduplicated leads.
- [x] Imported CSV rows are grouped by normalized domain.
- [x] Hard ICP filters reject wrong industry, location and employee size.
- [x] Every accepted timing claim has a source URL.
- [x] Unknown/accept-all emails are not labelled verified.
- [x] CSV and JSON exports work from stored jobs.
- [x] A saved job can be retrieved from SQLite.
- [x] Final source secret scan contains no real provider or Villow credentials.

## Live-data acceptance

- [ ] Villow provides one frozen evaluation brief and acceptance rubric.
- [ ] Owner creates free Hunter and Firecrawl accounts and privately configures keys.
- [ ] Run size and expected cost are approved before consuming credits.
- [ ] At least 10 live test deliveries are manually reviewed (3 completed through the public-source calibration path).
- [x] Initial company relevance, evidence accuracy, contact coverage and duplicates are recorded.
- [ ] Known misses are disclosed rather than manually hidden.

## Required Villow decisions before production connection

1. Exact certification brief(s) and minimum acceptance score.
2. Whether they will evaluate a hosted URL, Docker package, source archive or all three.
3. Who funds external data/API usage during evaluation and after launch.
4. Required lead count, maximum execution time and retry behavior.
5. Mandatory output fields and whether phone numbers are required.
6. Data retention/deletion and privacy requirements.
7. Ownership/licence terms before source-code transfer.

## Source handoff safety

Do not provide production credentials in the archive. Supply `.env.example`; the
recipient adds secrets in their own deployment environment. Confirm the commercial
and IP agreement before transferring the final source archive.
