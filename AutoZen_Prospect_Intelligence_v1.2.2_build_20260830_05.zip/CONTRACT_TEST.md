# Villow local contract-test record

Date: August 24, 2026 (Dubai time)

Contract: `villow.publisher.v1`

Endpoint tested: `http://127.0.0.1:8088`

Development identity: `publisher_local` / `agent_local` / `key_local`

Result: PASS

The official Villow CLI passed all six checks:

1. Signature verification
2. SDK schema package availability
3. Signed `/discover`
4. Idempotent duplicate request handling
5. Stale timestamp rejection
6. Malformed `/prepare` request rejection

These local values are placeholders, not Villow production credentials. Villow's
real publisher ID, agent ID, signing key ID and signing secret are supplied later
through environment variables without changing the engine code.
