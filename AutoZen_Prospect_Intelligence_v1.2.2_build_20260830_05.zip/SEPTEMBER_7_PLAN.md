# September 7 delivery plan

This plan assumes a frozen standalone-MVP scope and immediate access to the chosen
data providers. Dates are Dubai time.

## August 24 — core build and Villow contract complete

- Standalone dashboard, API, deterministic scoring and persistence.
- Fictional demo provider, zero-cost Hunter/Firecrawl adapters, optional Apollo/OpenAI.
- Provider-neutral CSV import and CSV/JSON exports.
- Villow SDK prepare, execute, artifact and signed lifecycle endpoints.
- 25-test automated suite, official local contract test and Docker/Render packaging.

## August 25–27 — live provider calibration

- Select automatic discovery provider or an approved CSV source.
- [x] Run the first 3 leads through the provider-neutral public-source path.
- [x] Manually check company fit, contact status and every evidence URL.
- Configure provider secrets privately only after the provider is selected.
- Record provider cost and coverage; do not buy large credit packs yet.

## August 28–30 — evaluation quality

- Obtain Villow's exact test brief and rubric.
- Run 10 controlled briefs or the number Villow specifies.
- Tune aliases, same-name rejection, signal classification and thresholds from errors.
- Measure relevance, evidence accuracy, contact coverage, duplicate rate, time and cost.

## August 31–September 2 — delivery hardening

- Fix systemic errors from the evaluation set.
- Test empty results, provider failures, missing emails and undated evidence.
- Run from a clean install and Docker image.
- Decide hosted link versus source/Docker handoff with Villow.

## September 3–4 — evaluator package

- Produce one manually verified live delivery and one fictional safe demo.
- Record a short demo showing brief → ranked leads → evidence → export.
- Finalize README, environment variables, limitations and test scorecard.

## September 5 — internal deadline

- Freeze features.
- Run all automated and manual acceptance checks.
- Remove secrets and private test data from the package.

## September 6 — contingency

- Fix only blocking defects.
- Rehearse the five-minute evaluator demo.

## September 7 — delivery

- Deliver the agreed artifact and the acceptance checklist.
- State remaining production or Villow-SDK work separately.

## Non-negotiable stop conditions

Do not call the engine production-ready if live providers are untested, source
claims have not been inspected, API economics are unknown, or Villow's acceptance
contract is still undefined. Deliver it accurately as a certification-ready MVP.
