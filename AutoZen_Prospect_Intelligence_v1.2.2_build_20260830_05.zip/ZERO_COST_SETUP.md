# AED 0 setup — beginner checklist

The engine code is complete and tested. The remaining actions need your own
accounts because API keys and deployment ownership must stay with you. Never paste
an API key, signing secret or dashboard password into chat, email or screenshots.

## What “zero cost” means

- Hunter free: 50 credits per month and API access.
- Firecrawl free: 1,000 credits per month.
- Render free: one free web service is enough for the dashboard and Villow routes.
- OpenAI is not required; `NARRATIVE_MODE=template` is free.
- No outreach is sent, so there is no email-sending cost.

The default three-lead run attempts at most 18 company enrichments, discards
known ICP mismatches, and builds a pool of up to nine matched companies. Contact
lookup happens only for that pool, so the conservative maximum is 27 Hunter
credits. This is intended for a certification-quality run, not repeated testing.
To stretch the allowance during development, set
`HUNTER_CANDIDATE_ATTEMPTS_PER_RUN=6`.

Free allowances are account-specific and can change. Do not add a paid plan or
card-based auto-upgrade. If a provider reports no credits remaining, stop until
the allowance renews or Villow approves a budget.

## Part A — run the finished demo locally

1. Unzip the delivery.
2. Install Python 3.13 and `uv`.
3. Open a terminal inside the project folder.
4. Run `uv sync`.
5. Copy `.env.example` to `.env`.
6. Leave `DATA_MODE=mock` for the safe fictional demo.
7. Run `uv run python -m scripts.run_villow_server`.
8. Open `http://127.0.0.1:8080`.
9. Keep the default brief and click **Generate ranked leads**.

This mode uses no external account and spends nothing.

## Part B — create the two free live-data accounts

### Hunter

1. Create a free Hunter account at `hunter.io`.
2. Open the API section of your Hunter dashboard and create/copy the API key.
3. In your private `.env`, set `HUNTER_API_KEY=...`.
4. Set `DATA_MODE=live` and `COMPANY_PROVIDER=hunter`.
5. Keep `HUNTER_CANDIDATE_ATTEMPTS_PER_RUN=6` for early tests and use the
   default 18-attempt budget only for the final three-lead run.

### Firecrawl

1. Create a free Firecrawl account at `firecrawl.dev`.
2. Create/copy an API key from the dashboard.
3. In your private `.env`, set `FIRECRAWL_API_KEY=...`.
4. Keep `FIRECRAWL_RESULTS_PER_COMPANY=5`.

Before generating live leads, open `/v1/readiness` and confirm
`live_data_ready: true`. Then send your brief to `/v1/cost-estimate`; the cash
estimate should be `0` and the warnings should be understood.

## Part C — deploy free on Render

1. Create a private GitHub repository. Upload the project but never upload `.env`.
2. Create a free Render account and connect that GitHub repository.
3. Choose **New → Blueprint** and select the repository. Render reads `render.yaml`.
4. Enter your Hunter and Firecrawl keys only in Render's secret environment fields.
5. Render generates a dashboard password. In Render, copy the generated value from
   `DASHBOARD_PASSWORD` and keep it private.
6. Wait for `/health` to report `status: ok`.
7. Open the Render URL. The browser asks for username `evaluator` and the generated
   password.
8. Share the URL and dashboard login only with the evaluator.

The dashboard password prevents strangers from consuming your free credits.
Villow's SDK routes use signed requests and do not use the dashboard password.

Render's free service sleeps after inactivity and may take about a minute to wake.
Its local files are temporary, so download the JSON/CSV delivery immediately. This
is acceptable for an evaluation MVP, not permanent production storage.

## Part D — connect Villow after they approve the agent

When Villow supplies the values, add these only in Render's environment settings:

```dotenv
APP_ENVIRONMENT=production
VILLOW_PUBLISHER_ID=
VILLOW_AGENT_ID=
VILLOW_SIGNING_KEY_ID=
VILLOW_SIGNING_SECRET=
```

Also replace the three `REPLACE_WITH_...` values in `agent.yaml` with the public
publisher ID, agent ID and exact category slug. Do not place the signing secret in
`agent.yaml` or GitHub.

## First live quality test

1. Ask for only three leads.
2. Open every company, contact and timing-signal source.
3. Confirm industry, country and employee bracket.
4. Confirm the evidence really names the company and is current.
5. Treat `unknown` and `accept_all` emails honestly; they are not verified.
6. Do not send outreach during certification testing.
7. Export JSON and CSV and record any false positives.

The engine deliberately returns fewer leads when candidates fail the timing or
quality gate. That is a quality feature, not a failure.
