# AutoZen Prospect Intelligence v1.2.1

Build: 20260830-04

## Discovery Expansion

- Expands Firecrawl discovery across 5 core search angles plus up to 4 product-specific searches.
- Builds and deduplicates a wider web candidate pool before Hunter company enrichment.
- Ranks web candidates using product relevance, distributor/supplier language, RFQ/quotation evidence, and project/tender/technical-sales signals.
- Excludes directories, recruiting sites, social networks, and common data-broker domains before Hunter.
- Preserves the configured Hunter company-enrichment cap; wider discovery does not increase that cap.
- Preserves the v1.1 pre-contact score gate, so Hunter decision-maker lookup still happens only when a candidate can plausibly pass the requested score.

## Verification

- Python compileall passed.
- New v1.2 discovery tests passed: 2/2.
- Tests confirm evidence-rich web candidates are enriched first and Hunter company enrichment never exceeds the configured cap.
- Legacy HVAC-era tests inherited from the original fork remain stale and are not release blockers for the AutoZen industrial schema; they should be removed/replaced in a future cleanup release.
