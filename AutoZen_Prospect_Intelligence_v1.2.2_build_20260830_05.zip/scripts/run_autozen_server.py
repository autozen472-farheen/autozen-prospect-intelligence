from __future__ import annotations
import os
import uvicorn
from app.main import app

def main() -> None:
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", "8080")))

if __name__ == "__main__":
    main()
