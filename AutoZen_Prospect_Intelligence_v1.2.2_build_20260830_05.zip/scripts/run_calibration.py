from __future__ import annotations

import argparse
import asyncio
import csv
import json
from collections import OrderedDict
from pathlib import Path
from typing import Any

from app.config import Settings
from app.exporter import delivery_to_csv
from app.factory import build_pipeline
from app.schemas import CompanySeed, LeadRequest, SeedEvidence


DEFAULT_INPUT = Path("sample/calibration-us-hvac-3.csv")
DEFAULT_OUTPUT = Path("calibration/latest")


def _optional(value: str | None) -> str | None:
    cleaned = (value or "").strip()
    return cleaned or None


def _optional_int(value: str | None) -> int | None:
    cleaned = _optional(value)
    return int(cleaned) if cleaned else None


def load_seeds(path: Path) -> list[CompanySeed]:
    grouped: OrderedDict[str, dict[str, Any]] = OrderedDict()
    with path.open(newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle):
            domain = row["domain"].strip().lower().removeprefix("www.")
            if domain not in grouped:
                grouped[domain] = {
                    "name": row["company_name"],
                    "domain": domain,
                    "website": _optional(row.get("website")),
                    "industry": row["industry"],
                    "city": _optional(row.get("city")),
                    "state": _optional(row.get("state")),
                    "country": _optional(row.get("country")),
                    "employee_count": _optional_int(row.get("employee_count")),
                    "technologies": [
                        item.strip()
                        for item in (row.get("technologies") or "").split("|")
                        if item.strip()
                    ],
                    "active_job_count": _optional_int(row.get("active_job_count")),
                    "contact_name": _optional(row.get("contact_name")),
                    "contact_title": _optional(row.get("contact_title")),
                    "contact_email": _optional(row.get("contact_email")),
                    "email_type": row.get("email_type") or "unknown",
                    "contact_phone": _optional(row.get("contact_phone")),
                    "phone_type": row.get("phone_type") or "unknown",
                    "linkedin_url": _optional(row.get("linkedin_url")),
                    "company_source_url": _optional(row.get("company_source_url")),
                    "contact_source_url": _optional(row.get("contact_source_url")),
                    "evidence": [],
                }
            if row.get("signal_type") and row.get("signal_title") and row.get("signal_url"):
                grouped[domain]["evidence"].append(
                    SeedEvidence(
                        signal_type=row["signal_type"],
                        title=row["signal_title"],
                        url=row["signal_url"],
                        snippet=row.get("signal_snippet") or "",
                        published_at=_optional(row.get("signal_date")),
                        confidence=float(row.get("signal_confidence") or 0.7),
                    )
                )
    return [CompanySeed.model_validate(value) for value in grouped.values()]


def quality_report(delivery: Any) -> str:
    leads = delivery.leads
    checks = {
        "Requested leads returned": len(leads) == delivery.meta.requested_count,
        "All leads passed the minimum score": all(
            lead.score.total >= delivery.request.minimum_score for lead in leads
        ),
        "Company provenance present": all(lead.company.source_url for lead in leads),
        "Decision-maker provenance present": all(lead.contact.source_url for lead in leads),
        "Timing evidence present": all(lead.evidence for lead in leads),
        "Every signal has a public URL": all(
            evidence.url.startswith("http")
            for lead in leads
            for evidence in lead.evidence
        ),
        "No imported email is falsely marked verified": all(
            lead.contact.email_status.value != "verified" for lead in leads
        ),
    }
    status = "PASS" if all(checks.values()) else "REVIEW REQUIRED"
    lines = [
        "# Step 5 public-source calibration",
        "",
        "Date: August 24, 2026 (Dubai time)",
        "",
        "Brief: Find three US HVAC companies with 10–50 employees that show active hiring or expansion signals.",
        "",
        f"Overall result: **{status}**",
        "",
        "## Automated quality gates",
        "",
    ]
    lines.extend(
        f"- [{'x' if passed else ' '}] {label}"
        for label, passed in checks.items()
    )
    lines.extend(["", "## Ranked output", ""])
    for lead in leads:
        lines.extend(
            [
                f"### {lead.rank}. {lead.company.name} — {lead.score.total}/100",
                "",
                f"- ICP: {lead.score.icp_fit}/40",
                f"- Timing: {lead.score.timing}/30",
                f"- Reachability: {lead.score.reachability}/15",
                f"- Evidence quality: {lead.score.evidence_quality}/15",
                f"- Contact: {lead.contact.name or 'Unavailable'} — {lead.contact.title or 'Unavailable'}",
                f"- Email: {lead.contact.email or 'Unavailable'} ({lead.contact.email_type.value}; {lead.contact.email_status.value})",
                f"- Why now: {lead.narrative.why_now}",
                "",
            ]
        )
    lines.extend(
        [
            "## Honest limitations",
            "",
            "- This is a manually researched calibration set, not automatic provider discovery.",
            "- Generic company inboxes remain `unknown`; they are not called verified personal emails.",
            "- Undated careers pages trigger a warning and must be rechecked immediately before outreach.",
            "- No outreach was sent and no paid provider credits were consumed.",
            "- Automatic discovery still requires an approved provider account and API key.",
            "",
        ]
    )
    return "\n".join(lines)


async def run(input_path: Path, output_dir: Path) -> None:
    request = LeadRequest(
        industry="HVAC",
        geographies=["United States"],
        employee_min=10,
        employee_max=50,
        desired_count=3,
        target_roles=[
            "Owner",
            "Managing Member",
            "General Manager",
            "President",
            "Marketing Director",
        ],
        desired_signals=["hiring", "expansion"],
        freshness_days=90,
        minimum_score=55,
        seed_companies=load_seeds(input_path),
    )
    settings = Settings(data_mode="live", narrative_mode="template")
    delivery = await build_pipeline(settings).run(request)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "delivery.json").write_text(
        delivery.model_dump_json(indent=2), encoding="utf-8"
    )
    (output_dir / "delivery.csv").write_text(
        delivery_to_csv(delivery), encoding="utf-8"
    )
    report = quality_report(delivery)
    (output_dir / "QUALITY_REPORT.md").write_text(report, encoding="utf-8")
    print(report)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the three-lead public-source calibration.")
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    asyncio.run(run(args.input, args.output))


if __name__ == "__main__":
    main()
