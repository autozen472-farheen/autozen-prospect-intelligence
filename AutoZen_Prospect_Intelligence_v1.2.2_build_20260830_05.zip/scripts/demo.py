import asyncio
import json

from app.config import Settings
from app.factory import build_pipeline
from app.schemas import LeadRequest


async def main() -> None:
    settings = Settings(data_mode="mock", narrative_mode="template")
    pipeline = build_pipeline(settings)
    delivery = await pipeline.run(
        LeadRequest(
            industry="HVAC",
            geographies=["United States"],
            employee_min=10,
            employee_max=50,
            desired_count=3,
            freshness_days=90,
        )
    )
    print(json.dumps(delivery.model_dump(mode="json"), indent=2))


if __name__ == "__main__":
    asyncio.run(main())

