import asyncio, json
import httpx
from app.adapters.live import FirecrawlHunterCompanySource
from app.schemas import LeadRequest


def test_v12_wide_web_pool_ranks_commercial_evidence_before_hunter_enrichment():
    hunter_domains=[]
    def handler(req: httpx.Request):
        if req.url.path.endswith('/search'):
            # Every query returns the same broad pool. High-value quote/RFQ pages
            # must rank before generic supplier pages.
            rows=[]
            for i in range(30):
                hot=i>=24
                rows.append({
                    'url': f'https://company-{i}.example/products',
                    'title': f'Industrial pump valve distributor {i}',
                    'description': ('Pumps valves compressors supplier. Request a quote RFQ projects technical sales.' if hot
                                    else 'Pumps valves industrial supplier distributor.'),
                })
            return httpx.Response(200,json={'data':{'web':rows}})
        if req.url.path.endswith('/companies/find'):
            domain=req.url.params['domain']; hunter_domains.append(domain)
            return httpx.Response(200,json={'data':{
                'id':domain,'name':domain,'domain':domain,
                'metrics':{'employees':'11-50'},'geo':{'country':'United Arab Emirates'},
                'category':{'industry':'Wholesale'}
            }})
        return httpx.Response(404)
    source=FirecrawlHunterCompanySource('hunter','firecrawl',max_company_enrichments=6,transport=httpx.MockTransport(handler))
    brief=LeadRequest(industry='Industrial equipment distributors',products_or_services='pumps, valves, compressors',geographies=['United Arab Emirates'],employee_min=5,employee_max=500,desired_count=1)
    companies=asyncio.run(source.discover(brief,20))
    assert len(hunter_domains) <= 6
    assert hunter_domains[0] in {f'company-{i}.example' for i in range(24,30)}
    assert companies


def test_v12_uses_multiple_discovery_angles_without_increasing_hunter_cap():
    bodies=[]; hunter_calls=0
    def handler(req: httpx.Request):
        nonlocal hunter_calls
        if req.url.path.endswith('/search'):
            bodies.append(json.loads(req.content)); idx=len(bodies)
            return httpx.Response(200,json={'data':{'web':[{
                'url':f'https://unique-{idx}.example','title':'Pump distributor UAE',
                'description':'Industrial pumps supplier request a quote'
            }]}})
        if req.url.path.endswith('/companies/find'):
            hunter_calls+=1; domain=req.url.params['domain']
            return httpx.Response(200,json={'data':{'id':domain,'name':domain,'domain':domain,'metrics':{'employees':'11-50'},'geo':{'country':'United Arab Emirates'},'category':{'industry':'Wholesale'}}})
        return httpx.Response(404)
    source=FirecrawlHunterCompanySource('hunter','firecrawl',max_company_enrichments=3,transport=httpx.MockTransport(handler))
    brief=LeadRequest(industry='Industrial equipment distributors',products_or_services='pumps, valves',geographies=['United Arab Emirates'],employee_min=5,employee_max=500,desired_count=1)
    asyncio.run(source.discover(brief,20))
    assert len(bodies) == 4
    assert hunter_calls <= 3
