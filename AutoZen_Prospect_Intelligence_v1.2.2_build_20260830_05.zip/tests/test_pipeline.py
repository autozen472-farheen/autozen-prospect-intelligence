import asyncio
from datetime import date, timedelta

import pytest

from app.adapters.live import ProviderError
from app.adapters.mock import MockCompanySource, MockContactVerifier, MockSignalSource
from app.config import Settings
from app.factory import build_pipeline
from app.narrative import TemplateNarrativeSource
from app.pipeline import LeadPipeline
from app.schemas import (
    CompanyCandidate,
    CompanySeed,
    Contact,
    EmailStatus,
    EmailType,
    LeadRequest,
    SeedEvidence,
    SignalType,
)


def test_mock_pipeline_returns_ranked_evidence_backed_leads(tmp_path) -> None:
    settings = Settings(
        data_mode="mock",
        narrative_mode="template",
        database_path=tmp_path / "test.db",
    )
    pipeline = build_pipeline(settings)
    delivery = asyncio.run(
        pipeline.run(LeadRequest(desired_count=3, minimum_score=55))
    )
    assert delivery.meta.mode == "mock"
    assert delivery.leads
    assert [lead.rank for lead in delivery.leads] == list(
        range(1, len(delivery.leads) + 1)
    )
    assert all(lead.evidence for lead in delivery.leads)
    totals = [lead.score.total for lead in delivery.leads]
    assert totals == sorted(totals, reverse=True)
    assert any("fictional" in warning for warning in delivery.meta.warnings)


def test_timing_signals_rank_leads_without_hiding_valid_icp_matches(tmp_path) -> None:
    settings = Settings(
        data_mode="mock",
        narrative_mode="template",
        database_path=tmp_path / "test.db",
    )
    pipeline = build_pipeline(settings)

    delivery = asyncio.run(
        pipeline.run(LeadRequest(desired_count=4, minimum_score=30))
    )
    no_signal_lead = next(
        lead for lead in delivery.leads if lead.company.domain == "hearthline.example"
    )
    assert no_signal_lead.evidence == []
    assert "no current timing signal" in no_signal_lead.narrative.why_now.lower()

    strict_delivery = asyncio.run(
        pipeline.run(
            LeadRequest(
                desired_count=4,
                minimum_score=30,
                require_timing_signal=True,
            )
        )
    )
    assert all(
        lead.company.domain != "hearthline.example" for lead in strict_delivery.leads
    )
    assert delivery.meta.engine_version == "0.7.0"
    assert delivery.meta.build_id == "20260828-02"
    assert set(delivery.meta.rejection_summary) == {
        "industry",
        "employee_range",
        "geography",
        "missing_required_timing_signal",
        "unusable_contact",
        "below_minimum_score",
        "provider_failure",
    }


def test_live_pipeline_rejects_invalid_or_wrong_role_contact() -> None:
    class CountingSignalSource(MockSignalSource):
        calls = 0

        async def research(self, company, request):
            self.calls += 1
            return await super().research(company, request)

    class InvalidBuyerSource(MockCompanySource):
        async def find_contact(
            self, company: CompanyCandidate, request: LeadRequest
        ) -> Contact:
            return Contact(
                name="Harper Reed",
                title="Director of Human Resources",
                email="hr@bluepeak-hvac.example",
                email_status=EmailStatus.INVALID,
                email_type=EmailType.PERSON_WORK,
                source_provider="hunter",
            )

    signals = CountingSignalSource()
    pipeline = LeadPipeline(
        company_source=InvalidBuyerSource(),
        signal_source=signals,
        contact_verifier=MockContactVerifier(),
        narrative_source=TemplateNarrativeSource(),
        mode="live",
    )
    delivery = asyncio.run(
        pipeline.run(LeadRequest(desired_count=1, minimum_score=0))
    )
    assert delivery.leads == []
    assert signals.calls == 0
    assert delivery.meta.rejection_summary["unusable_contact"] == 4
    assert any("valid or accept-all" in item for item in delivery.meta.warnings)


def test_import_pipeline_uses_provider_neutral_company_and_evidence(tmp_path) -> None:
    settings = Settings(
        data_mode="mock",
        narrative_mode="template",
        database_path=tmp_path / "test.db",
    )
    request = LeadRequest(
        industry="HVAC",
        geographies=["United States"],
        employee_min=10,
        employee_max=50,
        desired_count=1,
        minimum_score=50,
        seed_companies=[
            CompanySeed(
                name="Imported Heating",
                domain="imported-heating.example",
                industry="HVAC services",
                city="Austin",
                state="Texas",
                country="United States",
                employee_count=27,
                contact_name="Avery Smith",
                contact_title="Owner",
                contact_email="avery@imported-heating.example",
                evidence=[
                    SeedEvidence(
                        signal_type=SignalType.HIRING,
                        title="Imported Heating lists new service roles",
                        url="https://imported-heating.example/careers",
                        snippet="Three current technician openings.",
                        published_at=date.today() - timedelta(days=3),
                        confidence=0.9,
                    )
                ],
            )
        ],
    )
    delivery = asyncio.run(build_pipeline(settings).run(request))
    assert delivery.meta.mode == "import"
    assert delivery.leads[0].company.name == "Imported Heating"
    assert delivery.leads[0].contact.email == "avery@imported-heating.example"
    assert delivery.leads[0].evidence[0].source_provider == "import"
    assert not any("fictional" in warning for warning in delivery.meta.warnings)


def test_live_import_does_not_require_apollo_when_evidence_is_supplied(tmp_path) -> None:
    settings = Settings(
        data_mode="live",
        database_path=tmp_path / "test.db",
    )
    request = LeadRequest(
        desired_count=1,
        minimum_score=50,
        seed_companies=[
            CompanySeed(
                name="Portable Provider HVAC",
                domain="portable-provider.example",
                industry="HVAC",
                country="United States",
                employee_count=20,
                contact_name="Sam Lee",
                contact_title="Owner",
                evidence=[
                    SeedEvidence(
                        signal_type=SignalType.EXPANSION,
                        title="Portable Provider expands service coverage",
                        url="https://portable-provider.example/news",
                        published_at=date.today(),
                        confidence=0.9,
                    )
                ],
            )
        ],
    )
    delivery = asyncio.run(build_pipeline(settings).run(request))
    assert delivery.meta.mode == "import"
    assert delivery.leads[0].company.source_provider == "import"


def test_live_automatic_discovery_requires_configured_provider(tmp_path) -> None:
    settings = Settings(data_mode="live", database_path=tmp_path / "test.db")
    with pytest.raises(ProviderError, match="APOLLO_API_KEY"):
        asyncio.run(build_pipeline(settings).run(LeadRequest(desired_count=1)))
