import asyncio
import httpx

from app.adapters.live import FirecrawlSignalSource, ProviderError


def test_firecrawl_retries_429_then_succeeds():
    FirecrawlSignalSource._response_cache.clear()
    FirecrawlSignalSource._last_request_at = 0.0
    FirecrawlSignalSource._global_lock = None
    calls = {"n": 0}
    def handler(request: httpx.Request):
        calls["n"] += 1
        if calls["n"] < 3:
            return httpx.Response(429, json={"error": "rate limited"})
        return httpx.Response(200, json={"data": {"web": [], "news": []}})
    source = FirecrawlSignalSource(
        "test", transport=httpx.MockTransport(handler), max_attempts=3, max_concurrency=2, min_interval_seconds=0
    )
    original_sleep = asyncio.sleep
    async def no_sleep(_):
        return None
    asyncio.sleep = no_sleep
    try:
        payload = asyncio.run(source.search({"query": "test"}))
    finally:
        asyncio.sleep = original_sleep
    assert payload["data"]["web"] == []
    assert calls["n"] == 3


def test_firecrawl_does_not_retry_non_transient_400():
    FirecrawlSignalSource._response_cache.clear()
    FirecrawlSignalSource._last_request_at = 0.0
    FirecrawlSignalSource._global_lock = None
    calls = {"n": 0}
    def handler(request: httpx.Request):
        calls["n"] += 1
        return httpx.Response(400, json={"error": "bad request"})
    source = FirecrawlSignalSource(
        "test", transport=httpx.MockTransport(handler), max_attempts=3, min_interval_seconds=0
    )
    try:
        asyncio.run(source.search({"query": "test"}))
        assert False, "expected ProviderError"
    except ProviderError:
        pass
    assert calls["n"] == 1
