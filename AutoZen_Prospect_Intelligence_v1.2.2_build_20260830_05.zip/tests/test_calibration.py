import asyncio
from pathlib import Path

from app.config import Settings
from app.factory import build_pipeline
from app.schemas import LeadRequest
from scripts.run_calibration import load_seeds, quality_report


def test_public_calibration_fixture_passes_quality_gates() -> None:
    root = Path(__file__).parents[1]
    request = LeadRequest(
        industry="HVAC",
        geographies=["United States"],
        employee_min=10,
        employee_max=50,
        desired_count=3,
        target_roles=["Owner", "Managing Member", "General Manager"],
        desired_signals=["hiring", "expansion"],
        freshness_days=90,
        minimum_score=55,
        seed_companies=load_seeds(root / "sample/calibration-us-hvac-3.csv"),
    )
    delivery = asyncio.run(
        build_pipeline(Settings(data_mode="live", narrative_mode="template")).run(request)
    )

    assert len(delivery.leads) == 3
    assert all(lead.company.source_url for lead in delivery.leads)
    assert all(lead.contact.source_url for lead in delivery.leads)
    assert all(lead.evidence for lead in delivery.leads)
    assert "Overall result: **PASS**" in quality_report(delivery)
