import asyncio
import csv
import io

from app.config import Settings
from app.exporter import delivery_to_csv
from app.factory import build_pipeline
from app.schemas import LeadRequest


def test_csv_export_contains_ranked_intelligence(tmp_path) -> None:
    settings = Settings(database_path=tmp_path / "test.db")
    delivery = asyncio.run(
        build_pipeline(settings).run(LeadRequest(desired_count=1))
    )
    rows = list(csv.DictReader(io.StringIO(delivery_to_csv(delivery))))
    assert len(rows) == 1
    assert rows[0]["rank"] == "1"
    assert rows[0]["company_name"] == delivery.leads[0].company.name
    assert rows[0]["why_now"]
    assert rows[0]["evidence_urls"]
