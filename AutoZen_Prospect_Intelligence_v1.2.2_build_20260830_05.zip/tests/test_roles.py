from app.roles import title_matches_requested_roles


def test_role_aliases_accept_equivalent_revenue_leaders() -> None:
    roles = ["Owner", "CEO", "Head of Sales", "Marketing Director"]

    assert title_matches_requested_roles("Co-Owner", roles)
    assert title_matches_requested_roles("Chief Executive Officer", roles)
    assert title_matches_requested_roles("Director of Sales", roles)
    assert title_matches_requested_roles("VP of Marketing", roles)


def test_role_aliases_do_not_accept_unrequested_directors() -> None:
    roles = ["Owner", "CEO", "Head of Sales", "Marketing Director"]

    assert not title_matches_requested_roles("Human Resources Director", roles)
    assert not title_matches_requested_roles("Engineering Director", roles)
