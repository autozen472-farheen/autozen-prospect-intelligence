import asyncio
import json

import httpx

from app.adapters.live import (
    FirecrawlHunterCompanySource,
    FirecrawlSignalSource,
    HunterContactVerifier,
)
from app.narrative import TemplateNarrativeSource
from app.pipeline import LeadPipeline
from app.schemas import LeadRequest


def test_live_flow_returns_icp_leads_when_priority_signals_are_absent() -> None:
    domains = [f"contractor-{index}.example" for index in range(1, 7)]

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/discover"):
            body = json.loads(request.content)
            selected = domains[:3] if "industry" in body else domains
            return httpx.Response(
                200,
                json={
                    "data": [
                        {"domain": domain, "organization": f"HVAC Contractor {index}"}
                        for index, domain in enumerate(selected, start=1)
                    ]
                },
            )
        if request.url.path.endswith("/companies/find"):
            domain = request.url.params["domain"]
            return httpx.Response(
                200,
                json={
                    "data": {
                        "id": domain,
                        "name": domain.split(".")[0].replace("-", " ").title(),
                        "domain": domain,
                        "metrics": {"employees": "11-50"},
                        "geo": {"state": "Texas", "country": "United States"},
                        "category": {
                            "industry": "Specialty Trade Contractors",
                            "subIndustry": "Building Equipment Contractors",
                        },
                        "site": {"phoneNumbers": ["+1 555 010 2000"]},
                    }
                },
            )
        if request.url.path.endswith("/domain-search"):
            domain = request.url.params["domain"]
            return httpx.Response(
                200,
                json={
                    "data": {
                        "emails": [
                            {
                                "value": f"owner@{domain}",
                                "type": "personal",
                                "first_name": "Alex",
                                "last_name": "Owner",
                                "position": "Owner",
                                "decision_maker": True,
                                "confidence": 95,
                                "verification": {"status": "valid"},
                            }
                        ]
                    }
                },
            )
        if request.url.path.endswith("/search"):
            body = json.loads(request.content)
            query = str(body.get("query") or "").lower()
            if "hvac contractor company" in query or "heating and cooling" in query:
                return httpx.Response(
                    200,
                    json={
                        "success": True,
                        "data": {
                            "web": [
                                {
                                    "title": f"HVAC Contractor {index}",
                                    "description": (
                                        "Residential and commercial HVAC repair, installation, "
                                        "and maintenance services."
                                    ),
                                    "url": f"https://{domain}/services",
                                }
                                for index, domain in enumerate(domains, start=1)
                            ]
                            + [
                                {
                                    "title": "WorkRocket HVAC recruiting",
                                    "description": "Recruiting and staffing for HVAC companies.",
                                    "url": "https://workrocket.com/hvac",
                                }
                            ],
                            "news": [],
                        },
                    },
                )
            return httpx.Response(
                200,
                json={"success": True, "data": {"web": [], "news": []}},
            )
        return httpx.Response(404)

    transport = httpx.MockTransport(handler)
    pipeline = LeadPipeline(
        company_source=FirecrawlHunterCompanySource(
            "private-hunter-key",
            "private-firecrawl-key",
            max_company_enrichments=6,
            transport=transport,
        ),
        signal_source=FirecrawlSignalSource(
            "private-firecrawl-key",
            transport=transport,
        ),
        contact_verifier=HunterContactVerifier("private-hunter-key"),
        narrative_source=TemplateNarrativeSource(),
        mode="live",
    )

    delivery = asyncio.run(
        pipeline.run(
            LeadRequest(
                desired_count=3,
                minimum_score=30,
                require_timing_signal=False,
            )
        )
    )

    assert delivery.meta.candidates_considered == 6
    assert delivery.meta.qualified_count == 3
    assert len(delivery.leads) == 3
    assert all(lead.score.icp_fit == 40 for lead in delivery.leads)
    assert all(lead.evidence == [] for lead in delivery.leads)
    assert all(
        lead.company.source_provider == "firecrawl+hunter"
        for lead in delivery.leads
    )
    assert all(
        "no current timing signal" in lead.narrative.why_now.lower()
        for lead in delivery.leads
    )
    assert delivery.meta.engine_version == "0.7.0"
    assert delivery.meta.build_id == "20260828-02"
