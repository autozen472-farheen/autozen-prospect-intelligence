import asyncio
import json

import httpx

from app.adapters.live import FirecrawlHunterCompanySource, FirecrawlSignalSource
from app.schemas import LeadRequest, SignalType


def _request() -> LeadRequest:
    return LeadRequest(
        industry="Industrial equipment distributors",
        products_or_services="pumps, valves, compressors, instrumentation, water treatment",
        geographies=["United Arab Emirates"],
        employee_min=5,
        employee_max=500,
        desired_count=1,
        minimum_score=60,
        decision_maker_roles=["Managing Director", "Sales Director"],
        desired_signals=[SignalType.QUOTATION_RFQ, SignalType.PROJECT_TENDER, SignalType.TECHNICAL_SALES],
    )


def test_v122_discovery_uses_four_bounded_queries():
    bodies = FirecrawlHunterCompanySource._web_discovery_bodies(_request(), 3)
    assert len(bodies) == 4
    assert all(body["limit"] >= 40 for body in bodies)


def test_v122_identical_firecrawl_search_is_cached():
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(200, json={"success": True, "data": {"web": [], "news": []}})

    async def run():
        FirecrawlSignalSource._response_cache.clear()
        FirecrawlSignalSource._last_request_at = 0.0
        FirecrawlSignalSource._global_lock = None
        source = FirecrawlSignalSource(
            "test-key",
            transport=httpx.MockTransport(handler),
            min_interval_seconds=0,
            cache_ttl_seconds=900,
        )
        body = {"query": "same query", "limit": 5, "sources": ["web"]}
        first = await source.search(body)
        second = await source.search(body)
        assert first == second

    asyncio.run(run())
    assert calls == 1


def test_v122_429_retries_are_bounded():
    calls = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(429, json={"success": False, "error": "Rate limit exceeded"})

    async def run():
        FirecrawlSignalSource._response_cache.clear()
        FirecrawlSignalSource._last_request_at = 0.0
        FirecrawlSignalSource._global_lock = None
        source = FirecrawlSignalSource(
            "test-key",
            transport=httpx.MockTransport(handler),
            min_interval_seconds=0,
            max_attempts=1,
        )
        try:
            await source.search({"query": "rate limited"})
        except Exception as exc:
            assert "after 1 attempts" in str(exc)
        else:
            raise AssertionError("Expected provider failure")

    asyncio.run(run())
    assert calls == 1
