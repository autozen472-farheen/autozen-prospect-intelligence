from datetime import date, timedelta

from app.schemas import (
    CompanyCandidate,
    Contact,
    EmailStatus,
    Evidence,
    LeadRequest,
    SignalType,
)
from app.scoring import passes_hard_filters, score_candidate


def test_strong_lead_scores_high() -> None:
    request = LeadRequest(desired_count=1)
    company = CompanyCandidate(
        provider_id="1",
        name="Demo HVAC",
        domain="demo.example",
        website="https://demo.example",
        industry="HVAC services",
        city="Austin",
        state="Texas",
        country="United States",
        employee_count=30,
        source_provider="test",
    )
    evidence = [
        Evidence(
            signal_type=SignalType.HIRING,
            title="Hiring technicians",
            url="https://demo.example/jobs",
            snippet="Three open roles",
            source_provider="test",
            published_at=date.today() - timedelta(days=5),
            confidence=0.95,
        ),
        Evidence(
            signal_type=SignalType.EXPANSION,
            title="New service area",
            url="https://news.example/demo-expands",
            snippet="New county coverage",
            source_provider="test",
            published_at=date.today() - timedelta(days=10),
            confidence=0.9,
        ),
    ]
    contact = Contact(
        name="Jamie Doe",
        title="Owner",
        email="jamie@demo.example",
        email_status=EmailStatus.VERIFIED,
        source_provider="test",
    )
    assert passes_hard_filters(request, company)
    score = score_candidate(request, company, evidence, contact)
    assert score.total >= 85
    assert score.icp_fit == 40


def test_out_of_range_company_fails_hard_filter() -> None:
    request = LeadRequest(employee_min=10, employee_max=50)
    company = CompanyCandidate(
        provider_id="2",
        name="Large HVAC",
        domain="large.example",
        website="https://large.example",
        industry="HVAC",
        country="United States",
        employee_count=70,
        source_provider="test",
    )
    assert not passes_hard_filters(request, company)


def test_wrong_geography_fails_hard_filter() -> None:
    request = LeadRequest(geographies=["Canada"])
    company = CompanyCandidate(
        provider_id="3",
        name="US HVAC",
        domain="us-hvac.example",
        website="https://us-hvac.example",
        industry="HVAC",
        country="United States",
        employee_count=25,
        source_provider="test",
    )
    assert not passes_hard_filters(request, company)


def test_common_us_alias_and_hvac_synonym_pass() -> None:
    request = LeadRequest(industry="HVAC", geographies=["US"])
    company = CompanyCandidate(
        provider_id="4",
        name="Heating Demo",
        domain="heating.example",
        website="https://heating.example",
        industry="Heating and air conditioning",
        country="United States",
        employee_count=25,
        source_provider="test",
    )
    assert passes_hard_filters(request, company)


def test_hunter_hvac_service_category_passes_without_admitting_recruiters() -> None:
    request = LeadRequest(industry="HVAC", geographies=["United States"])
    contractor = CompanyCandidate(
        provider_id="5",
        name="Local Mechanical",
        domain="local-mechanical.example",
        website="https://local-mechanical.example",
        industry="Specialty Trade Contractors Building Equipment Contractors",
        country="United States",
        employee_count=25,
        source_provider="hunter",
    )
    recruiter = contractor.model_copy(
        update={
            "provider_id": "6",
            "domain": "hvac-recruiter.example",
            "industry": "Human Resources Staffing and Recruiting",
        }
    )
    assert passes_hard_filters(request, contractor)
    assert not passes_hard_filters(request, recruiter)
