import asyncio

from app.config import Settings
from app.factory import build_pipeline
from app.schemas import LeadRequest, OutcomeEvent
from app.store import SQLiteStore


def test_delivery_and_outcome_round_trip(tmp_path) -> None:
    settings = Settings(
        data_mode="mock",
        narrative_mode="template",
        database_path=tmp_path / "test.db",
    )
    delivery = asyncio.run(
        build_pipeline(settings).run(LeadRequest(desired_count=1))
    )
    store = SQLiteStore(settings.database_path)
    store.save_delivery(delivery)
    loaded = store.get_delivery(delivery.meta.job_id)
    assert loaded is not None
    assert loaded.meta.job_id == delivery.meta.job_id
    jobs = store.list_deliveries()
    assert jobs[0]["job_id"] == delivery.meta.job_id
    event = OutcomeEvent(
        job_id=delivery.meta.job_id,
        company_domain=delivery.leads[0].company.domain,
        outcome="approved",
    )
    store.save_outcome(event)
    outcomes = store.list_outcomes(delivery.meta.job_id)
    assert outcomes[0]["outcome"] == "approved"
