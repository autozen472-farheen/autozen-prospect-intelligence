import asyncio
import json

import httpx

from app.adapters.live import (
    FirecrawlHunterCompanySource,
    FirecrawlSignalSource,
    HunterCompanySource,
)
from app.config import Settings
from app.costing import estimate_zero_cost_usage
from app.schemas import CompanyCandidate, LeadRequest, PhoneType, SignalType
from app.scoring import passes_hard_filters


def test_hunter_free_discover_enrich_and_decision_maker_contract() -> None:
    calls: list[tuple[str, str, dict[str, object] | None]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content) if request.content else None
        calls.append((request.method, request.url.path, body))
        if request.url.path.endswith("/discover"):
            return httpx.Response(
                200,
                json={
                    "data": [
                        {"domain": "alpha-hvac.example", "organization": "Alpha HVAC"},
                        {"domain": "beta-hvac.example", "organization": "Beta HVAC"},
                        {"domain": "unused-hvac.example", "organization": "Unused HVAC"},
                    ]
                },
            )
        if request.url.path.endswith("/companies/find"):
            domain = request.url.params["domain"]
            name = "Alpha HVAC" if domain.startswith("alpha") else "Beta HVAC"
            return httpx.Response(
                200,
                json={
                    "data": {
                        "id": domain,
                        "name": name,
                        "domain": domain,
                        "description": "A commercial HVAC service company.",
                        "metrics": {"employees": "11-50"},
                        "geo": {
                            "city": "Austin",
                            "state": "Texas",
                            "country": "United States",
                        },
                        "category": {"industry": "Mechanical Services"},
                        "linkedin": {"handle": f"company/{domain.split('.')[0]}"},
                        "site": {"phoneNumbers": ["+1 512 555 0100"]},
                    }
                },
            )
        if request.url.path.endswith("/domain-search"):
            assert request.url.params["limit"] == "10"
            assert request.url.params["type"] == "personal"
            assert request.url.params["decision_maker"] == "true"
            assert request.url.params["verification_status"] == "valid,accept_all"
            assert "Owner" in request.url.params["job_titles"]
            return httpx.Response(
                200,
                json={
                    "data": {
                        "emails": [
                            {
                                "value": "owner@alpha-hvac.example",
                                "type": "personal",
                                "first_name": "Avery",
                                "last_name": "Stone",
                                "position": "Owner",
                                "decision_maker": True,
                                "confidence": 96,
                                "verification": {"status": "valid"},
                                "linkedin": "in/avery-stone",
                            }
                        ]
                    }
                },
            )
        return httpx.Response(404)

    source = HunterCompanySource(
        "private-test-key",
        max_company_enrichments=2,
        transport=httpx.MockTransport(handler),
    )
    brief = LeadRequest(
        industry="HVAC",
        employee_min=10,
        employee_max=50,
        desired_count=2,
    )
    companies = asyncio.run(source.discover(brief, 20))
    assert len(companies) == 2
    assert all(company.employee_count_text == "11-50" for company in companies)
    assert all(passes_hard_filters(brief, company) for company in companies)

    contact = asyncio.run(source.find_contact(companies[0], brief))
    assert contact.name == "Avery Stone"
    assert contact.email_status.value == "verified"
    assert contact.phone_type == PhoneType.GENERIC_COMPANY
    assert contact.linkedin_url == "https://www.linkedin.com/in/avery-stone"

    discover_body = next(body for _, path, body in calls if path.endswith("/discover"))
    assert discover_body is not None
    assert "limit" not in discover_body
    assert "offset" not in discover_body
    assert discover_body["keywords"]["include"] == [
        "HVAC",
        "heating",
        "air conditioning",
        "mechanical services",
    ]
    assert discover_body["industry"]["include"] == [
        "Specialty Trade Contractors",
        "Building Equipment Contractors",
        "Repair and Maintenance",
        "Facilities Services",
    ]
    enrichment_calls = [path for _, path, _ in calls if path.endswith("/companies/find")]
    assert len(enrichment_calls) == 2


def test_hunter_rejects_unrequested_role_and_invalid_email() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path.endswith("/domain-search")
        return httpx.Response(
            200,
            json={
                "data": {
                    "emails": [
                        {
                            "value": "hr@example.com",
                            "type": "personal",
                            "first_name": "Harper",
                            "last_name": "Reed",
                            "position": "Director of Human Resources",
                            "decision_maker": True,
                            "verification": {"status": "invalid"},
                        }
                    ]
                }
            },
        )

    source = HunterCompanySource(
        "private-test-key", transport=httpx.MockTransport(handler)
    )
    company = CompanyCandidate(
        provider_id="example.com",
        name="Example HVAC",
        domain="example.com",
        website="https://example.com",
        industry="HVAC services",
        country="United States",
        employee_count_min=11,
        employee_count_max=50,
        source_provider="hunter",
    )
    contact = asyncio.run(source.find_contact(company, LeadRequest()))
    assert contact.name is None
    assert contact.email is None

def test_hunter_retries_without_taxonomy_when_strict_search_is_sparse() -> None:
    discover_bodies: list[dict[str, object]] = []

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/discover"):
            body = json.loads(request.content)
            discover_bodies.append(body)
            if "industry" in body:
                return httpx.Response(
                    200,
                    json={
                        "data": [
                            {"domain": "strict-hvac.example", "organization": "Strict HVAC"}
                        ]
                    },
                )
            return httpx.Response(
                200,
                json={
                    "data": [
                        {"domain": "strict-hvac.example", "organization": "Strict HVAC"},
                        {"domain": "fallback-hvac.example", "organization": "Fallback HVAC"},
                    ]
                },
            )
        if request.url.path.endswith("/companies/find"):
            domain = request.url.params["domain"]
            return httpx.Response(
                200,
                json={
                    "data": {
                        "id": domain,
                        "name": domain.split(".")[0].replace("-", " ").title(),
                        "domain": domain,
                        "metrics": {"employees": "11-50"},
                        "geo": {"country": "United States"},
                        "category": {"industry": "Mechanical Services"},
                    }
                },
            )
        return httpx.Response(404)

    source = HunterCompanySource(
        "private-test-key",
        max_company_enrichments=2,
        transport=httpx.MockTransport(handler),
    )
    companies = asyncio.run(source.discover(LeadRequest(desired_count=2), 20))

    assert [company.domain for company in companies] == [
        "strict-hvac.example",
        "fallback-hvac.example",
    ]
    assert len(discover_bodies) == 2
    assert "industry" in discover_bodies[0]
    assert "industry" not in discover_bodies[1]
    assert discover_bodies[1]["keywords"] == discover_bodies[0]["keywords"]


def test_hunter_does_not_mislabel_a_vendor_that_only_serves_hvac() -> None:
    request = LeadRequest(
        industry="HVAC",
        geographies=["United States"],
        employee_min=10,
        employee_max=50,
    )
    company = HunterCompanySource._company_from_payload(
        {
            "id": "recruiter",
            "name": "Recruiting Vendor",
            "domain": "recruiter.example",
            "description": "Recruiting services for construction and HVAC clients.",
            "tags": ["HVAC hiring"],
            "metrics": {"employees": "11-50"},
            "geo": {"state": "Virginia", "country": "United States"},
            "category": {
                "industry": "Human Resources",
                "subIndustry": "Staffing and Recruiting",
            },
        },
        {"domain": "recruiter.example"},
        request,
    )

    assert company is not None
    assert company.industry == "Human Resources Staffing and Recruiting"
    assert not passes_hard_filters(request, company)


def test_web_discovery_accepts_contractors_and_rejects_hvac_vendors() -> None:
    assert FirecrawlHunterCompanySource._verified_hvac_result(
        {
            "title": "Austin Heating & Cooling",
            "description": "Commercial HVAC repair, installation and maintenance services.",
        }
    )
    assert not FirecrawlHunterCompanySource._verified_hvac_result(
        {
            "title": "HVAC recruiting platform",
            "description": "Recruiting and staffing services for HVAC companies.",
        }
    )
    assert not FirecrawlHunterCompanySource._verified_hvac_result(
        {
            "title": "HVAC CRM software",
            "description": "Lead generation and marketing software for contractors.",
        }
    )
    assert FirecrawlHunterCompanySource._is_excluded_domain("jobs.workrocket.com")


def test_hybrid_discovery_skips_wrong_employee_bands_and_keeps_searching() -> None:
    domains = [f"candidate-{index}.example" for index in range(1, 7)]

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/search"):
            return httpx.Response(
                200,
                json={
                    "data": {
                        "web": [
                            {
                                "url": f"https://{domain}/hvac",
                                "title": f"HVAC Contractor {index}",
                                "description": "Commercial HVAC repair and installation services.",
                            }
                            for index, domain in enumerate(domains, start=1)
                        ]
                    }
                },
            )
        if request.url.path.endswith("/companies/find"):
            domain = request.url.params["domain"]
            index = domains.index(domain) + 1
            employee_band = "51-200" if index <= 3 else "11-50"
            return httpx.Response(
                200,
                json={
                    "data": {
                        "id": domain,
                        "name": f"HVAC Contractor {index}",
                        "domain": domain,
                        "metrics": {"employees": employee_band},
                        "geo": {"country": "United States"},
                        "category": {"industry": "Specialty Trade Contractors"},
                    }
                },
            )
        return httpx.Response(404)

    source = FirecrawlHunterCompanySource(
        "private-hunter-key",
        "private-firecrawl-key",
        max_company_enrichments=6,
        transport=httpx.MockTransport(handler),
    )
    companies = asyncio.run(
        source.discover(LeadRequest(desired_count=1), candidate_limit=20)
    )

    assert [company.domain for company in companies] == domains[3:]
    assert all(company.employee_count_text == "11-50" for company in companies)


def test_firecrawl_search_is_signal_specific_and_time_bounded() -> None:
    captured: dict[str, object] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured.update(json.loads(request.content))
        return httpx.Response(
            200,
            json={
                "data": {
                    "web": [
                        {
                            "url": "https://alpha-hvac.example/careers",
                            "title": "Alpha HVAC careers",
                            "description": "Alpha HVAC is hiring service technicians.",
                            "date": "2026-08-20",
                        }
                    ],
                    "news": [],
                },
                "creditsUsed": 2,
            },
        )

    company = CompanyCandidate(
        provider_id="alpha",
        name="Alpha HVAC",
        domain="alpha-hvac.example",
        website="https://alpha-hvac.example",
        industry="HVAC",
        country="United States",
        employee_count=25,
        source_provider="test",
    )
    source = FirecrawlSignalSource(
        "private-test-key",
        transport=httpx.MockTransport(handler),
    )
    brief = LeadRequest(
        desired_signals=[SignalType.HIRING], freshness_days=30
    )
    evidence = asyncio.run(source.research(company, brief))
    assert evidence[0].signal_type == SignalType.HIRING
    assert evidence[0].confidence == 0.9
    assert captured["tbs"] == "qdr:m"
    assert "hiring" in str(captured["query"])
    assert "funding" not in str(captured["query"])


def test_zero_cost_estimate_reports_candidate_and_delivery_pool_caps() -> None:
    settings = Settings(
        data_mode="live",
        company_provider="hunter",
        hunter_api_key="private-test-key",
        firecrawl_api_key="private-test-key",
        hunter_candidate_attempts_per_run=18,
    )
    estimate = estimate_zero_cost_usage(settings, LeadRequest(desired_count=3))
    assert estimate["estimated_cash_charge"] == 0
    assert estimate["candidate_cap"] == 18
    assert estimate["qualified_pool_cap"] == 9
    assert estimate["hunter"]["estimated_max_credits"] == 27
    assert estimate["firecrawl"]["company_discovery_searches"] == 2
    assert estimate["firecrawl"]["estimated_max_credits"] == 20
    assert estimate["warnings"] == []
