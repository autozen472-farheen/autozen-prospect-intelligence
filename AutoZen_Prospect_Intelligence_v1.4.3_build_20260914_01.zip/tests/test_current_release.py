import asyncio
from pathlib import Path

import yaml

from app import main as main_module
from app.config import Settings
from app.factory import build_pipeline
from app.schemas import DeliveryMeta, LeadDelivery, LeadRequest, SavedDiscoverySeed
from app.version import BUILD_ID, ENGINE_VERSION


def test_default_demo_returns_ranked_uae_industrial_leads(tmp_path) -> None:
    settings = Settings(
        data_mode="mock",
        narrative_mode="template",
        database_path=tmp_path / "test.db",
    )
    delivery = asyncio.run(
        build_pipeline(settings).run(LeadRequest(desired_count=3, minimum_score=40))
    )

    assert len(delivery.leads) == 3
    assert all(
        lead.company.country == "United Arab Emirates" for lead in delivery.leads
    )
    assert all(lead.score.total >= 40 for lead in delivery.leads)
    assert all(lead.evidence for lead in delivery.leads)


def test_release_identity() -> None:
    assert ENGINE_VERSION == "1.4.3"
    assert BUILD_ID == "20260914-01"


def test_database_handoff_replaces_domain_selector_with_one_source(monkeypatch) -> None:
    class SavedProspectStore:
        def saved_discovery(self, domains):
            assert domains == ["pumpsuae.com"]
            return (
                [
                    SavedDiscoverySeed(
                        source_url="https://pumpsuae.com/",
                        source_title="Industrial Pumps & Compressors UAE",
                        snippet="Get a quote today.",
                    )
                ],
                [],
            )

    monkeypatch.setattr(main_module, "store", lambda: SavedProspectStore())
    original = LeadRequest(prospect_domains=["pumpsuae.com"])

    effective = main_module.request_with_database(original)
    delivery = LeadDelivery(
        request=effective,
        meta=DeliveryMeta(
            job_id="handoff-regression",
            mode="live",
            requested_count=1,
            candidates_considered=0,
            qualified_count=0,
            duration_ms=0,
        ),
        leads=[],
    )

    assert original.prospect_domains == ["pumpsuae.com"]
    assert delivery.request.prospect_domains == []
    assert [seed.source_url for seed in delivery.request.saved_discovery] == ["https://pumpsuae.com/"]


def test_default_hunter_cap_and_render_blueprint_match() -> None:
    assert Settings().hunter_candidate_attempts_per_run == 3
    root = Path(__file__).parents[1]
    blueprint = yaml.safe_load((root / "render.yaml").read_text(encoding="utf-8"))
    env = {
        item["key"]: item.get("value")
        for item in blueprint["services"][0]["envVars"]
    }
    assert env["HUNTER_CANDIDATE_ATTEMPTS_PER_RUN"] == "3"
