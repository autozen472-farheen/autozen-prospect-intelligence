"""Single source of truth for AutoZen release and deployment identity."""

ENGINE_VERSION = "1.4.0"
BUILD_ID = "20260908-01"
BUILD_LABEL = f"v{ENGINE_VERSION} · build {BUILD_ID}"
