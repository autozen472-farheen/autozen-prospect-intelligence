# AutoZen 1.4.0 deployment and acceptance

Use these files together:

- `AutoZen_Prospect_Intelligence_v1.4.0_build_20260908_01.zip`
- `Dockerfile_AutoZen_v1.4.0`

Keep the ZIP compressed in the repository.

## A. Activate the build

1. Upload both files to the existing AutoZen GitHub repository. Do not change Villow.
2. In Render → `autozen-prospect-intelligence` → Settings, set Dockerfile Path to `./Dockerfile_AutoZen_v1.4.0`.
3. Deploy the latest commit once and wait for **Live**.
4. Open `/health`; confirm version `1.4.0` and build `20260908-01`.
5. Sign in and confirm all three pages open: Prospecting Agent, Research & Qualification, Prospect Database.

Keep `ENABLE_LIVE_RUNS=false` during these checks.

## B. Make storage durable before client delivery

The supplied free-service default is `/tmp/autozen-prospect-intelligence.db`; it does not survive all restarts/redeploys.

1. Attach a Render persistent disk to the AutoZen service (a paid Render feature) or choose an external production database migration.
2. For a Render disk, mount it at `/var/data/autozen`.
3. Set `DATABASE_PATH=/var/data/autozen/autozen-prospect-intelligence.db`.
4. Deploy, add one harmless imported prospect, restart the service, and confirm it still appears in `/prospects`.
5. Only then set `PERSISTENT_STORAGE_CONFIRMED=true`.

Do not set that variable merely to remove the readiness warning.

## C. One controlled live acceptance

Before enabling live access, confirm private environment values exist: `DASHBOARD_USERNAME`, a password of at least 16 characters, `FIRECRAWL_API_KEY`, and `HUNTER_API_KEY`. Do not send secrets by ordinary email or chat.

1. Set `ENABLE_LIVE_RUNS=true`; keep `DAILY_LIVE_RUN_LIMIT=1`.
2. In Prospecting Agent, search one narrow niche in one market, request up to five results, and set website reads to `0` for the cheapest discovery acceptance.
3. Confirm candidates appear once in Prospect Database and duplicates update rather than multiply.
4. In Research & Qualification, enter the matching ICP, enable **Use saved companies**, request one lead, and review the displayed estimate before approving.
5. Confirm every decision has a grade or an incomplete status, reason, unknowns and source URLs. Export the database CSV.
6. Compare Firecrawl/Hunter logs to the estimate. Do not repeat a failed live run until its saved JSON and diagnostics are reviewed.
7. Set `ENABLE_LIVE_RUNS=false` after acceptance unless the owner approves ongoing use.

## D. Delivery gate

`/v1/readiness` should show:

- `live_data_ready: true`
- `login_configured: true`
- `persistent_storage_confirmed: true`
- `final_delivery_ready: true`

Then provide the client the HTTPS URL and a separate private login. Never share provider API keys or Render access.

If the bounded live test still cannot verify company size or a requested decision-maker, keep the company incomplete/rejected with the exact reason. Change the ICP requirement explicitly instead of spending on repeated runs.
