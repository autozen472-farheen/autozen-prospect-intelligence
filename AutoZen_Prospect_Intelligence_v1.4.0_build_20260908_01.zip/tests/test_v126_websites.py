"""Offline only. Historical discovery + SYNTHETIC HTML/Hunter responses.

These tests prove control flow, not live company facts or provider coverage.
"""
import asyncio
import csv
import io
import json
import socket
from pathlib import Path

import httpx
import pytest

from app import public_web
from app.adapters.imported import ImportAwareCompanySource
from app.adapters.live import FirecrawlHunterCompanySource, HunterCompanySource, ProviderError
from app.config import Settings
from app.costing import estimate_zero_cost_usage
from app.discovery import assess_result, selection_key
from app.exporter import delivery_to_csv, delivery_to_review_csv
from app.factory import build_pipeline
from app.public_web import Page, PublicWebReader, WebReadError, public_addresses, validate_url
from app.schemas import Contact, DiscoveryCandidate, LeadDelivery, LeadRequest, WebsiteReview
from app.scoring import _geography_matches
from app.website_verification import Document, exact_headcount, extract_facts, organization_nodes, verify_website

FIXTURE = Path(__file__).parent / 'fixtures' / 'failed_v125_job.json'


def brief(**overrides):
    return LeadRequest(products_or_services='Pumps, valves', desired_count=1, minimum_score=60, **overrides)


def candidate(domain='supplier.example'):
    return DiscoveryCandidate(domain=domain, source_title='Pump valve supplier UAE', source_url=f'https://{domain}/', snippet='Industrial pumps valves supplier UAE RFQ')


def saved_request(items=None):
    items = items or [candidate()]
    return brief(saved_discovery=[{'source_url': x.source_url, 'source_title': x.source_title, 'snippet': x.snippet} for x in items])


def html(domain, employees=42, country='AE', more='', identity=None):
    org = {'@context': 'https://schema.org', '@type': 'Organization', 'url': identity or f'https://{domain}',
           'name': 'Synthetic Supplier', 'telephone': '+971 40000000',
           'numberOfEmployees': employees}
    if country:
        org['address'] = {'@type': 'PostalAddress', 'addressCountry': country, 'addressLocality': 'Dubai'}
    return '<title>Pumps and valves supplier UAE</title><script type="application/ld+json">' + json.dumps(org) + '</script><p>We supply industrial pumps and valves. Request a quote.</p>' + more


def fake_web(monkeypatch, employees=42, country='AE', more=''):
    calls = []
    def get(url, domain):
        calls.append(url)
        if url.endswith('/robots.txt'):
            return Page(url, 200, 'User-agent: *\nAllow: /', 'text/plain')
        return Page(url, 200, html(domain, employees, country, more))
    monkeypatch.setattr(public_web, 'pinned_get', get)
    return calls


def live_pipeline(monkeypatch, company_data=None, status=200):
    settings = Settings(data_mode='live', company_provider='hunter', narrative_mode='template',
                        hunter_api_key='offline-hunter', firecrawl_api_key='offline-firecrawl')
    pipeline = build_pipeline(settings)
    source = pipeline.company_source.fallback
    attempts, contacts = [], []
    async def no_search(body):
        raise AssertionError('Saved research must not repeat Firecrawl discovery')
    source.web_discovery.search = no_search
    pipeline.signal_source.fallback.search = no_search
    def handler(request):
        assert request.url.path.endswith('/companies/find')
        domain = request.url.params['domain']
        attempts.append(domain)
        data = {'domain': domain, 'name': 'Synthetic Supplier', 'metrics': {'employeesCount': 42}, 'geo': {}}
        data.update(company_data or {})
        return httpx.Response(status, json={'data': data})
    source.transport = httpx.MockTransport(handler)
    async def contact(company, request):
        contacts.append(company.domain)
        return Contact(name='Synthetic Buyer', title='Managing Director', email=f'buyer@{company.domain}',
                       email_status='verified', email_type='person_work', source_provider='hunter')
    source.find_contact = contact
    return pipeline, attempts, contacts, settings


def test_first_party_profile_qualifies_without_company_lookup(monkeypatch):
    calls = fake_web(monkeypatch)
    pipeline, attempts, contacts, settings = live_pipeline(monkeypatch)
    result = asyncio.run(pipeline.run(saved_request()))
    assert len(result.leads) == 1
    lead = result.leads[0]
    assert lead.company.employee_count == 42 and lead.company.country == 'United Arab Emirates'
    assert lead.company.source_provider == 'first_party_website'
    assert {x.field for x in lead.company.verification_facts} == {'employee_count', 'location'}
    assert lead.evidence and all(e.source_provider == 'first_party_website' for e in lead.evidence)
    assert not attempts and contacts == ['supplier.example'] and len(calls) == 2
    report = result.meta.discovery
    assert report.saved_research_used and not report.queries and not report.fallback_used
    assert report.website_checks == 1 and report.website_http_requests == 2
    costs = estimate_zero_cost_usage(settings, saved_request())
    assert costs['firecrawl']['company_discovery_searches'] == 0
    assert costs['firecrawl']['estimated_max_credits'] == 24
    assert costs['hunter']['estimated_max_credits'] == 6


def test_hunter_size_can_use_first_party_address_when_geo_missing(monkeypatch):
    fake_web(monkeypatch, employees=None)
    pipeline, attempts, _, _ = live_pipeline(monkeypatch)
    result = asyncio.run(pipeline.run(saved_request()))
    assert len(result.leads) == len(attempts) == 1
    assert result.leads[0].company.country == 'United Arab Emirates'
    facts = result.leads[0].company.verification_facts
    assert any(x.method == 'hunter_company_enrichment' and x.value == '42' for x in facts)


@pytest.mark.parametrize('status,data,reason', [
    (404, {}, 'hunter_record_not_found'),
    (200, {'metrics': {}}, 'employee_count_unverified'),
    (200, {'geo': {'country': 'India'}}, 'geography_mismatch'),
    (200, {'metrics': {'employeesCount': 5000}}, 'employee_range_mismatch'),
])
def test_missing_or_conflicting_hunter_facts_do_not_qualify(monkeypatch, status, data, reason):
    fake_web(monkeypatch, employees=None)
    pipeline, attempts, contacts, _ = live_pipeline(monkeypatch, data, status)
    result = asyncio.run(pipeline.run(saved_request()))
    assert not result.leads and not contacts and len(attempts) == 1
    assert reason in result.meta.discovery.candidates[0].reasons


@pytest.mark.parametrize('employees,country', [(5000, 'AE'), (42, None), (42, 'IN')])
def test_website_bad_fit_skips_hunter(monkeypatch, employees, country):
    fake_web(monkeypatch, employees=employees, country=country)
    pipeline, attempts, contacts, _ = live_pipeline(monkeypatch)
    result = asyncio.run(pipeline.run(saved_request()))
    assert not result.leads and not attempts and not contacts


@pytest.mark.parametrize('employees,expected_attempts', [(None, 3), (42, 0)])
def test_actual_failed_job_replay_is_bounded_and_deterministic(monkeypatch, employees, expected_attempts):
    fake_web(monkeypatch, employees=employees)
    previous = LeadDelivery.model_validate_json(FIXTURE.read_text())
    assert len(previous.meta.discovery.candidates) == 56
    items = previous.meta.discovery.candidates
    selected = []
    for records in (items, list(reversed(items))):
        pipeline, attempts, contacts, _ = live_pipeline(monkeypatch, status=404)
        result = asyncio.run(pipeline.run(saved_request(records)))
        report = result.meta.discovery
        checked = [x.domain for x in report.candidates if x.website.status != 'not_checked']
        assert len(checked) == report.website_checks == 6
        assert report.website_http_requests <= 24 and len(attempts) == expected_attempts
        assert len(contacts) <= 3 and report.enriched_companies <= 3
        assert not {'moosaalshehi.com', 'xylem.com'}.intersection(checked)
        assert not report.queries and not report.fallback_used
        selected.append((checked, attempts))
    assert selected[0] == selected[1]


@pytest.mark.parametrize('value,expected', [
    (42, (42, None, None)), ({'value': 42}, (42, None, None)),
    ({'minValue': 11, 'maxValue': 50}, (None, 11, 50)),
    (True, (None, None, None)), ('50+', (None, None, None)),
    ({'minValue': 50, 'maxValue': 11}, (None, None, None)),
])
def test_exact_published_headcount_only(value, expected):
    assert exact_headcount(value) == expected


def test_unrelated_organization_and_service_area_not_physical_location():
    review = WebsiteReview()
    doc = Document(html('supplier.example', identity='https://another.example', country=None,
                        more='<p>We serve UAE with over 5000 clients and 20 years experience.</p>'))
    extract_facts(doc, 'https://supplier.example/', 'supplier.example', brief(), review)
    assert review.employee_count is None and review.country is None and not review.facts


def test_conflicting_or_approximate_workforce_not_made_exact():
    review = WebsiteReview()
    extract_facts(Document(html('supplier.example', more='<p>We employ 51 employees.</p>')),
                  'https://supplier.example/', 'supplier.example', brief(), review)
    assert review.employee_count is None and 'website_conflicting_headcounts' in review.reasons
    review = WebsiteReview()
    extract_facts(Document(html('supplier.example', employees=None, more='<p>We have over 50 employees and 500 clients.</p>')),
                  'https://supplier.example/', 'supplier.example', brief(), review)
    assert review.employee_count is None


def test_nested_structured_data_is_bounded():
    value = {'@type': 'Organization'}
    for _ in range(100):
        value = {'@graph': value}
    assert list(organization_nodes(value)) == []


def test_saved_research_rejected_before_unsupported_provider_calls():
    source = ImportAwareCompanySource(HunterCompanySource('offline-hunter'))
    with pytest.raises(ProviderError, match='configuration'):
        asyncio.run(source.discover_batch(saved_request(), 20))
    pipeline = build_pipeline(Settings(data_mode='mock', narrative_mode='template'))
    with pytest.raises(ProviderError, match='live verification'):
        asyncio.run(pipeline.run(saved_request()))


@pytest.mark.parametrize('url,domain', [
    ('http://supplier.example', 'supplier.example'),
    ('https://user:secret@supplier.example', 'supplier.example'),
    ('https://supplier.example:8443', 'supplier.example'),
    ('https://localhost', 'localhost'), ('https://thing.internal', 'thing.internal'),
    ('https://different.example', 'supplier.example'),
    ('https://supplier.example/admin', 'supplier.example'),
    ('https://supplier.example/%61pi/key', 'supplier.example'),
])
def test_unsafe_urls_blocked(url, domain):
    with pytest.raises(WebReadError, match='blocked'):
        validate_url(url, domain)


@pytest.mark.parametrize('addresses', [['127.0.0.1'], ['169.254.169.254'], ['::1'], ['8.8.8.8', '10.1.1.1'], ['::ffff:8.8.8.8']])
def test_dns_checks_every_address_before_socket_connect(monkeypatch, addresses):
    monkeypatch.setattr(socket, 'getaddrinfo', lambda *a, **kw: [(2, 1, 6, '', (x, 443)) for x in addresses])
    with pytest.raises(WebReadError, match='dns_blocked'):
        public_addresses('supplier.example')


@pytest.mark.parametrize('status,robots,content_type,error', [
    (200, 'User-agent: *\nDisallow: /', 'text/plain', 'robots_disallowed'),
    (403, '', 'text/plain', 'robots_unavailable'),
    (200, '<html>oops</html>', 'text/html', 'robots_unavailable'),
    (200, 'User-agent: *\nCrawl-delay: 5', 'text/plain', 'robots_crawl_delay'),
])
def test_robots_access_limits_stop_page_fetch(monkeypatch, status, robots, content_type, error):
    calls = []
    def get(url, domain):
        calls.append(url)
        return Page(url, status, robots, content_type)
    monkeypatch.setattr(public_web, 'pinned_get', get)
    with pytest.raises(WebReadError, match=error):
        asyncio.run(PublicWebReader().read('https://supplier.example/', 'supplier.example'))
    assert len(calls) == 1


@pytest.mark.parametrize('status', [403, 429])
def test_page_access_denial_does_not_try_other_routes(monkeypatch, status):
    calls = []
    def get(url, domain):
        calls.append(url)
        return Page(url, 404, '', 'text/plain') if url.endswith('/robots.txt') else Page(url, status, '')
    monkeypatch.setattr(public_web, 'pinned_get', get)
    review = asyncio.run(verify_website(candidate(), brief(), PublicWebReader()))
    assert review.status == 'unavailable' and review.reasons == [f'website_http_{status}']
    assert len(calls) == 2


def test_redirect_to_other_host_never_requested(monkeypatch):
    calls = []
    def get(url, domain):
        calls.append(url)
        return Page(url, 404, '', 'text/plain') if url.endswith('/robots.txt') else Page(url, 302, '', location='https://169.254.169.254/latest')
    monkeypatch.setattr(public_web, 'pinned_get', get)
    with pytest.raises(WebReadError, match='url_blocked'):
        asyncio.run(PublicWebReader().read('https://supplier.example/', 'supplier.example'))
    assert len(calls) == 2


def test_shared_http_budget_includes_robots_and_redirects(monkeypatch):
    calls = fake_web(monkeypatch)
    reader = PublicWebReader(limit=1)
    with pytest.raises(WebReadError, match='budget'):
        asyncio.run(reader.read('https://supplier.example/', 'supplier.example'))
    assert reader.requests == len(calls) == 1


def test_country_abbreviations_do_not_match_inside_other_names():
    assert not _geography_matches(['US'], 'Australia')
    assert _geography_matches(['UAE'], 'Dubai, United Arab Emirates')
    assert not _geography_matches(['Dubai'], 'Sharjah, United Arab Emirates')


@pytest.mark.parametrize('oversize', [False, True])
def test_pinned_connection_uses_public_numeric_ip_and_tls_hostname(monkeypatch, oversize):
    trace = []
    class FakeSocket:
        def settimeout(self, value): trace.append(('timeout', value))
        def connect(self, endpoint): trace.append(('connect', endpoint))
        def close(self): pass
    class FakeContext:
        def set_alpn_protocols(self, protocols): pass
        def wrap_socket(self, sock, server_hostname):
            trace.append(('tls_hostname', server_hostname))
            return sock
    class FakeResponse:
        status = 200
        headers = type('Headers', (), {'get_content_charset': lambda self: 'utf-8'})()
        def getheader(self, key, default=None):
            return {'Content-Type': 'text/html', 'Content-Length': str(900000 if oversize else 0)}.get(key, default)
        def read1(self, size): return b''
    class FakeConnection:
        def __init__(self, host, timeout): self.sock = None
        def request(self, method, path, headers):
            assert method == 'GET' and set(headers) == {'User-Agent', 'Accept', 'Accept-Encoding'}
        def getresponse(self): return FakeResponse()
        def close(self): pass
    monkeypatch.setattr(public_web, 'public_addresses', lambda host: ['8.8.8.8'])
    monkeypatch.setattr(public_web.socket, 'socket', lambda *args: FakeSocket())
    monkeypatch.setattr(public_web.ssl, 'create_default_context', lambda: FakeContext())
    monkeypatch.setattr(public_web.http.client, 'HTTPSConnection', FakeConnection)
    if oversize:
        with pytest.raises(WebReadError, match='too_large'):
            public_web.pinned_get('https://supplier.example/', 'supplier.example')
    else:
        assert public_web.pinned_get('https://supplier.example/', 'supplier.example').status == 200
    assert ('connect', ('8.8.8.8', 443)) in trace
    assert ('tls_hostname', 'supplier.example') in trace


def test_review_export_preserves_unknowns_and_neutralizes_formulas():
    result = LeadDelivery.model_validate_json(FIXTURE.read_text())
    assert not list(csv.DictReader(io.StringIO(delivery_to_csv(result))))
    rows = list(csv.DictReader(io.StringIO(delivery_to_review_csv(result))))
    assert len(rows) == 56 and all(row['published_employee_count'] == '' for row in rows)
    result.meta.discovery.candidates[0].source_title = '=HYPERLINK("bad")'
    result.meta.discovery.candidates[1].status = 'qualified'
    rows = list(csv.DictReader(io.StringIO(delivery_to_review_csv(result))))
    assert len(rows) == 55 and rows[0]['search_title'].startswith("'=")


def test_api_review_export_and_health_offline(tmp_path, monkeypatch):
    from app import main
    from app.store import SQLiteStore
    store = SQLiteStore(tmp_path / 'test.db')
    result = LeadDelivery.model_validate_json(FIXTURE.read_text())
    store.save_delivery(result)
    monkeypatch.setattr(main, 'store', lambda: store)
    async def check():
        async with httpx.AsyncClient(transport=httpx.ASGITransport(app=main.app), base_url='http://offline') as client:
            health = await client.get('/health')
            assert health.json()['engine_version'] == '1.4.0'
            response = await client.get(f'/v1/jobs/{result.meta.job_id}/review.csv')
            assert response.status_code == 200 and 'unqualified_research' in response.headers['content-disposition']
            assert len(list(csv.DictReader(io.StringIO(response.text)))) == 56
    asyncio.run(check())
