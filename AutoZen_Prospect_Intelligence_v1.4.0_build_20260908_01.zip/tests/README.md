# Current release tests

This suite covers the AutoZen industrial-distributor schema, Firecrawl discovery breadth, request pacing and caching, controlled fallback discovery, visible diagnostics, Hunter enrichment limits, release identity, and the safe UAE demo.

Run `python -m pytest` with the project dependencies and pytest installed. The suite blocks real outbound connections; provider behavior is simulated. The four JSON files in `fixtures/firecrawl` and `fixtures/failed_v125_job.json` are supplied historical exports, not freshly executed searches. v126 cases exercise the real public-page reader, parser, company selection, saved-research flow and pipeline with synthetic HTML/HTTP responses. Legacy adapter cases use a documented synthetic website double to isolate the older provider logic.

Run `node --test tests/dashboard_logic.cjs tests/global_dashboard.cjs` for 23 dashboard-logic cases. These use a minimal DOM double, not a rendered layout. Run `node --check app/static/app.js` and `node --check app/static/global.js` for syntax validation.

v1.3.1 adds 38 Python diagnostics cases, for 202 in total. These use simulated HTTPX transports and ASGI requests; real sockets are blocked. They check error categories, timing, safe exception-chain classification, no secret/body disclosure, received statuses, no retries, saved diagnostic replay and the unchanged daily allowance. No live provider success is implied.

v1.4.0 contains 247 offline Python tests and 23 Node dashboard checks. The added cases cover canonical-domain deduplication, discovery-to-database handoff, contact and evidence persistence, generic first-party business verification, revenue-workflow classification, stable A+/A/B/Reject boundaries, buyer-role priority, and non-industrial discovery queries. Existing screening, provider-failure, idempotency, safe browsing, CSV, authentication and no-credit regression coverage remains intact. Retained candidates are not thereby verified or qualified.

Neither suite spends provider credits, sends email, or deploys anything. A successful offline suite cannot confirm current provider coverage, billing, or live deployment health.

The obsolete Villow/HVAC-era suite remains preserved in the V1.2.3 archive and is intentionally not part of this release.
