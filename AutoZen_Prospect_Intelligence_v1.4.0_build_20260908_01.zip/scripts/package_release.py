"""Package reviewed source only; no secrets, databases, caches or legacy builds."""
from pathlib import Path
from hashlib import sha256
from zipfile import ZipFile, ZIP_DEFLATED


def main():
    root = Path(__file__).resolve().parents[1]
    destination = root.parents[1] / 'outputs' / 'autozen_v140'
    destination.mkdir(parents=True, exist_ok=True)
    target = destination / 'AutoZen_Prospect_Intelligence_v1.4.0_build_20260908_01.zip'
    if target.exists():
        raise SystemExit('Refusing to overwrite an existing packaged release.')
    files = [root / name for name in ('README.md', 'DEPLOYMENT.md', 'pyproject.toml', 'requirements.lock', 'Dockerfile', 'render.yaml')]
    for directory in ('app', 'scripts', 'tests', 'sample'):
        files.extend(p for p in (root/directory).rglob('*') if p.is_file() and not p.is_symlink()
                     and '__pycache__' not in p.parts and p.suffix not in {'.pyc', '.db'} and not p.name.startswith('.'))
    with ZipFile(target, 'x', ZIP_DEFLATED) as archive:
        for path in sorted(files):
            archive.write(path, path.relative_to(root))
    with ZipFile(target) as archive:
        assert archive.testzip() is None
        assert 'app/global_discovery.py' in archive.namelist()
        assert 'app/access.py' in archive.namelist()
        assert 'app/result_screening.py' in archive.namelist()
        assert 'app/store.py' in archive.namelist()
        assert 'app/static/prospects.html' in archive.namelist()
    print(f'{target}\n{target.stat().st_size} bytes\nSHA256 {sha256(target.read_bytes()).hexdigest()}')


if __name__ == '__main__':
    main()
